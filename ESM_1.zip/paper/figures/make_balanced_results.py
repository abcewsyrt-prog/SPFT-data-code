"""Condition-resolved evidence and compact interventions; complete seed-level source data."""
import csv,json,statistics,sys,os
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
sys.path.insert(0,os.environ.get('NATURE_FIGURE_SCRIPTS',str(Path.home()/'.codex/skills/nature-figure/scripts')))
from audit_panel_alignment import require_matplotlib_panel_alignment
R=Path(__file__).resolve().parents[2];D=R/'results';O=Path(__file__).parent
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Helvetica','DejaVu Sans'],'font.size':8,'axes.labelsize':8,'xtick.labelsize':7.5,'ytick.labelsize':7.5,'legend.fontsize':7.5,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65})
B='#315F80';A='#AA704B';G='#52796B'
def save(fig,name,rows):
 fig.canvas.draw();require_matplotlib_panel_alignment(fig,json_out=str(O/f'{name}.alignment.json'),overlay_svg=str(O/f'{name}.alignment.svg'),tolerance_pt=1.5,gutter_tolerance_pt=1.5,require_panel_labels=True,strict=True)
 fig.savefig(O/f'{name}.pdf');fig.savefig(O/f'{name}.svg');fig.savefig(O/f'{name}.png',dpi=600);fig.savefig(O/f'{name}.tiff',dpi=600)
 with (O/f'{name}.source-data.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 plt.close(fig)
def title(ax,letter,t):
 ax.set_title(t,fontsize=9,pad=10);ax.annotate(letter,(0,1),xycoords='axes fraction',xytext=(-26,11),textcoords='offset points',fontweight='bold',fontsize=10,va='bottom')
# Condition profile and adaptation/retention tradeoff have distinct inferential roles.
fig,(a,b)=plt.subplots(2,1,figsize=(5.15,4.75));fig.subplots_adjust(left=.20,right=.97,bottom=.12,top=.90,hspace=.96)
keys=[f'{n}@{depth}' for n in [256,512,1024] for depth in [.1,.5,.9]];modes=['baseline','lcr','l2replay','spft'];names=['Reference','LCR','L2 + LCR','SPFT'];rows=[];matrix=[];allrecords={}
for mode in modes:
 records=[json.loads((D/f'revision_v5/matched_original/seed{s}_selected_test.json' if mode=='l2replay' else D/f'revision_v2/mamba130_seed{s}/{mode}.json').read_text()) for s in range(3)];allrecords[mode]=records
 matrix.append([statistics.mean(r['retrieval'][k]['full_key_exact_match'] for r in records) for k in keys])
 for seed,r in enumerate(records):
  for k in keys:rows.append(dict(endpoint='condition_em',method=mode,seed=seed,condition=k,value=r['retrieval'][k]['full_key_exact_match'],text_nll=''))
a.imshow(matrix,cmap='Blues',vmin=0,vmax=1,aspect='auto',interpolation='nearest')
for i,row in enumerate(matrix):
 for j,v in enumerate(row):a.text(j,i,f'{100*v:.0f}',ha='center',va='center',fontsize=7,color='white' if v>.65 else '#273746')
a.set_yticks(range(4),names);a.set_xticks(range(9),[f'{n}\n{p}' for n in [256,512,1024] for p in ['.1','.5','.9']]);a.tick_params(length=0);a.set_xlabel('Context length / insertion depth',labelpad=3)
for x in [2.5,5.5]:a.axvline(x,color='white',lw=2)
title(a,'a','Complete-key retrieval by test condition (%)')
q=json.loads((D/'revision_v3/backbone_conditional_retention.json').read_text());new=json.loads((D/'revision_v5/matched_analysis.json').read_text());colors={'lcr':'#7F8A94','l2replay':B,'spft':G};test={}
for mode,c in colors.items():
 xs=[r['text']['nll'] for r in allrecords[mode]];ys=new['conditional_retention']['values'] if mode=='l2replay' else [v['conditional_retention'] for v in q['mamba130'][mode]['values']];test[mode]=(xs,ys)
 b.scatter(xs,ys,s=18,color=c,alpha=.7,zorder=4)
 b.errorbar(statistics.mean(xs),statistics.mean(ys),xerr=statistics.stdev(xs),yerr=statistics.stdev(ys),fmt='D',color=c,ms=4.5,capsize=2,lw=.9,zorder=3)
 for seed,(x,y) in enumerate(zip(xs,ys)):rows.append(dict(endpoint='retention_nll',method=mode,seed=seed,condition='all',value=y,text_nll=x))
for seed in range(3):b.plot([test[m][0][seed] for m in ['l2replay','spft']],[test[m][1][seed] for m in ['l2replay','spft']],color='#BEC4C9',lw=.7,zorder=1)
b.set_xlabel('Held-out text NLL');b.set_ylabel('Conditional retention Q');b.set_xlim(2.768,2.817);b.set_ylim(.59,.85);b.set_yticks([.6,.7,.8]);b.grid(axis='y',color='#E6E8EA',lw=.5);b.set_axisbelow(True);title(b,'b','Retained retrieval versus text adaptation')
fig.legend(handles=[Line2D([],[],marker='D',lw=0,color=c,label={'lcr':'LCR','l2replay':'L2 + LCR','spft':'SPFT'}[m],ms=4) for m,c in colors.items()],loc='upper center',bbox_to_anchor=(.59,.505),ncol=3,frameon=False,handlelength=1,columnspacing=1.2)
save(fig,'figure_matched_profile',rows)
# Graded effect and four endpoint combinations clarify the same parameter intervention.
sw=json.loads((D/'revision_v3/swaps_corrected/results.json').read_text())['results'];rows=[]
fig,(a,b)=plt.subplots(1,2,figsize=(5.15,3.2));fig.subplots_adjust(left=.13,right=.98,bottom=.23,top=.78,wspace=.60)
for group,c,name in [('decay',B,'Decay group'),('content',A,'Other parameters')]:
 vals=[]
 for seed in range(3):
  v=sw[str(seed)]['interpolation'][group];xs=[r['alpha'] for r in v];ys=[r['recall']['768']['accuracy'] for r in v];vals.append(ys)
  for x,y in zip(xs,ys):rows.append(dict(intervention='interpolation',group=group,seed=seed,alpha=x,recall=y,short_accuracy=''))
 a.errorbar(xs,[statistics.mean(v) for v in zip(*vals)],yerr=[statistics.stdev(v) for v in zip(*vals)],color=c,marker='o',ms=3,lw=1.2,capsize=2,label=name)
a.set_xlim(-.02,1.02);a.set_ylim(-.03,1.05);a.set_xticks([0,.5,1]);a.set_xlabel('Interpolation coefficient α');a.set_ylabel('Recall at length 768');a.grid(axis='y',color='#E6E8EA',lw=.5);a.set_axisbelow(True);title(a,'a','Graded intervention')
mat=[];acc=[]
for d in ['pre','ft']:
 rr=[];aa=[]
 for o in ['pre','ft']:
  vv=[sw[str(seed)]['swaps'][f'decay_{d}_content_{o}'] for seed in range(3)];rr.append(statistics.mean(r['recall']['768']['accuracy'] for r in vv));aa.append(statistics.mean(r['local']['accuracy'] for r in vv))
  for seed,v in enumerate(vv):rows.append(dict(intervention='swap',group=f'decay_{d}_other_{o}',seed=seed,alpha='',recall=v['recall']['768']['accuracy'],short_accuracy=v['local']['accuracy']))
 mat.append(rr);acc.append(aa)
b.imshow(mat,vmin=0,vmax=1,cmap='Blues',aspect='auto',interpolation='nearest')
for i in range(2):
 for j in range(2):
  c='white' if mat[i][j]>.65 else '#273746';b.text(j,i-.10,f'{mat[i][j]:.3f}',ha='center',va='center',fontsize=10,color=c);b.text(j,i+.20,f'({acc[i][j]:.3f})',ha='center',va='center',fontsize=7.5,color=c)
b.set_xticks([0,1],['Reference','Adapted']);b.set_yticks([0,1],['Reference','Adapted']);b.tick_params(length=0);b.set_xlabel('Other-parameter source');b.set_ylabel('Decay-group source');b.axvline(.5,color='white',lw=2);b.axhline(.5,color='white',lw=2);title(b,'b','Recall (short accuracy)')
fig.legend(loc='upper center',bbox_to_anchor=(.55,1),ncol=2,frameon=False,columnspacing=1.7)
save(fig,'figure_intervention_balanced',rows)
