"""
Figure 4 Redesign: Parameter Intervention and Mechanistic Localization (Controlled Model)
Answers: Which parameter pathways drive the catastrophic forgetting of retrieval during short-context
adaptation: the designated decay module (A_log, W_g) or the other/content pathways (projections, gates, MLP)?
"""
import csv
import json
import statistics
import sys
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

# Import panel alignment auditor
sys.path.insert(0, '/workspace/.gemini/config/skills/nature-figure/scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment

# Paths
OUT_DIR = Path('/workspace/Desktop/实验/Applied Intelligence/paper/figures/antigravity_redesign')
RES_DIR = Path('/workspace/Desktop/实验/Applied Intelligence/results')

# Load source data
swaps_data = json.loads((RES_DIR / 'revision_v10/swaps_compatible/results.json').read_text())['results']

# Styling
plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
    'font.size': 8.5,
    'axes.labelsize': 8.5,
    'xtick.labelsize': 8.5,
    'ytick.labelsize': 8.5,
    'legend.fontsize': 8.5,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.linewidth': 0.65,
    'axes.edgecolor': '#333F48',
    'pdf.fonttype': 42,
    'svg.fonttype': 'none',
})

# Distinct colors for parameter pathways
COLOR_DECAY = '#2B6CB0'    # Deep Royal Blue for Decay group
COLOR_CONTENT = '#C53030'  # Crimson / Coral for Other/Content parameters

fig, (ax_a, ax_b) = plt.subplots(1, 2, figsize=(5.3, 3.25))
fig.subplots_adjust(left=0.12, right=0.89, bottom=0.19, top=0.76, wspace=0.48)

csv_rows = []

# --- PANEL A: Graded Parameter-Group Interpolation ---
ax_a.grid(axis='y', color='#E8ECF0', lw=0.5, zorder=0)
ax_a.set_axisbelow(True)

for group, color, marker, label in [
    ('decay', COLOR_DECAY, 'o', 'Decay group ($A_{\\log}, W_g$)'),
    ('content', COLOR_CONTENT, 's', 'Other parameters (Content/Readout)')
]:
    vals = []
    for seed in range(3):
        v = swaps_data[str(seed)]['interpolation'][group]
        xs = [r['alpha'] for r in v]
        ys = [r['recall']['768']['accuracy'] for r in v]
        vals.append(ys)
        for a_val, y_val in zip(xs, ys):
            csv_rows.append({
                'panel': 'a_interpolation',
                'group': group,
                'seed': seed,
                'alpha': a_val,
                'recall_768': y_val,
                'short_task_accuracy': '',
            })
            
    means = [statistics.mean(col) for col in zip(*vals)]
    sds = [statistics.stdev(col) for col in zip(*vals)]
    
    # Shaded error band
    ax_a.fill_between(
        xs,
        [m - s for m, s in zip(means, sds)],
        [m + s for m, s in zip(means, sds)],
        color=color,
        alpha=0.15,
        zorder=2
    )
    
    # Line with error bars
    ax_a.errorbar(
        xs, means,
        yerr=sds,
        color=color,
        ecolor=color,
        elinewidth=1.0,
        capsize=2.2,
        capthick=0.8,
        marker=marker,
        ms=4.0,
        lw=1.3,
        label=label,
        zorder=4
    )

ax_a.set_xlim(-0.03, 1.03)
ax_a.set_ylim(-0.04, 1.05)
ax_a.set_xticks([0.0, 0.2, 0.4, 0.6, 0.8, 1.0])
ax_a.set_xticklabels(['0.0', '0.2', '0.4', '0.6', '0.8', '1.0'])
ax_a.set_yticks([0.0, 0.25, 0.50, 0.75, 1.00])
ax_a.set_yticklabels(['0.00', '0.25', '0.50', '0.75', '1.00'])

ax_a.set_xlabel('Interpolation coefficient $\\alpha$', labelpad=4)
ax_a.set_ylabel('Recall at length 768 ($\\uparrow$)', labelpad=4)
ax_a.set_title('Graded parameter interpolation', fontsize=8.5, fontweight='bold', pad=8, color='#1A202C')
ax_a.annotate('a', xy=(0, 1), xycoords='axes fraction', xytext=(-20, 9), textcoords='offset points', fontweight='bold', fontsize=10.0, va='bottom')

# Unified legend placed at top of figure
legend_handles_a = [
    Line2D([], [], marker='o', lw=1.3, color=COLOR_DECAY, ms=4.0, label='Decay group ($A_{\\log}, W_g$)'),
    Line2D([], [], marker='s', lw=1.3, color=COLOR_CONTENT, ms=4.0, label='Other parameters (Content/Readout)'),
]

fig.legend(
    handles=legend_handles_a,
    loc='upper center',
    bbox_to_anchor=(0.52, 0.94),
    ncol=2,
    frameon=False,
    fontsize=8.5,
    handletextpad=0.35,
    columnspacing=1.5
)

# --- PANEL B: Factorial Checkpoint Swap Matrix ---
mat_recall = []
mat_acc = []

for d in ['pre', 'ft']:
    row_r = []
    row_a = []
    for o in ['pre', 'ft']:
        recs = [swaps_data[str(s)]['swaps'][f'decay_{d}_content_{o}']['recall']['768']['accuracy'] for s in range(3)]
        accs = [swaps_data[str(s)]['swaps'][f'decay_{d}_content_{o}']['local']['accuracy'] for s in range(3)]
        mean_r = statistics.mean(recs)
        mean_a = statistics.mean(accs)
        row_r.append(mean_r)
        row_a.append(mean_a)
        for s_idx, (r_val, a_val) in enumerate(zip(recs, accs)):
            csv_rows.append({
                'panel': 'b_swap_matrix',
                'group': f'decay_{d}_other_{o}',
                'seed': s_idx,
                'alpha': '',
                'recall_768': r_val,
                'short_task_accuracy': a_val,
            })
    mat_recall.append(row_r)
    mat_acc.append(row_a)

im_b = ax_b.imshow(mat_recall, vmin=0, vmax=1.0, cmap='Blues', aspect='auto', interpolation='nearest')

# Display Recall (large bold) and Short-Task Accuracy (small)
for i in range(2):
    for j in range(2):
        rec_val = mat_recall[i][j]
        acc_val = mat_acc[i][j]
        text_color = 'white' if rec_val > 0.55 else '#1A202C'
        
        # Recall at top
        ax_b.text(j, i - 0.12, f'{rec_val:.3f}', ha='center', va='center', fontsize=9.5, fontweight='bold', color=text_color)
        # Short accuracy at bottom
        ax_b.text(j, i + 0.18, f'(Acc: {acc_val:.3f})', ha='center', va='center', fontsize=8.5, color=text_color)

# Clean grid separation
ax_b.axvline(0.5, color='white', lw=1.8)
ax_b.axhline(0.5, color='white', lw=1.8)

ax_b.set_xticks([0, 1])
ax_b.set_xticklabels(['Reference', 'Adapted'], fontsize=8.5)
ax_b.set_yticks([0, 1])
ax_b.set_yticklabels(['Reference', 'Adapted'], fontsize=8.5)
ax_b.tick_params(length=0)

ax_b.set_xlabel('Other-parameter source (Content)', labelpad=4)
ax_b.set_ylabel('Decay-group source ($A_{\\log}, W_g$)', labelpad=4)
ax_b.set_title('Recall & (short-task acc.)', fontsize=8.5, fontweight='bold', pad=8, color='#1A202C')
ax_b.annotate('b', xy=(0, 1), xycoords='axes fraction', xytext=(-22, 9), textcoords='offset points', fontweight='bold', fontsize=10.0, va='bottom')

# Elegant slim colorbar for Panel B
cax_b = inset_axes(ax_b, width='3.5%', height='100%', loc='lower left', bbox_to_anchor=(1.04, 0., 1, 1), bbox_transform=ax_b.transAxes, borderpad=0)
cbar_b = fig.colorbar(im_b, cax=cax_b, ticks=[0, 0.25, 0.50, 0.75, 1.0])
cbar_b.ax.set_yticklabels(['0.00', '0.25', '0.50', '0.75', '1.00'], fontsize=8.5)
cbar_b.outline.set_linewidth(0.5)

# Enforce panel alignment and save
fig.canvas.draw()
require_matplotlib_panel_alignment(
    fig,
    json_out=str(OUT_DIR / 'fig4_parameter_interventions.alignment.json'),
    overlay_svg=str(OUT_DIR / 'fig4_parameter_interventions.alignment.svg'),
    tolerance_pt=1.5,
    gutter_tolerance_pt=1.5,
    require_panel_labels=True,
    strict=True
)

fig.savefig(OUT_DIR / 'fig4_parameter_interventions.pdf')
fig.savefig(OUT_DIR / 'fig4_parameter_interventions.svg')
fig.savefig(OUT_DIR / 'fig4_parameter_interventions.png', dpi=600)

with (OUT_DIR / 'fig4_parameter_interventions.source-data.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['panel', 'group', 'seed', 'alpha', 'recall_768', 'short_task_accuracy'])
    writer.writeheader()
    writer.writerows(csv_rows)

plt.close(fig)
print('Figure 4 redesigned and exported successfully.')
