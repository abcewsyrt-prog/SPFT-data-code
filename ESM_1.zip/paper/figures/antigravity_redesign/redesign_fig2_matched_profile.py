"""
Figure 2 Redesign: Replay-Matched Condition Profile & Adaptation-Retention Tradeoff (Mamba-2 130M)
Answers: Under strictly matched reference checkpoints and replay exposure, how does SPFT compare
against LCR and conventional parameter regularization (L2+LCR) across individual conditions
and along the text-adaptation vs retrieval-retention Pareto frontier?
"""
import csv
import json
import statistics
import sys
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

# Import panel alignment auditor
sys.path.insert(0, '/workspace/.gemini/config/skills/nature-figure/scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment

# Paths
OUT_DIR = Path('/workspace/Desktop/实验/Applied Intelligence/paper/figures/antigravity_redesign')
RES_DIR = Path('/workspace/Desktop/实验/Applied Intelligence/results')

# Load source data
retention_data = json.loads((RES_DIR / 'revision_v3/backbone_conditional_retention.json').read_text())
matched_analysis = json.loads((RES_DIR / 'revision_v5/matched_analysis.json').read_text())

keys = [f'{n}@{depth}' for n in [256, 512, 1024] for depth in [0.1, 0.5, 0.9]]
modes = ['baseline', 'lcr', 'l2replay', 'spft']
method_display_names = ['Reference', 'LCR', 'L2 + LCR', 'SPFT']

records = {}
for m in ['baseline', 'lcr', 'spft']:
    records[m] = [json.loads((RES_DIR / f'revision_v2/mamba130_seed{s}/{m}.json').read_text()) for s in range(3)]
records['l2replay'] = [json.loads((RES_DIR / f'revision_v5/matched_original/seed{s}_selected_test.json').read_text()) for s in range(3)]

# Styling
plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
    'font.size': 8.5,
    'axes.labelsize': 8.5,
    'xtick.labelsize': 8.5,
    'ytick.labelsize': 8.5,
    'legend.fontsize': 8.5,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.linewidth': 0.65,
    'axes.edgecolor': '#333F48',
    'pdf.fonttype': 42,
    'svg.fonttype': 'none',
})

# Colors
COLORS = {
    'lcr': '#2B6CB0',       # Scientific Blue
    'l2replay': '#5C6B73',  # Slate Steel Gray
    'spft': '#1B7837',      # Emerald Green
}

SEED_MARKERS = ['o', 's', '^']

# Setup figure with 2 vertically stacked panels
# Width 5.25 in (378 pt), height 4.5 in
fig, (ax_a, ax_b) = plt.subplots(2, 1, figsize=(5.25, 4.5))
fig.subplots_adjust(left=0.17, right=0.86, bottom=0.10, top=0.87, hspace=0.58)

csv_rows = []

# --- PANEL A: Condition-Resolved Retrieval Heatmap ---
matrix = []
for m in modes:
    row = [statistics.mean(r['retrieval'][k]['full_key_exact_match'] for r in records[m]) for k in keys]
    matrix.append(row)
    for seed_idx, r in enumerate(records[m]):
        for k in keys:
            csv_rows.append({
                'panel': 'a_condition_em',
                'method': m,
                'seed': seed_idx,
                'condition': k,
                'exact_match': r['retrieval'][k]['full_key_exact_match'],
                'text_nll': '',
                'conditional_retention_Q': '',
            })

im = ax_a.imshow(matrix, cmap='Blues', vmin=0, vmax=1.0, aspect='auto', interpolation='nearest')

# Overlay percentage text in each cell
for i in range(len(modes)):
    for j in range(len(keys)):
        val = matrix[i][j]
        text_color = 'white' if val > 0.55 else '#1A202C'
        ax_a.text(j, i, f'{val * 100:.0f}%', ha='center', va='center', fontsize=8.5, color=text_color, fontweight='medium')

# Grid separation between context lengths (256 | 512 | 1024)
for x in [2.5, 5.5]:
    ax_a.axvline(x, color='white', lw=1.8)
for y in [0.5, 1.5, 2.5]:
    ax_a.axhline(y, color='white', lw=1.0)

ax_a.set_yticks(range(4))
ax_a.set_yticklabels(method_display_names, fontsize=8.5)
ax_a.set_xticks(range(9))
ax_a.set_xticklabels(['0.1', '0.5', '0.9', '0.1', '0.5', '0.9', '0.1', '0.5', '0.9'], fontsize=8.5)
ax_a.tick_params(length=0)
ax_a.set_xlabel('Insertion depth $\\rho$', labelpad=3)

# Super-headers for context lengths
ax_a.text(1.0, -0.65, 'Context $L=256$', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#2D3748')
ax_a.text(4.0, -0.65, 'Context $L=512$', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#2D3748')
ax_a.text(7.0, -0.65, 'Context $L=1024$', ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#2D3748')

ax_a.set_title('Complete-key retrieval by test condition (%)', fontsize=8.5, fontweight='bold', pad=14, color='#1A202C')
ax_a.annotate('a', xy=(0, 1), xycoords='axes fraction', xytext=(-26, 10), textcoords='offset points', fontweight='bold', fontsize=10.0, va='bottom')

# Elegant slim colorbar on the right
cax = inset_axes(ax_a, width='3.0%', height='100%', loc='lower left', bbox_to_anchor=(1.03, 0., 1, 1), bbox_transform=ax_a.transAxes, borderpad=0)
cbar = fig.colorbar(im, cax=cax, ticks=[0, 0.25, 0.50, 0.75, 1.0])
cbar.ax.set_yticklabels(['0%', '25%', '50%', '75%', '100%'], fontsize=8.5)
cbar.outline.set_linewidth(0.5)

# --- PANEL B: Retrieval Retention vs Text Adaptation Tradeoff ---
ax_b.set_axisbelow(True)

tradeoff_data = {}
for m in ['lcr', 'l2replay', 'spft']:
    xs = [r['text']['nll'] for r in records[m]]
    ys = matched_analysis['conditional_retention']['values'] if m == 'l2replay' else [v['conditional_retention'] for v in retention_data['mamba130'][m]['values']]
    tradeoff_data[m] = (xs, ys)
    
    c = COLORS[m]
    mean_x = statistics.mean(xs)
    mean_y = statistics.mean(ys)
    sd_x = statistics.stdev(xs)
    sd_y = statistics.stdev(ys)
    
    # Plot individual seeds
    for s_idx, (x_val, y_val) in enumerate(zip(xs, ys)):
        ax_b.scatter(x_val, y_val, s=20, marker=SEED_MARKERS[s_idx], color=c, alpha=0.75, zorder=4)
        csv_rows.append({
            'panel': 'b_tradeoff',
            'method': m,
            'seed': s_idx,
            'condition': 'overall',
            'exact_match': '',
            'text_nll': x_val,
            'conditional_retention_Q': y_val,
        })
        
    # Plot method centroid (Diamond) with bidirectional error bars
    ax_b.errorbar(
        mean_x, mean_y,
        xerr=sd_x, yerr=sd_y,
        fmt='D',
        color=c,
        ecolor=c,
        elinewidth=0.9,
        capsize=2.2,
        capthick=0.8,
        ms=5.0,
        markeredgecolor='white',
        markeredgewidth=0.6,
        zorder=5
    )

# Connect paired seeds between L2+LCR and SPFT
for s_idx in range(3):
    x_l2 = tradeoff_data['l2replay'][0][s_idx]
    y_l2 = tradeoff_data['l2replay'][1][s_idx]
    x_spft = tradeoff_data['spft'][0][s_idx]
    y_spft = tradeoff_data['spft'][1][s_idx]
    ax_b.annotate(
        '',
        xy=(x_spft, y_spft),
        xytext=(x_l2, y_l2),
        arrowprops=dict(
            arrowstyle='->',
            color='#8C959D',
            lw=0.8,
            alpha=0.85,
            shrinkA=3,
            shrinkB=3,
            mutation_scale=6,
        ),
        zorder=3
    )

ax_b.set_xlim(2.768, 2.818)
ax_b.set_ylim(0.58, 0.86)
ax_b.set_xticks([2.77, 2.78, 2.79, 2.80, 2.81])
ax_b.set_xticklabels(['2.77', '2.78', '2.79', '2.80', '2.81'])
ax_b.set_yticks([0.60, 0.65, 0.70, 0.75, 0.80, 0.85])
ax_b.set_yticklabels(['0.60', '0.65', '0.70', '0.75', '0.80', '0.85'])

ax_b.set_xlabel('Held-out text NLL (lower is better $\\leftarrow$)', labelpad=4)
ax_b.set_ylabel('Conditional retention $Q$ ($\\uparrow$)', labelpad=4)
ax_b.set_title('Retention of reference-correct retrieval vs. text adaptation', fontsize=8.5, fontweight='bold', pad=8, color='#1A202C')
ax_b.annotate('b', xy=(0, 1), xycoords='axes fraction', xytext=(-26, 10), textcoords='offset points', fontweight='bold', fontsize=10.0, va='bottom')

# Unified legend placed between Panel A and Panel B
tradeoff_handles = [
    Line2D([], [], marker='D', lw=0, color=COLORS['lcr'], ms=4.2, label='LCR'),
    Line2D([], [], marker='D', lw=0, color=COLORS['l2replay'], ms=4.2, label='L2+LCR'),
    Line2D([], [], marker='D', lw=0, color=COLORS['spft'], ms=4.2, label='SPFT'),
    Line2D([], [], color='#8C959D', lw=0.9, ls='-', label='Seed transition'),
]

fig.legend(
    handles=tradeoff_handles,
    loc='upper center',
    bbox_to_anchor=(0.60, 0.505),
    ncol=4,
    frameon=False,
    fontsize=8.5,
    handletextpad=0.35,
    columnspacing=1.3
)

# Enforce panel alignment and save
fig.canvas.draw()
require_matplotlib_panel_alignment(
    fig,
    json_out=str(OUT_DIR / 'fig2_matched_profile.alignment.json'),
    overlay_svg=str(OUT_DIR / 'fig2_matched_profile.alignment.svg'),
    tolerance_pt=1.5,
    gutter_tolerance_pt=1.5,
    require_panel_labels=True,
    strict=True
)

fig.savefig(OUT_DIR / 'fig2_matched_profile.pdf')
fig.savefig(OUT_DIR / 'fig2_matched_profile.svg')
fig.savefig(OUT_DIR / 'fig2_matched_profile.png', dpi=600)

with (OUT_DIR / 'fig2_matched_profile.source-data.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['panel', 'method', 'seed', 'condition', 'exact_match', 'text_nll', 'conditional_retention_Q'])
    writer.writeheader()
    writer.writerows(csv_rows)

plt.close(fig)
print('Figure 2 redesigned and exported successfully.')
