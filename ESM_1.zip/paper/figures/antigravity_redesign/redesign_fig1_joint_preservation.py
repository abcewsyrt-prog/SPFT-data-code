"""
Figure 1 Redesign: Joint Retrieval and Decay Preservation Across Recurrent Backbones
Answers: Does SPFT jointly retain functional retrieval (Q) while minimizing decay drift (W1)
across different linear recurrent architectures (Mamba-2 130M and RWKV-7 0.4B)?
"""
import csv
import json
import os
import statistics
import sys
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch

# Import panel alignment auditor from nature-figure skills
sys.path.insert(0, '/workspace/.gemini/config/skills/nature-figure/scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment

# Paths
OUT_DIR = Path('/workspace/Desktop/实验/Applied Intelligence/paper/figures/antigravity_redesign')
RES_DIR = Path('/workspace/Desktop/实验/Applied Intelligence/results')

# Load real source data
summary_data = json.loads((RES_DIR / 'revision_v3/summary.json').read_text())
retention_data = json.loads((RES_DIR / 'revision_v3/backbone_conditional_retention.json').read_text())

# Styling constants
plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
    'font.size': 8.5,
    'axes.labelsize': 8.5,
    'xtick.labelsize': 8.5,
    'ytick.labelsize': 8.5,
    'legend.fontsize': 8.5,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.linewidth': 0.65,
    'axes.edgecolor': '#333F48',
    'pdf.fonttype': 42,
    'svg.fonttype': 'none',
})

# Refined publication palette (consistent across all redesigned figures)
COLORS = {
    'vanilla': '#8A929A',   # Slate Gray
    'spec_reg': '#D95F02',  # Warm Amber / Terracotta
    'lcr': '#2B6CB0',       # Scientific Deep Blue
    'spft': '#1B7837',      # Deep Forest Emerald Green
}

LABELS = {
    'vanilla': 'Vanilla',
    'spec_reg': 'SR',
    'lcr': 'LCR',
    'spft': 'SPFT',
}

SEED_MARKERS = ['o', 's', '^']

# Figure setup: standard two-column width 5.25 in, height 3.15 in
fig, axes = plt.subplots(1, 2, figsize=(5.25, 3.15))
fig.subplots_adjust(left=0.12, right=0.98, bottom=0.20, top=0.74, wspace=0.38)

csv_rows = []

configs = [
    {
        'ax': axes[0],
        'arch': 'mamba130',
        'title': 'Mamba-2 130M',
        'letter': 'a',
        'xlim': (-0.01, 0.28),
        'xticks': [0, 0.05, 0.10, 0.15, 0.20, 0.25],
        'xticklabels': ['0.00', '0.05', '0.10', '0.15', '0.20', '0.25'],
    },
    {
        'ax': axes[1],
        'arch': 'rwkv400',
        'title': 'RWKV-7 0.4B',
        'letter': 'b',
        'xlim': (-0.05, 2.05),
        'xticks': [0, 0.5, 1.0, 1.5, 2.0],
        'xticklabels': ['0.0', '0.5', '1.0', '1.5', '2.0'],
    }
]

for cfg in configs:
    ax = cfg['ax']
    arch = cfg['arch']
    
    # Grid lines
    ax.grid(axis='y', color='#E8ECF0', lw=0.5, zorder=0)
    ax.set_axisbelow(True)
    
    arch_data = {}
    for mode in ['vanilla', 'spec_reg', 'lcr', 'spft']:
        xs = summary_data['independent_probes'][arch][mode]['pooled_probe_w1']['values']
        ys = [v['conditional_retention'] for v in retention_data[arch][mode]['values']]
        arch_data[mode] = (xs, ys)
        
        c = COLORS[mode]
        mean_x = statistics.mean(xs)
        mean_y = statistics.mean(ys)
        sd_x = statistics.stdev(xs)
        sd_y = statistics.stdev(ys)
        
        # Plot individual seed points
        for seed_idx, (x_val, y_val) in enumerate(zip(xs, ys)):
            ax.scatter(
                x_val, y_val,
                s=19,
                marker=SEED_MARKERS[seed_idx],
                color=c,
                alpha=0.75,
                edgecolors='none',
                zorder=4
            )
            csv_rows.append({
                'architecture': arch,
                'method': mode,
                'seed': seed_idx,
                'independent_probe_w1': x_val,
                'conditional_retention_Q': y_val,
                'mean_w1': mean_x,
                'sd_w1': sd_x,
                'mean_Q': mean_y,
                'sd_Q': sd_y,
            })
            
        # Plot method centroid (Diamond) with bidirectional error bars
        ax.errorbar(
            mean_x, mean_y,
            xerr=sd_x, yerr=sd_y,
            fmt='D',
            color=c,
            ecolor=c,
            elinewidth=0.9,
            capsize=2.2,
            capthick=0.8,
            ms=4.8,
            markeredgecolor='white',
            markeredgewidth=0.6,
            zorder=5
        )
    
    # Paired trajectory connecting LCR -> SPFT for each seed
    for seed_idx in range(3):
        x_lcr, y_lcr = arch_data['lcr'][0][seed_idx], arch_data['lcr'][1][seed_idx]
        x_spft, y_spft = arch_data['spft'][0][seed_idx], arch_data['spft'][1][seed_idx]
        ax.annotate(
            '',
            xy=(x_spft, y_spft),
            xytext=(x_lcr, y_lcr),
            arrowprops=dict(
                arrowstyle='->',
                color='#7F8A94',
                lw=0.75,
                alpha=0.8,
                shrinkA=3,
                shrinkB=3,
                mutation_scale=6,
            ),
            zorder=3
        )

    # Panel styling
    ax.set_xlim(cfg['xlim'])
    ax.set_ylim(-0.04, 1.04)
    ax.set_xticks(cfg['xticks'])
    ax.set_xticklabels(cfg['xticklabels'])
    ax.set_yticks([0, 0.25, 0.50, 0.75, 1.00])
    ax.set_yticklabels(['0.00', '0.25', '0.50', '0.75', '1.00'])
    
    ax.set_xlabel('Decay distance $W_{\mathrm{ch}}$\n(independent probes)', labelpad=4)
    ax.set_title(cfg['title'], fontsize=8.5, fontweight='bold', pad=8, color='#1A202C')
    
    # Panel letter
    ax.annotate(
        cfg['letter'],
        xy=(0, 1),
        xycoords='axes fraction',
        xytext=(-20, 9),
        textcoords='offset points',
        fontweight='bold',
        fontsize=10.0,
        va='bottom'
    )

axes[0].set_ylabel('Conditional retention $Q$ (retrieval successes)', labelpad=4)
axes[1].set_ylabel('Conditional retention $Q$', labelpad=4)

# Semantic goal badge in Mamba-2 panel
axes[0].text(
    0.015, 0.90,
    'Target: High $Q$, Low $W_{\mathrm{ch}}$',
    fontsize=8.5,
    color='#1B7837',
    fontstyle='italic',
    fontweight='bold',
    zorder=6,
    bbox=dict(boxstyle='square,pad=0.45', facecolor='#E8F5E9', edgecolor='#C8E6C9', lw=0.5, alpha=0.9)
)

# Refined unified legend at top
legend_handles = [
    Line2D([], [], marker='D', lw=0, color=COLORS['vanilla'], ms=4.2, label='Vanilla'),
    Line2D([], [], marker='D', lw=0, color=COLORS['spec_reg'], ms=4.2, label='SR'),
    Line2D([], [], marker='D', lw=0, color=COLORS['lcr'], ms=4.2, label='LCR'),
    Line2D([], [], marker='D', lw=0, color=COLORS['spft'], ms=4.2, label='SPFT'),
    Line2D([], [], color='#7F8A94', lw=0.9, ls='-', label='Seed transition'),
]

fig.legend(
    handles=legend_handles,
    loc='upper center',
    bbox_to_anchor=(0.52, 0.93),
    ncol=5,
    frameon=False,
    handletextpad=0.35,
    columnspacing=1.2,
    fontsize=8.5
)

# Enforce panel alignment and save
fig.canvas.draw()
require_matplotlib_panel_alignment(
    fig,
    json_out=str(OUT_DIR / 'fig1_joint_preservation.alignment.json'),
    overlay_svg=str(OUT_DIR / 'fig1_joint_preservation.alignment.svg'),
    tolerance_pt=1.5,
    gutter_tolerance_pt=1.5,
    require_panel_labels=True,
    strict=True
)

fig.savefig(OUT_DIR / 'fig1_joint_preservation.pdf')
fig.savefig(OUT_DIR / 'fig1_joint_preservation.svg')
fig.savefig(OUT_DIR / 'fig1_joint_preservation.png', dpi=600)

with (OUT_DIR / 'fig1_joint_preservation.source-data.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(csv_rows[0].keys()))
    writer.writeheader()
    writer.writerows(csv_rows)

plt.close(fig)
print('Figure 1 redesigned and exported successfully.')
