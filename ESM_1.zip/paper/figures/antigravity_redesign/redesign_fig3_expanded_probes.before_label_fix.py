"""
Figure 3 Redesign: Independent-Input Decay Preservation Under Equal Training Time
Answers: Does decay-distribution preservation generalize across independently sampled, unseen input
conditions of varying context lengths (64, 256, 1024 tokens) when training computation is equalized?
"""
import csv
import json
import statistics
import sys
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

# Import panel alignment auditor
sys.path.insert(0, '/workspace/.gemini/config/skills/nature-figure/scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment

# Paths
OUT_DIR = Path('/workspace/Desktop/实验/Applied Intelligence/paper/figures/antigravity_redesign')
RES_DIR = Path('/workspace/Desktop/实验/Applied Intelligence/results')
D_EXP = RES_DIR / 'revision_v9/assessment'

# Styling
plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
    'font.size': 8.5,
    'axes.labelsize': 8.5,
    'xtick.labelsize': 8.5,
    'ytick.labelsize': 8.5,
    'legend.fontsize': 8.5,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.linewidth': 0.65,
    'axes.edgecolor': '#333F48',
    'pdf.fonttype': 42,
    'svg.fonttype': 'none',
})

# Colors (consistent with Figure 1 & 2)
COLORS = {
    'lcr': '#2B6CB0',         # Scientific Deep Blue
    'highreplay': '#D95F02',  # Warm Amber / Terracotta (high replay)
    'spft': '#1B7837',        # Deep Emerald Green
}

METHOD_CONFIGS = [
    ('lcr', 'LCR ($p = 0.05$, iso-updates)', COLORS['lcr']),
    ('highreplay', 'LCR ($p = 0.30$, iso-time)', COLORS['highreplay']),
    ('spft', 'SPFT ($p = 0.05$, iso-time)', COLORS['spft']),
]

SEED_MARKERS = ['o', 's', '^']
LENGTHS = [64, 256, 1024]
REGIME_TITLES = ['Natural text\n64 tokens', 'Retrieval context\n256 tokens', 'Retrieval context\n1024 tokens']

# Figure setup: width 5.25 in, height 3.2 in
fig, ax = plt.subplots(figsize=(5.25, 3.2))
fig.subplots_adjust(left=0.13, right=0.97, bottom=0.20, top=0.78)

ax.grid(axis='y', color='#E8ECF0', lw=0.5, zorder=0)
ax.set_axisbelow(True)

csv_rows = []

# Collect data
regime_data = {length: {} for length in LENGTHS}
for mode, label, color in METHOD_CONFIGS:
    for length in LENGTHS:
        seed_vals = []
        for seed in range(3):
            data_file = D_EXP / f'seed{seed}_{mode}_probe_expansion.json'
            raw = json.loads(data_file.read_text())
            batch_vals = [row['w1'] for row in raw['rows'] if row['length'] == length]
            assert len(batch_vals) == 10
            mean_w1 = statistics.mean(batch_vals)
            seed_vals.append(mean_w1)
            csv_rows.append({
                'method': mode,
                'seed': seed,
                'probe_length': length,
                'num_batches': 10,
                'num_inputs': 20,
                'seed_mean_w1': mean_w1,
            })
        regime_data[length][mode] = seed_vals

# Plotting by regime
spft_means = []
lcr_means = []

for i, length in enumerate(LENGTHS):
    # Shaded background column for visual grouping
    ax.axvspan(i - 0.42, i + 0.42, color='#F8FAFC' if i % 2 == 0 else '#FFFFFF', zorder=0, lw=0)
    
    lcr_m = statistics.mean(regime_data[length]['lcr'])
    spft_m = statistics.mean(regime_data[length]['spft'])
    lcr_means.append(lcr_m)
    spft_means.append(spft_m)
    
    for j, (mode, label, color) in enumerate(METHOD_CONFIGS):
        vals = regime_data[length][mode]
        m_val = statistics.mean(vals)
        s_val = statistics.stdev(vals)
        
        # Center x-position for this method
        x_center = i + (j - 1) * 0.23
        
        # Plot individual seeds with jitter
        for s_idx, v in enumerate(vals):
            x_seed = x_center + (s_idx - 1) * 0.04
            ax.scatter(
                x_seed, v,
                s=16,
                marker=SEED_MARKERS[s_idx],
                color=color,
                alpha=0.65,
                zorder=4
            )
            
        # Plot method centroid (Diamond) + SD whiskers
        ax.errorbar(
            x_center, m_val,
            yerr=s_val,
            fmt='D',
            color=color,
            ecolor=color,
            elinewidth=1.0,
            capsize=2.4,
            capthick=0.8,
            ms=4.8,
            markeredgecolor='white',
            markeredgewidth=0.6,
            zorder=5
        )
        
    # Relative reduction badge above SPFT
    reduction_pct = 100 * (lcr_m - spft_m) / lcr_m
    x_spft = i + 0.23
    ax.text(
        x_spft, spft_m + 0.038,
        f'$-{reduction_pct:.1f}\\%$',
        ha='center', va='bottom',
        fontsize=8.5,
        fontweight='bold',
        color='#1B7837',
        zorder=6
    )

# Subtle dashed trendline connecting SPFT means across lengths showing scale-invariance
spft_x = [i + 0.23 for i in range(len(LENGTHS))]
ax.plot(spft_x, spft_means, color='#1B7837', lw=0.9, ls='--', alpha=0.6, zorder=2)

# Subtle dashed trendline connecting LCR means showing increasing drift with context length
lcr_x = [i - 0.23 for i in range(len(LENGTHS))]
ax.plot(lcr_x, lcr_means, color='#2B6CB0', lw=0.9, ls=':', alpha=0.5, zorder=2)

ax.set_xlim(-0.55, 2.55)
ax.set_ylim(0, 0.26)
ax.set_yticks([0, 0.05, 0.10, 0.15, 0.20, 0.25])
ax.set_yticklabels(['0.00', '0.05', '0.10', '0.15', '0.20', '0.25'])
ax.set_xticks([0, 1, 2])
ax.set_xticklabels(REGIME_TITLES, fontsize=8.5, fontweight='medium')

ax.set_ylabel('Decay distance $W_1$ on unseen probes (lower is better $\\leftarrow$)', labelpad=4)
ax.set_title('Decay preservation across independent input conditions at equal training time', fontsize=8.5, fontweight='bold', pad=10, color='#1A202C')

# Panel letter
ax.annotate('a', xy=(0, 1), xycoords='axes fraction', xytext=(-22, 10), textcoords='offset points', fontweight='bold', fontsize=10.0, va='bottom')

# Top Legend
legend_handles = [
    Line2D([], [], marker='D', lw=0, color=COLORS['lcr'], ms=4.2, label='LCR ($p = 0.05$, iso-updates)'),
    Line2D([], [], marker='D', lw=0, color=COLORS['highreplay'], ms=4.2, label='LCR ($p = 0.30$, iso-time)'),
    Line2D([], [], marker='D', lw=0, color=COLORS['spft'], ms=4.2, label='SPFT ($p = 0.05$, iso-time)'),
]

fig.legend(
    handles=legend_handles,
    loc='upper center',
    bbox_to_anchor=(0.54, 0.95),
    ncol=3,
    frameon=False,
    fontsize=8.5,
    handletextpad=0.35,
    columnspacing=1.2
)

# Enforce panel alignment and save
fig.canvas.draw()
require_matplotlib_panel_alignment(
    fig,
    json_out=str(OUT_DIR / 'fig3_expanded_probes.alignment.json'),
    overlay_svg=str(OUT_DIR / 'fig3_expanded_probes.alignment.svg'),
    strict=True
)

fig.savefig(OUT_DIR / 'fig3_expanded_probes.pdf')
fig.savefig(OUT_DIR / 'fig3_expanded_probes.svg')
fig.savefig(OUT_DIR / 'fig3_expanded_probes.png', dpi=600)

with (OUT_DIR / 'fig3_expanded_probes.source-data.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['method', 'seed', 'probe_length', 'num_batches', 'num_inputs', 'seed_mean_w1'])
    writer.writeheader()
    writer.writerows(csv_rows)

plt.close(fig)
print('Figure 3 redesigned and exported successfully.')
