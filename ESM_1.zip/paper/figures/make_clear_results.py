"""One scientific question per figure; complete source observations retained."""
import csv,json,statistics,sys,os
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
sys.path.insert(0,os.environ.get('NATURE_FIGURE_SCRIPTS',str(Path.home()/'.codex/skills/nature-figure/scripts')))
from audit_panel_alignment import require_matplotlib_panel_alignment
R=Path(__file__).resolve().parents[2];D=R/'results';O=Path(__file__).parent
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Helvetica','DejaVu Sans'],'font.size':8,'axes.labelsize':8,'xtick.labelsize':7.5,'ytick.labelsize':7.5,'legend.fontsize':7.5,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65})
B='#315F80';A='#AA704B';G='#52796B'
def save(fig,name,rows,multi=True):
 if multi:
  fig.canvas.draw();require_matplotlib_panel_alignment(fig,json_out=str(O/f'{name}.alignment.json'),overlay_svg=str(O/f'{name}.alignment.svg'),tolerance_pt=1.5,gutter_tolerance_pt=1.5,require_panel_labels=True,strict=True)
 fig.savefig(O/f'{name}.pdf');fig.savefig(O/f'{name}.svg');fig.savefig(O/f'{name}.png',dpi=600);fig.savefig(O/f'{name}.tiff',dpi=600)
 with (O/f'{name}.source-data.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 plt.close(fig)
def label(ax,l,title):
 ax.set_title(title,fontsize=9,pad=10);ax.annotate(l,(0,1),xycoords='axes fraction',xytext=(-17,11),textcoords='offset points',fontweight='bold',fontsize=10,va='bottom');ax.grid(axis='y',color='#E8EAEC',lw=.5);ax.set_axisbelow(True)
# Joint statistical and functional result; observations and centroid, without redundant error/seed encodings.
s=json.loads((D/'revision_v3/summary.json').read_text());q=json.loads((D/'revision_v3/backbone_conditional_retention.json').read_text())
colors={'vanilla':'#929AA2','spec_reg':A,'lcr':B,'spft':G};names={'vanilla':'Vanilla','spec_reg':'SR','lcr':'LCR','spft':'SPFT'}
fig,axes=plt.subplots(1,2,figsize=(5.15,2.95));fig.subplots_adjust(left=.13,right=.98,bottom=.22,top=.76,wspace=.45);rows=[]
for ax,arch,title,l,xmax in zip(axes,['mamba130','rwkv400'],['Mamba-2 130M','RWKV-7 0.4B'],['a','b'],[.3,2.]):
 for m,c in colors.items():
  xs=s['independent_probes'][arch][m]['pooled_probe_w1']['values'];ys=[r['conditional_retention'] for r in q[arch][m]['values']]
  ax.scatter(xs,ys,s=18,color=c,alpha=.55,linewidths=0,zorder=3);ax.scatter(statistics.mean(xs),statistics.mean(ys),s=45,marker='D',color=c,edgecolors='white',linewidths=.6,zorder=4)
  for seed,(x,y) in enumerate(zip(xs,ys)):rows.append(dict(architecture=arch,method=m,seed=seed,independent_probe_w1=x,conditional_retention=y))
 ax.set_xlim(-.008,xmax);ax.set_ylim(-.04,1.04);ax.set_yticks([0,.25,.5,.75,1]);ax.set_xlabel('Independent-probe decay distance');ax.set_ylabel('Conditional retention Q');label(ax,l,title)
fig.legend(handles=[Line2D([],[],marker='D',lw=0,color=c,label=names[m],ms=4) for m,c in colors.items()],loc='upper center',bbox_to_anchor=(.55,1),ncol=4,frameon=False,handlelength=1,columnspacing=1.4)
save(fig,'figure_joint_clear',rows)
# Paired benefit/cost against the validation-selected conventional control.
new=json.loads((D/'revision_v5/matched_analysis.json').read_text());assert new['status']=='passed'
spftq=[r['conditional_retention'] for r in q['mamba130']['spft']['values']];spftnll=[json.loads((D/f'revision_v2/mamba130_seed{i}/spft.json').read_text())['text']['nll'] for i in range(3)]
gain=[100*(x-y) for x,y in zip(spftq,new['conditional_retention']['values'])];cost=[x-y for x,y in zip(spftnll,new['test_nll']['values'])]
fig,axes=plt.subplots(1,2,figsize=(5.15,2.85));fig.subplots_adjust(left=.15,right=.98,bottom=.24,top=.80,wspace=.58)
for ax,vals,c,l,title,xlabel in zip(axes,[gain,cost],[B,A],['a','b'],['Retrieval benefit','Adaptation cost'],['Retention gain (percentage points)','Text NLL change']):
 ax.axvline(0,color='#9AA2A9',lw=.7);ax.scatter(vals,[3,2,1],s=28,color=c,zorder=3);ax.errorbar(statistics.mean(vals),0,xerr=statistics.stdev(vals),fmt='D',color=c,ms=5,lw=1,capsize=3)
 ax.set_yticks([3,2,1,0],['Seed 0','Seed 1','Seed 2','Mean ± SD']);ax.set_ylim(-.6,3.65);ax.set_xlabel(xlabel);label(ax,l,title)
axes[0].set_xlim(-.7,9.2);axes[1].set_xlim(-.003,.019)
rows=[dict(seed=i,retention_gain_percentage_points=gain[i],text_nll_change=cost[i],spft_retention=spftq[i],control_retention=new['conditional_retention']['values'][i],spft_nll=spftnll[i],control_nll=new['test_nll']['values'][i]) for i in range(3)]
save(fig,'figure_matched_effects',rows)
# Controlled intervention: two groups, same path, one response.
sw=json.loads((D/'revision_v3/swaps_corrected/results.json').read_text())['results'];rows=[]
fig,ax=plt.subplots(figsize=(5.15,2.8));fig.subplots_adjust(left=.14,right=.97,bottom=.23,top=.79)
for group,color,name in [('decay',B,'Decay group'),('content',A,'Other parameters')]:
 vals=[]
 for seed in range(3):
  vs=sw[str(seed)]['interpolation'][group];xs=[r['alpha'] for r in vs];ys=[r['recall']['768']['accuracy'] for r in vs];vals.append(ys)
  for a,y in zip(xs,ys):rows.append(dict(group=group,seed=seed,alpha=a,recall=y))
 means=[statistics.mean(v) for v in zip(*vals)];sd=[statistics.stdev(v) for v in zip(*vals)]
 ax.errorbar(xs,means,yerr=sd,color=color,marker='o',ms=3.5,lw=1.3,capsize=2,label=name)
ax.set_ylim(-.03,1.05);ax.set_xlim(-.02,1.02);ax.set_xticks([0,.2,.4,.6,.8,1]);ax.set_xlabel('Interpolation toward adapted parameter group α');ax.set_ylabel('Recall at length 768');ax.grid(axis='y',color='#E8EAEC',lw=.5);ax.set_axisbelow(True)
fig.legend(loc='upper center',bbox_to_anchor=(.55,1),ncol=2,frameon=False,columnspacing=2)
save(fig,'figure_intervention_clear',rows,multi=False)
