"""Joint functional and independent decay preservation; all paired training seeds."""
import csv,json,os,sys,statistics
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
sys.path.insert(0,os.environ['NATURE_FIGURE_SCRIPTS'])
from audit_panel_alignment import require_matplotlib_panel_alignment
R=Path(__file__).resolve().parents[2];D=R/'results/revision_v3';O=Path(__file__).with_name('figure_revision')
s=json.loads((D/'summary.json').read_text());conditional=json.loads((D/'backbone_conditional_retention.json').read_text())
colors={'vanilla':'#8A8F98','spec_reg':'#D55E00','lcr':'#0072B2','spft':'#009E73'};labels={'vanilla':'Vanilla','spec_reg':'SR','lcr':'LCR','spft':'SPFT'};markers=['o','s','^']
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Helvetica','DejaVu Sans'],'font.size':8,'axes.labelsize':8,'xtick.labelsize':7.5,'ytick.labelsize':7.5,'legend.fontsize':7.5,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,'pdf.fonttype':42,'svg.fonttype':'none'})
fig,axes=plt.subplots(1,2,figsize=(5.15,3.3));fig.subplots_adjust(left=.14,right=.98,bottom=.23,top=.70,wspace=.45);rows=[]
for ax,arch,title,xlim,letter in zip(axes,['mamba130','rwkv400'],['Mamba-2 130M','RWKV-7 0.4B'],[(0,.3),(0,2.05)],['a','b']):
 data={}
 for mode in colors:
  xp=s['independent_probes'][arch][mode]['pooled_probe_w1'];yp=conditional[arch][mode];assert xp['n']==3
  x=xp['values'];y=[v['conditional_retention'] for v in yp['values']];data[mode]=(x,y)
  ax.errorbar(statistics.mean(x),statistics.mean(y),xerr=statistics.stdev(x),yerr=statistics.stdev(y),fmt='D',ms=4,color=colors[mode],capsize=2,lw=.85,zorder=3)
  for seed,(xx,yy) in enumerate(zip(x,y)):
   assert 0<=yy<=1 and xx>=0
   ax.scatter(xx,yy,s=23,marker=markers[seed],color=colors[mode],alpha=.85,zorder=4)
   rows.append({'architecture':arch,'mode':mode,'seed':seed,'independent_probe_w1':xx,'retention_given_baseline_correct':yy,'baseline_correct_n':yp['values'][seed]['baseline_hits']})
 for seed in range(3):ax.plot([data[m][0][seed] for m in ['lcr','spft']],[data[m][1][seed] for m in ['lcr','spft']],color='#B0B0B0',lw=.7,zorder=1)
 ax.set_xticks([0,.1,.2,.3] if arch=='mamba130' else [0,.5,1,1.5,2]);ax.set_xlim(*xlim);ax.set_ylim(-.055,1.04);ax.set_yticks([0,.25,.5,.75,1]);ax.set_title(title,fontsize=9,pad=8);ax.set_xlabel('Independent-probe decay\ndistance');ax.grid(axis='y',color='#E8E8E8',lw=.5);ax.set_axisbelow(True)
 ax.annotate(letter,xy=(0,1),xycoords='axes fraction',xytext=(-16,10),textcoords='offset points',fontweight='bold',fontsize=10,va='bottom')
axes[0].set_ylabel('Retention of previously\ncorrect retrievals');axes[1].set_ylabel('Retention of previously\ncorrect retrievals')
method_handles=[Line2D([],[],marker='D',lw=0,color=colors[m],label=labels[m],markersize=4) for m in colors]+[Line2D([],[],color='#B0B0B0',lw=.8,label='Paired LCR/SPFT')]
fig.legend(handles=method_handles,loc='upper center',bbox_to_anchor=(.54,1.005),ncol=5,frameon=False,columnspacing=1.1,handlelength=1.3)
fig.legend(handles=[Line2D([],[],marker=m,lw=0,color='#333333',label='Seed '+str(i),markersize=4) for i,m in enumerate(markers)],loc='upper center',bbox_to_anchor=(.54,.90),ncol=3,frameon=False,columnspacing=1.4,handlelength=1.3)
fig.canvas.draw();require_matplotlib_panel_alignment(fig,json_out=str(O)+'.alignment.json',overlay_svg=str(O)+'.alignment.svg',tolerance_pt=1.5,gutter_tolerance_pt=1.5,require_panel_labels=True,strict=True)
fig.savefig(str(O)+'.pdf');fig.savefig(str(O)+'.svg')
fig.savefig(str(O)+'.png',dpi=600);fig.savefig(str(O)+'.tiff',dpi=600)
with open(str(O)+'.source-data.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('Exported all 24 architecture-method-seed observations and paired links.')
