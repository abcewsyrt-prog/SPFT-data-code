"""SPFT execution diagram and independently validated replay-matched control."""
import csv,json,sys,statistics,os
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
sys.path.insert(0,os.environ.get('NATURE_FIGURE_SCRIPTS',str(Path.home()/'.codex/skills/nature-figure/scripts')))
from audit_panel_alignment import require_matplotlib_panel_alignment
R=Path(__file__).resolve().parents[2]; O=Path(__file__).parent
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Helvetica','DejaVu Sans'],'font.size':8,'axes.labelsize':8,'xtick.labelsize':7.5,'ytick.labelsize':7.5,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
def save(fig,name):
 fig.savefig(O/f'{name}.pdf')
 fig.savefig(O/f'{name}.svg')
 fig.savefig(O/f'{name}.png',dpi=600)
 fig.savefig(O/f'{name}.tiff',dpi=600)
 plt.close(fig)
fig,ax=plt.subplots(figsize=(5.15,4.4));fig.subplots_adjust(0,0,1,1);ax.set_xlim(0,10);ax.set_ylim(0,10);ax.axis('off')
def box(x,y,w,h,text,color='#EEF3F7'):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.05,rounding_size=0.12',facecolor=color,edgecolor='#647585',linewidth=.7));ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=8,linespacing=1.5)
def arrow(a,b):ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=9,color='#506172',linewidth=.85))
box(.35,8.45,9.3,1.05,'Retrieval-trained reference checkpoint  $\\theta_0$\nFixed optimization probe → detached, layerwise sorted reference statistics')
box(.35,5.65,9.3,1.8,'1. Short-context update\nShort-task batch + differentiable pass on the fixed probe\nMinimize  $L_{\mathrm{short}} + \lambda W_{\mathrm{ch}}$  ($\lambda = 1$)', '#EAF5EF')
arrow((5,7.82),(5,7.5))
ax.text(5,7.94,'Initialize $\\theta$ ← $\\theta_0$; retain fixed reference statistics',ha='center',va='center',fontsize=7.5)
box(.35,2.9,9.3,1.65,'2. Additional retrieval update with probability p = 0.05\nRetrieval batch + freshly recomputed probe penalty\nMinimize  $L_{\mathrm{replay}} + \lambda W_{\mathrm{ch}}$', '#EAF5EF');arrow((5,4.95),(5,4.6))
ax.text(5,5.1,'Independent Bernoulli draw after each short update',ha='center',va='center',fontsize=7.5)
arrow((9.72,3.7),(9.72,6.5));ax.text(9.9,5.1,'Repeat',rotation=90,rotation_mode='anchor',fontsize=7.5,ha='center',va='center')
box(.35,.3,9.3,1.45,'3. Evaluation with the original inference graph\nFull-key retrieval E • Conditional retention Q • Text NLL\nDecay distance on independent evaluation probes','#F5F1E8');arrow((5,2.12),(5,1.8))
ax.text(5,2.3,'After the prescribed number of short-task updates',ha='center',va='center',fontsize=7.5)
save(fig,'figure_framework')
summary=json.loads((R/'results/revision_v3/summary.json').read_text());q=json.loads((R/'results/revision_v3/backbone_conditional_retention.json').read_text())
new=json.loads((R/'results/revision_v5/matched_analysis.json').read_text());assert new['status']=='passed'
data={};rows=[]
for mode in ['lcr','l2replay','spft']:
 if mode=='l2replay':vals=[new['conditional_retention']['values'],new['independent_w1']['values'],new['test_nll']['values']]
 else:
  vals=[[v['conditional_retention'] for v in q['mamba130'][mode]['values']],summary['independent_probes']['mamba130'][mode]['pooled_probe_w1']['values'],[json.loads((R/f'results/revision_v2/mamba130_seed{s}/{mode}.json').read_text())['text']['nll'] for s in range(3)]]
 data[mode]=vals
 for s in range(3):rows.append(dict(mode=mode,seed=s,retention=vals[0][s],independent_w1=vals[1][s],text_nll=vals[2][s]))
with (O/'figure_matched_control.source-data.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
fig,axes=plt.subplots(1,3,figsize=(5.15,3.1));fig.subplots_adjust(left=.10,right=.985,bottom=.26,top=.78,wspace=.68)
colors=['#0072B2','#AA6DB0','#009E73'];markers=['o','s','^'];labels=['LCR','L2 +\nLCR','SPFT']
for k,ax in enumerate(axes):
 for seed in range(3):ax.plot(range(3),[data[m][k][seed] for m in data],color='#C7CCD1',lw=.7,zorder=1)
 for i,m in enumerate(data):
  values=data[m][k];ax.errorbar(i,statistics.mean(values),yerr=statistics.stdev(values),fmt='D',color=colors[i],capsize=2,ms=4,lw=.8,zorder=3)
  for seed,v in enumerate(values):ax.scatter(i,v,marker=markers[seed],s=23,facecolors='white',edgecolors=colors[i],linewidth=.9,zorder=4)
 ax.set_xticks(range(3),labels);ax.set_xlim(-.45,2.45);ax.grid(axis='y',color='#E8E8E8',lw=.5);ax.set_axisbelow(True)
 ax.set_title(['Retrieval retained ↑','Decay drift ↓','Adaptation NLL ↓'][k],fontsize=8,pad=13)
 ax.annotate('abc'[k],(0,1),xycoords='axes fraction',xytext=(-12,18),textcoords='offset points',fontweight='bold',fontsize=10)
 axes[k].set_ylim(*[(.55,.9),(.055,.235),(2.765,2.82)][k])
axes[0].set_ylabel('Conditional retention Q');axes[1].set_ylabel('Independent-probe distance');axes[2].set_ylabel('Held-out text NLL')
from matplotlib.lines import Line2D
fig.legend(handles=[Line2D([],[],marker=markers[s],color='#555555',lw=0,label=f'Seed {s}',markerfacecolor='white',markersize=4) for s in range(3)]+[Line2D([],[],marker='D',color='#555555',lw=0,label='Mean ± SD',markersize=4)],loc='upper center',bbox_to_anchor=(.53,1.0),ncol=4,frameon=False,fontsize=7.5,handlelength=1,columnspacing=1)
fig.canvas.draw();require_matplotlib_panel_alignment(fig,json_out=str(O/'figure_matched_control.alignment.json'),overlay_svg=str(O/'figure_matched_control.alignment.svg'),tolerance_pt=1.5,gutter_tolerance_pt=1.5,require_panel_labels=True,strict=True)
save(fig,'figure_matched_control')
