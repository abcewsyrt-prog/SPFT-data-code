import importlib.util,sys,unittest
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'pilot'))
import lrm_pilot as L
from revision3_train import short_batch
class GeneratorProperties(unittest.TestCase):
 def test_every_queried_pair_is_visible(self):
  for length in [32,192,384,768]:
   gen=torch.Generator().manual_seed(9000+length)
   for _ in range(8):
    x,y,d=L.make_mqar(64,length,32,4,gen,'cpu');qp=x.shape[1]-2
    for row,target in zip(x,y):
     q=row[qp];loc=(row[:qp]==q).nonzero().flatten()
     self.assertEqual(len(loc),1);self.assertLess(int(loc[0])+1,qp);self.assertEqual(row[int(loc[0])+1],target)
 def test_unsafe_explicit_position_rejected(self):
  with self.assertRaises(ValueError):L.make_mqar(1,32,32,4,torch.Generator(),'cpu',max_pair_pos=30)
 def test_structured_task_has_conditional_signal(self):
  x=short_batch(4096,torch.Generator().manual_seed(17),'cpu','markov')
  self.assertAlmostEqual(float((x[:,1:]==(x[:,:-1]+1)%4).float().mean()),.85,delta=.005)
  for current in range(4):
   mask=x[:,:-1]==current;targets=x[:,1:][mask]
   self.assertGreater(float((targets==(current+1)%4).float().mean()),.83)
if __name__=='__main__':unittest.main()
