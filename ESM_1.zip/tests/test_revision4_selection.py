"""Validate the planned comparator's selection rule without running training."""
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backbone'))
from revision4_matched_control import select_candidate

class SelectionTests(unittest.TestCase):
    def test_excludes_ineligible_high_recall(self):
        candidates=[{'coefficient':100.,'validation_em':.9,'validation_nll':3.},
                    {'coefficient':10000.,'validation_em':.7,'validation_nll':2.8}]
        self.assertEqual(select_candidate(candidates,2.8)['coefficient'],10000.)

    def test_uses_largest_validation_recall(self):
        candidates=[{'coefficient':100.,'validation_em':.6,'validation_nll':2.8},
                    {'coefficient':10000.,'validation_em':.7,'validation_nll':2.8}]
        self.assertEqual(select_candidate(candidates,2.8)['coefficient'],10000.)

    def test_tie_favors_lower_coefficient(self):
        candidates=[{'coefficient':10000.,'validation_em':.7,'validation_nll':2.8},
                    {'coefficient':100.,'validation_em':.7,'validation_nll':2.8}]
        self.assertEqual(select_candidate(candidates,2.8)['coefficient'],100.)

    def test_no_admissible_candidate_is_explicit(self):
        with self.assertRaises(ValueError):
            select_candidate([{'coefficient':100.,'validation_em':.9,'validation_nll':3.}],2.8)

if __name__=='__main__':unittest.main()
