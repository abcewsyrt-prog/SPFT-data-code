import importlib.util
import math
import unittest
from pathlib import Path
from types import SimpleNamespace
import torch

spec=importlib.util.spec_from_file_location('revision',Path(__file__).resolve().parents[1]/'backbone/revision_experiments.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)


class ToyMixer(torch.nn.Module):
    def __init__(self):
        super().__init__();self.num_heads=2;self.A_log=torch.nn.Parameter(torch.tensor([0.,math.log(2.)]));self.dt_bias=torch.nn.Parameter(torch.tensor([-2.,1.]));self.time_step_limit=(.01,10.);self.in_proj=torch.nn.Linear(2,4,bias=False)
        torch.nn.init.zeros_(self.in_proj.weight)
    def forward(self,x):return self.in_proj(x)


class ToyModel(torch.nn.Module):
    def __init__(self):super().__init__();self.mixer=ToyMixer()
    def forward(self,x,use_cache=False):return SimpleNamespace(logits=self.mixer(x.float()))


class RevisionTests(unittest.TestCase):
    def test_noncontiguous_digit_lookup(self):
        ids=torch.arange(10)*3+2
        x,y,pos=r.make_retrieval(16,32,.5,torch.Generator().manual_seed(91),ids,[41]*100,torch.device('cpu'))
        for i,p in enumerate(pos):self.assertEqual(x[i,p:p+5].tolist(),y[i].tolist())
        self.assertTrue(all(v in ids.tolist() for row in y.tolist() for v in row))

    def test_bias_and_gradient_match_forward_formula(self):
        m=ToyModel();probe=torch.ones(2,7,2)
        got=r.corrected_spectrum(m,probe)[0]
        expected=(math.log(2.)/(torch.exp(m.mixer.A_log)*torch.nn.functional.softplus(m.mixer.dt_bias))).log()
        torch.testing.assert_close(got,expected)
        got.sum().backward();self.assertTrue(torch.all(m.mixer.dt_bias.grad.abs()>0))
        self.assertEqual(len(m.mixer.in_proj._forward_hooks),0)

    def test_bias_clamping(self):
        m=ToyMixer();m.time_step_limit=(.2,.3)
        g=r.mamba_logdecay(m,torch.zeros(1,3,4))
        torch.testing.assert_close(g[0,0],-torch.exp(m.A_log)*torch.tensor([.2,.3]))

    def test_hook_cleanup_after_error(self):
        class Broken(ToyModel):
            def forward(self,*a,**k):raise RuntimeError('expected')
        m=Broken()
        with self.assertRaises(RuntimeError):r.corrected_spectrum(m,torch.ones(1,3,2))
        self.assertEqual(len(m.mixer.in_proj._forward_hooks),0)

    def test_full_key_loss_uses_all_five_targets(self):
        class Perfect(torch.nn.Module):
            def forward(self,x,use_cache=False):
                self.input=x.clone();logits=torch.full((2,12,32),-15.)
                for k in range(5):logits[:,7+k,k+10]=15.
                return SimpleNamespace(logits=logits)
        m=Perfect();context=torch.zeros(2,8,dtype=torch.long);target=torch.arange(10,15).expand(2,-1)
        self.assertLess(float(r.full_key_loss(m,context,target)),1e-4)
        torch.testing.assert_close(m.input[:,8:],target[:,:-1])

    def test_pairing_and_exact_match_not_first_digit(self):
        class Constant(torch.nn.Module):
            def forward(self,x,use_cache=False):
                logits=torch.zeros(x.shape[0],x.shape[1],50);logits[:,:,2]=1
                return SimpleNamespace(logits=logits)
        args=(Constant(),torch.arange(10)*3+2,[41]*100,torch.device('cpu'),128,8,[32],[.5],91)
        a=r.evaluate_keys(*args);b=r.evaluate_keys(*args)
        self.assertEqual(a,b);v=a['32@0.5']
        self.assertEqual(v['full_key_hits'],sum(p==t for p,t in zip(v['predictions'],v['targets'])))
        self.assertLess(v['full_key_exact_match'],v['first_digit_accuracy'])

if __name__=='__main__':unittest.main()
