"""Fresh matched-budget adaptation runs with checkpoint provenance per seed/mode."""
import argparse,copy,hashlib,json,math,random,time
from pathlib import Path
import torch
import torch.nn.functional as F
import lrm_pilot as L
from revision_paired import recall,local,ci


def spectrum(model,probe):
    x=model.emb(probe);out=[]
    for block in model.blocks:
        h=block.norm1(x);rate=F.softplus(block.raw_decay(h))
        # Per-channel mean log retention; retain channel identity until distance.
        out.append((math.log(2.)/rate.mean((0,1)).clamp_min(1e-10)).log().reshape(-1))
        x=block(x)
    return out


def distance(a,b):return torch.stack([(x.sort().values-y.sort().values).abs().mean() for x,y in zip(a,b)]).mean()


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pre',required=True);ap.add_argument('--out',required=True);ap.add_argument('--seeds',default='0,1,2');ap.add_argument('--steps',type=int,default=3000);ap.add_argument('--batch',type=int,default=32);ap.add_argument('--n',type=int,default=1024);ap.add_argument('--modes',default='vanilla,lcr,spec_reg,spft,l2sp,freeze_decay,restore_decay');ap.add_argument('--lambda-spec',type=float,default=1.);ap.add_argument('--lambda-l2',type=float,default=1.)
    a=ap.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True);device=torch.device('cuda' if torch.cuda.is_available() else 'cpu');torch.set_num_threads(4)
    if device.type=='cuda':torch.backends.cuda.matmul.allow_tf32=True
    pre=torch.load(a.pre,map_location='cpu');model=L.TinyLRM(32,128,3,4,32,2048).to(device)
    manifest=vars(a).copy();manifest.update({'schema':'toy-training-v2','pre_sha256':hashlib.sha256(Path(a.pre).read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'torch':torch.__version__,'device':torch.cuda.get_device_name() if device.type=='cuda' else 'cpu','replication_unit':'independent adaptation seeds conditional on one fixed pretrained checkpoint','budget':'equal short-task updates; replay updates are additional and separately counted','spectrum':'per-channel mean log-retention, layer-average log-half-life W1','test_seed':81917})
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    probe=L.make_mqar(8,192,32,4,torch.Generator().manual_seed(12301),device)[0];model.load_state_dict(pre)
    with torch.no_grad():ref=[x.detach() for x in spectrum(model,probe)]
    def evaluate(m):
        return {'recall':{str(n):recall(m,n,a.n,16,81917,device) for n in [192,384,768]},'local':local(m,a.n,32,81591,device),'spectral_w1':float(distance(spectrum(m,probe),ref))}
    with torch.no_grad():base=evaluate(model)
    (out/'baseline.json').write_text(json.dumps(base,indent=2));print('BASE', {k:v['accuracy'] for k,v in base['recall'].items()},flush=True)
    for seed in map(int,a.seeds.split(',')):
        for mode in a.modes.split(','):
            path=out/('seed{}_{}.json'.format(seed,mode))
            if path.exists():continue
            if mode=='restore_decay':
                statepath=out/('seed{}_vanilla.pt'.format(seed))
                model=L.TinyLRM(32,128,3,4,32,2048).to(device);model.load_state_dict(torch.load(statepath,map_location=device))
                with torch.no_grad():
                    for name,param in model.named_parameters():
                        if name.endswith(('A_log','g_proj.weight')):param.copy_(pre[name])
                with torch.no_grad():r=evaluate(model)
                r.update({'seed':seed,'mode':mode,'training':'copy-back from same seed vanilla; no extra training'})
                path.write_text(json.dumps(r,indent=2));print('DONE',seed,mode,{k:v['accuracy'] for k,v in r['recall'].items()},r['local']['accuracy'],flush=True);continue
            torch.manual_seed(seed);model=L.TinyLRM(32,128,3,4,32,2048).to(device);model.load_state_dict(pre)
            if mode=='freeze_decay':L.set_decay_trainable(model,False)
            opt=torch.optim.AdamW(L.build_param_groups(model,.01),lr=1e-4)
            short_gen=torch.Generator().manual_seed(seed+2001);replay_gen=torch.Generator().manual_seed(seed+2002);choose_gen=torch.Generator().manual_seed(seed+2003)
            l2ref={k:v.to(device) for k,v in pre.items()} if mode=='l2sp' else None
            model.train();t=time.perf_counter();replays=0
            if device.type=='cuda':torch.cuda.reset_peak_memory_stats()
            for step in range(a.steps):
                opt.zero_grad(set_to_none=True);x=L.make_local_task(a.batch,48,32,short_gen,device);logits=model(x[:,:-1]);loss=F.cross_entropy(logits.reshape(-1,32),x[:,1:].reshape(-1))
                if mode in ('spec_reg','spft'):loss=loss+a.lambda_spec*distance(spectrum(model,probe),ref)
                if mode=='l2sp':loss=loss+a.lambda_l2*sum((param-l2ref[name]).square().sum() for name,param in model.named_parameters())/sum(p.numel() for p in model.parameters())
                loss.backward();torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],1.);opt.step()
                if mode in ('lcr','spft') and float(torch.rand(1,generator=choose_gen))<.05:
                    opt.zero_grad(set_to_none=True);x,y,_=L.make_mqar(a.batch,192,32,4,replay_gen,device);replay=F.cross_entropy(model(x)[:,-2],y)
                    if mode=='spft':replay=replay+a.lambda_spec*distance(spectrum(model,probe),ref)
                    replay.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step();replays+=1
                if (step+1)%500==0:print('TRAIN',seed,mode,step+1,round(time.perf_counter()-t,1),flush=True)
            if device.type=='cuda':torch.cuda.synchronize()
            training={'seconds':time.perf_counter()-t,'short_updates':a.steps,'replay_updates':replays,'batch':a.batch,'peak_memory_bytes':torch.cuda.max_memory_allocated() if device.type=='cuda' else None}
            model.eval()
            with torch.no_grad():r=evaluate(model)
            r.update({'seed':seed,'mode':mode,'training':training,'pre_sha256':manifest['pre_sha256']})
            path.write_text(json.dumps(r,indent=2));torch.save(model.state_dict(),out/('seed{}_{}.pt'.format(seed,mode)))
            print('DONE',seed,mode,{k:v['accuracy'] for k,v in r['recall'].items()},r['local']['accuracy'],training,flush=True)
            del model,opt,l2ref
            if device.type=='cuda':torch.cuda.empty_cache()
    print('ALL_COMPLETE',flush=True)

if __name__=='__main__':main()
