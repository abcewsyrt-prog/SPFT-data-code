"""
Pilot: Memory-Drift in fine-tuned linear recurrent models.

受控合成实验，验证三条假设：
  H1  微调会系统性改变预训练学到的对数时间尺度分布（衰减谱漂移）
  H2  微调后领域内短上下文任务变好，但长程召回显著下降（隐形失效）
  H4  冻结衰减参数 / 谱正则 能在几乎不损失领域内表现的前提下保住长程召回

模型：最小可用的门控线性注意力 LM（GLA 风格，逐通道数据依赖 log-decay），
      衰减参数化方式刻意对齐 RWKV-7 的 w / Mamba-2 的 A_log+dt。
"""

import argparse
import json
import math
import os
import time

import torch
import torch.nn as nn
import torch.nn.functional as F

# --------------------------------------------------------------------------------------
# 基础组件
# --------------------------------------------------------------------------------------


class RMSNorm(nn.Module):
    def __init__(self, d, eps=1e-5):
        super().__init__()
        self.w = nn.Parameter(torch.ones(d))
        self.eps = eps

    def forward(self, x):
        n = x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)
        return n * self.w


def chunkwise_gated_linear_attn(q, k, v, g, chunk=64):
    """
    门控线性注意力（逐通道 log-decay），chunkwise 并行形式。
      S_t = exp(g_t) * S_{t-1} + k_t v_t^T
      o_t = S_t^T q_t
    张量形状：q,k,v,g -> (B, H, T, D) ；g 为 log-decay（<=0）
    返回 o: (B, H, T, D)
    """
    B, H, T, D = q.shape
    pad = (chunk - T % chunk) % chunk
    if pad:
        q = F.pad(q, (0, 0, 0, pad))
        k = F.pad(k, (0, 0, 0, pad))
        v = F.pad(v, (0, 0, 0, pad))
        g = F.pad(g, (0, 0, 0, pad))
    Tp = T + pad
    n_chunk = Tp // chunk

    q = q.view(B, H, n_chunk, chunk, D)
    k = k.view(B, H, n_chunk, chunk, D)
    v = v.view(B, H, n_chunk, chunk, D)
    g = g.view(B, H, n_chunk, chunk, D)

    # chunk 内累积 log-decay
    G = g.cumsum(dim=3)                                   # (B,H,C,chunk,D)，非增

    # 因果掩码：causal[t, s] = True 当且仅当 t >= s
    idx = torch.arange(chunk, device=q.device)
    causal = (idx.unsqueeze(1) >= idx.unsqueeze(0)).float()           # (chunk, chunk)
    causal = causal.view(1, 1, 1, chunk, chunk, 1)

    # 逐通道衰减权重 decay[t,s,d] = exp(G_t[d] - G_s[d])
    # g<=0 => G 非增 => 对 s<=t 有 G_t-G_s<=0，对 s>t 有 >=0。
    # 因此 clamp(max=0) 后再乘因果掩码，既保证数值安全（不会 exp 爆炸）又正确置零未来项。
    Dmat = G.unsqueeze(4) - G.unsqueeze(3)                # (B,H,C,chunk,chunk,D)
    decay = torch.exp(Dmat.clamp(max=0.0)) * causal

    # 关键：通道维 d 不能被提前求和——它是衰减的载体。
    qk = q.unsqueeze(4) * k.unsqueeze(3)                  # (B,H,C,chunk,chunk,D)
    w = qk * decay
    o_intra = torch.einsum("b h c t s d, b h c s e -> b h c t e", w, v)

    # chunk 间状态传递
    chunk_decay = torch.exp(G[:, :, :, -1, :])                        # 整个 chunk 的总衰减 (B,H,C,D)
    kd = k * torch.exp(G[:, :, :, -1:, :] - G)                        # 相对 chunk 末端的衰减
    U = torch.einsum("b h c t d, b h c t e -> b h c d e", kd, v)      # chunk 贡献 (B,H,C,D,D)

    S = torch.zeros(B, H, D, D, device=q.device, dtype=q.dtype)
    o_inter = torch.empty_like(o_intra)
    decay_offsets = torch.exp(G)                                      # (B,H,C,chunk,D)
    for c in range(n_chunk):
        o_inter[:, :, c] = torch.einsum("b h t d, b h d e -> b h t e", q[:, :, c] * decay_offsets[:, :, c], S)
        S = S * chunk_decay[:, :, c].unsqueeze(-1) + U[:, :, c]

    o = (o_intra + o_inter).reshape(B, H, Tp, D)[:, :, :T]
    return o


def sequential_gated_linear_attn(q, k, v, g):
    """参考实现（逐时间步），仅用于数值校验。"""
    B, H, T, D = q.shape
    S = torch.zeros(B, H, D, D, device=q.device, dtype=q.dtype)
    outs = []
    for t in range(T):
        a = torch.exp(g[:, :, t])                       # (B,H,D)
        S = a.unsqueeze(-1) * S + torch.einsum("b h d, b h e -> b h d e", k[:, :, t], v[:, :, t])
        outs.append(torch.einsum("b h d e, b h d -> b h e", S, q[:, :, t]))
    return torch.stack(outs, dim=2)


class GatedLinearBlock(nn.Module):
    """一层：GLA(逐通道数据依赖衰减) + 门控 + FFN。衰减参数 = A_log + W_g(x)。

    注意 A_log 的初始化：若置零，则 softplus(0)=0.693 -> a=exp(-0.693)=0.5，
    即每步衰减一半、有效记忆仅约 1.4 个 token，模型学不会长程依赖
    （这正是 PoST / Stuffed Mamba 指出的「衰减谱塌缩」）。
    因此这里按**几何间隔**铺开初始衰减率，模拟一个训练良好的谱形。
    """

    def __init__(self, d_model, n_head, d_head, ffn_mult=2, rate_hi=0.5, rate_lo=2e-3):
        super().__init__()
        self.h, self.dh = n_head, d_head
        inner = n_head * d_head
        self.norm1 = RMSNorm(d_model)
        self.q_proj = nn.Linear(d_model, inner, bias=False)
        self.k_proj = nn.Linear(d_model, inner, bias=False)
        self.v_proj = nn.Linear(d_model, inner, bias=False)
        self.o_proj = nn.Linear(inner, d_model, bias=False)
        self.g_proj = nn.Linear(d_model, inner, bias=False)   # 数据依赖动态衰减
        self.o_gate = nn.Linear(d_model, inner, bias=False)

        rates = torch.logspace(math.log10(rate_hi), math.log10(rate_lo), d_head)
        init = torch.log(torch.expm1(rates))                  # softplus 的逆
        self.A_log = nn.Parameter(init.unsqueeze(0).repeat(n_head, 1).contiguous())

        self.norm2 = RMSNorm(d_model)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, ffn_mult * d_model, bias=False),
            nn.SiLU(),
            nn.Linear(ffn_mult * d_model, d_model, bias=False),
        )
        self.decay_params = [self.A_log, self.g_proj.weight]

    def raw_decay(self, x):
        """返回 raw = A_log + W_g x，随后 log_decay = -softplus(raw)。"""
        g = self.g_proj(x).view(*x.shape[:-1], self.h, self.dh)
        return self.A_log.view(1, 1, self.h, self.dh) + g

    def forward(self, x):
        B, T, _ = x.shape
        h = self.norm1(x)
        q = self.q_proj(h).view(B, T, self.h, self.dh).transpose(1, 2)
        k = self.k_proj(h).view(B, T, self.h, self.dh).transpose(1, 2)
        v = self.v_proj(h).view(B, T, self.h, self.dh).transpose(1, 2)
        g = -F.softplus(self.raw_decay(h)).transpose(1, 2)      # (B,H,T,D) log-decay<=0
        o = chunkwise_gated_linear_attn(q, k, v, g)
        o = o.transpose(1, 2).reshape(B, T, self.h * self.dh)
        o = o * F.silu(self.o_gate(h))
        x = x + self.o_proj(o)
        x = x + self.ffn(self.norm2(x))
        return x


class TinyLRM(nn.Module):
    def __init__(self, vocab, d_model=128, n_layer=3, n_head=4, d_head=32, max_len=2048):
        super().__init__()
        self.emb = nn.Embedding(vocab, d_model)
        self.blocks = nn.ModuleList(
            [GatedLinearBlock(d_model, n_head, d_head) for _ in range(n_layer)]
        )
        self.norm_f = RMSNorm(d_model)
        self.head = nn.Linear(d_model, vocab, bias=False)
        self.head.weight = self.emb.weight
        self.max_len = max_len

    def forward(self, idx):
        x = self.emb(idx)
        for b in self.blocks:
            x = b(x)
        return self.head(self.norm_f(x))

    # ---------------- 诊断工具 ----------------

    @torch.no_grad()
    def decay_stats(self, idx, n_batch=8):
        """逐层统计有效衰减率 softplus(raw) 的分布与有效记忆视界 H_eff。"""
        self.eval()
        rates = []
        x = self.emb(idx[:n_batch])
        for blk in self.blocks:
            h = blk.norm1(x)
            raw = blk.raw_decay(h)                    # (B,T,H,dh)
            rate = F.softplus(raw)                    # >0，单位：每 token 的衰减率
            rates.append(rate.reshape(-1).float().cpu())
            x = blk(x)
        out = {}
        for i, r in enumerate(rates):
            tau = 1.0 / r.clamp_min(1e-8)             # 通道时间常数
            out[f"layer{i}"] = {
                "mean_rate": r.mean().item(),
                "median_H_eff_tokens": (math.log(2) / r.median().item()),
                "log_tau_mean": tau.log().mean().item(),
                "log_tau_std": tau.log().std().item(),
                "p90_tau": tau.quantile(0.9).item(),
                "p10_tau": tau.quantile(0.1).item(),
                "p99_tau": tau.quantile(0.99).item(),
                "max_tau": tau.max().item(),
                # 长记忆尾部：半衰期 > 64 token 的通道占比。中位数半衰期会被最快的那些通道
                # 拉低，而真正承担长程召回的是慢通道，所以这个比例是更贴切的容量指标。
                "long_mass_tau_gt64": (tau > 64).float().mean().item(),
            }
        # 全局 H_eff（所有层所有通道混合）
        allr = torch.cat(rates)
        alltau = 1.0 / allr.clamp_min(1e-8)
        out["global"] = {
            "median_H_eff_tokens": math.log(2) / allr.median().item(),
            "mean_rate": allr.mean().item(),
            "log_tau_mean": alltau.log().mean().item(),
            "p95_tau": alltau.quantile(0.95).item(),
            "p99_tau": alltau.quantile(0.99).item(),
            "long_mass_tau_gt64": (alltau > 64).float().mean().item(),
            "long_mass_tau_gt256": (alltau > 256).float().mean().item(),
        }
        return out, [r for r in rates]


def spectral_w1(r1, r2):
    """两组衰减率的一维 1-Wasserstein 距离（作用在 log-tau 上，量纲无关）。"""
    a = (1.0 / r1.clamp_min(1e-8)).log().sort().values
    b = (1.0 / r2.clamp_min(1e-8)).log().sort().values
    n = min(a.numel(), b.numel())
    a = a[torch.linspace(0, a.numel() - 1, n).long()]
    b = b[torch.linspace(0, b.numel() - 1, n).long()]
    return (a - b).abs().mean().item()


# --------------------------------------------------------------------------------------
# 数据
# --------------------------------------------------------------------------------------


def _sample_positions(n, max_pos, gap, gen):
    """在不重叠的前提下采样 n 个位置（两两间隔 >= gap）。"""
    for _ in range(200):
        cand = torch.randperm(max_pos, generator=gen)[:n].sort().values
        if n < 2 or (cand[1:] - cand[:-1] >= gap).all():
            return cand
    step = max(gap, max_pos // max(n, 1))
    return torch.arange(0, min(n * step, max_pos), step)[:n]


def make_mqar(batch, seq_len, vocab, n_pairs, gen, device, max_pair_pos=None):
    """多查询联想召回（MQAR），作为下一 token 预测任务。

    关键：**键 / 值 / 填充使用三个互不相交的符号集**，否则查询有歧义、任务不可学。
      vocab=32 -> 键 [0,8)  值 [8,16)  填充 [16,32)
    序列：[ 若干 (键,值) 对 + 填充 ... ] [查询键] -> 目标：对应值
    损失只算最后一个位置。
    """
    n_sym = vocab // 4
    KEY_LO, VAL_LO, FILL_LO = 0, n_sym, 2 * n_sym
    ctx_len = seq_len - 2
    if max_pair_pos is None:
        max_pair_pos = max(1, ctx_len - 1)

    x = torch.randint(FILL_LO, vocab, (batch, ctx_len), generator=gen)   # 只用填充符号
    tgt = torch.zeros(batch, dtype=torch.long)
    dist = torch.zeros(batch, dtype=torch.long)
    for b in range(batch):
        pos = _sample_positions(n_pairs, max_pair_pos, 3, gen)
        keys = torch.randperm(n_sym, generator=gen)[:n_pairs]            # 键互不重复
        vals = torch.randint(VAL_LO, VAL_LO + n_sym, (n_pairs,), generator=gen)
        for p, kk, vv in zip(pos.tolist(), keys.tolist(), vals.tolist()):
            if p + 1 < ctx_len:
                x[b, p] = kk
                x[b, p + 1] = vv
        j = int(torch.randint(0, n_pairs, (1,), generator=gen).item())
        qk = int(keys[j])
        x[b, ctx_len - 1] = qk                                          # 查询键置于末尾
        tgt[b] = int(vals[j])
        loc = (x[b, : ctx_len - 1] == qk).nonzero()
        dist[b] = (ctx_len - 1) - (int(loc[-1].item()) if loc.numel() else 0)

    inp = torch.cat([x, torch.zeros(batch, 1, dtype=torch.long)], dim=1).to(device)
    return inp, tgt.to(device), dist


def make_local_task(batch, seq_len, vocab, gen, device):
    """短上下文领域任务：一阶马尔可夫链（只需 ~1-2 步记忆）。"""
    k = 4
    trans = torch.zeros(vocab, vocab)
    trans[:, :k] = 1.0 / k                                   # 下一个 token 只依赖当前 token 属于哪个簇
    x = torch.zeros(batch, seq_len, dtype=torch.long)
    x[:, 0] = torch.randint(0, vocab, (batch,), generator=gen)
    for t in range(1, seq_len):
        probs = trans[x[:, t - 1]]
        x[:, t] = torch.multinomial(probs, 1, generator=gen).squeeze(-1)
    return x.to(device)


def make_gap_task(batch, seq_len, vocab, gap, gen, device):
    """间隔回看任务（可控记忆需求）：在序列末尾位置，要求模型输出 **gap 步之前** 的那个 token。

    要解这个任务，模型必须保留恰好 `gap` 步的精确记忆 —— 于是 `gap` 就是
    「微调数据本身要求的记忆深度」。这是检验 H3（梯度局部性）的自变量：
    域内微调数据要求的记忆越短，长程召回被破坏得越狠。

    gap=0 表示恒等（直接输出当前 token，零记忆）；gap=1 只需 1 步。
    """
    x = torch.randint(1, vocab, (batch, seq_len), generator=gen)
    tgt = x[:, seq_len - 2 - max(gap, 1)].clone()
    return x.to(device), tgt.to(device)


# --------------------------------------------------------------------------------------
# 训练
# --------------------------------------------------------------------------------------


def effective_rates(model, probe_x):
    """在固定探针批次上取**实际生效**的衰减率谱 softplus(A_log + W_g·norm(x))。

    注意：有效衰减依赖上游表示，所以即使冻结 A_log 与 W_g，
    只要前层在变，有效谱仍会漂移 —— 这正是「冻结」不够、
    必须正则化有效谱的原因。
    """
    x = model.emb(probe_x)
    rates = []
    for blk in model.blocks:
        h = blk.norm1(x)
        rates.append(F.softplus(blk.raw_decay(h).reshape(-1)).float())
        x = blk(x)
    return rates


def decay_regularizer(model, probe_x, ref_rates, lam):
    """SPFT-SR：把**有效衰减谱**的 log-tau 分布拉回参考分布（1-Wasserstein，可微）。"""
    if lam <= 0 or ref_rates is None:
        return torch.zeros((), device=next(model.parameters()).device)
    cur_rates = effective_rates(model, probe_x)
    loss = torch.zeros((), device=cur_rates[0].device)
    for cur, ref in zip(cur_rates, ref_rates):
        ref = ref.to(cur.device)
        ref_sorted = ref.sort().values
        cur_sorted = cur.sort().values
        n = min(ref_sorted.numel(), cur_sorted.numel())
        jdx = torch.linspace(0, cur_sorted.numel() - 1, n).long()
        kdx = torch.linspace(0, ref_sorted.numel() - 1, n).long()
        # 在 log 时间尺度上比较（量纲无关），1-Wasserstein == 排序后的 L1
        a = (1.0 / cur_sorted[jdx].clamp_min(1e-8)).log()
        b = (1.0 / ref_sorted[kdx].clamp_min(1e-8)).log()
        loss = loss + (a - b).abs().mean()
    return lam * loss / len(cur_rates)


def set_decay_trainable(model, flag):
    for blk in model.blocks:
        for p in blk.decay_params:
            p.requires_grad_(flag)


def build_param_groups(model, wd=0.01):
    """衰减参数绝不做 weight decay。

    AdamW 的 weight decay 会把 A_log 往 0 拉，而 A_log=0 意味着
    softplus(0)=0.693、每步衰减一半 —— 等于主动摧毁长程记忆。
    这类 1 维/衰减参数必须 wd=0。
    """
    decay_p, other_p = [], []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if name.endswith("A_log") or name.endswith("g_proj.weight") or p.ndim <= 1:
            decay_p.append(p)
        else:
            other_p.append(p)
    groups = []
    if other_p:
        groups.append({"params": other_p, "weight_decay": wd})
    if decay_p:
        groups.append({"params": decay_p, "weight_decay": 0.0})
    return groups


def evaluate_mqar_by_distance(model, vocab, seq_len, n_pairs, device, gen,
                             n_batch=64, n_rounds=6):
    """按查询距离分桶统计召回率 —— 这是 H2「短程还好、长程崩掉」的直接证据。"""
    buckets = [(0, 32), (32, 64), (64, 128), (128, 10 ** 9)]
    hits = {b: 0 for b in buckets}
    tot = {b: 0 for b in buckets}
    model.eval()
    with torch.no_grad():
        for _ in range(n_rounds):
            inp, tgt, dist = make_mqar(n_batch, seq_len, vocab, n_pairs, gen, device)
            correct = (model(inp)[:, -2, :].argmax(-1) == tgt)
            for b in buckets:
                m = (dist >= b[0]) & (dist < b[1])
                hits[b] += int(correct[m].sum())
                tot[b] += int(m.sum())
    return {f"{b[0]}-{'inf' if b[1] > 10**8 else b[1]}": (hits[b] / tot[b] if tot[b] else float("nan"))
            for b in buckets}


def evaluate_mqar(model, vocab, lengths, n_pairs, device, gen, n_batch=32, n_rounds=4):
    model.eval()
    res = {}
    for L in lengths:
        accs = []
        with torch.no_grad():
            for _ in range(n_rounds):
                inp, tgt, _ = make_mqar(n_batch, L, vocab, n_pairs, gen, device)
                logits = model(inp)[:, -2, :]
                accs.append((logits.argmax(-1) == tgt).float().mean().item())
        res[L] = sum(accs) / len(accs)
    return res


def evaluate_local(model, vocab, seq_len, device, gen, n_batch=32, n_rounds=4):
    model.eval()
    accs = []
    with torch.no_grad():
        for _ in range(n_rounds):
            x = make_local_task(n_batch, seq_len, vocab, gen, device)
            logits = model(x[:, :-1])
            pred = logits.argmax(-1)
            accs.append((pred == x[:, 1:]).float().mean().item())
    return sum(accs) / len(accs)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps_pretrain", type=int, default=3000)
    ap.add_argument("--steps_finetune", type=int, default=600)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--epochs", type=int, default=1)
    ap.add_argument("--ft_lr", type=float, default=1e-4)
    ap.add_argument("--modes", type=str,
                    default="vanilla,freeze_decay,restore_decay,spec_reg,lcr,spft")
    ap.add_argument("--spec_lambda", type=float, default=1.0)
    ap.add_argument("--lcr_prob", type=float, default=0.05,
                    help="长上下文回放比例：每个微调步以该概率替换为长程 MQAR 批次（无标注）")
    ap.add_argument("--task_gap", type=int, default=-1,
                    help="域内微调任务的记忆需求（步）。-1 = 用一阶马尔可夫链（约 1 步）；"
                         ">=0 时改用「间隔回看」任务，要求恰好 gap 步记忆")
    ap.add_argument("--grad_probe", action="store_true",
                    help="在微调第 0 步打印衰减/内容两组参数的梯度范数（H3 的证据）")
    ap.add_argument("--eval_every", type=int, default=500,
                    help="微调过程中每 N 步记录一次漂移曲线（0 = 关闭）")
    ap.add_argument("--preexpand", type=int, default=0,
                    help="可选：冻结原衰减参数并新增一组慢通道（容量扩容），预留")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--device", type=str, default="auto")
    ap.add_argument("--skip_pretrain", action="store_true",
                    help="跳过预训练，直接复用 results/pilot_pretrained.pt（用于只重跑微调模式）")
    ap.add_argument("--out", type=str, default="results/pilot_metrics.json")
    args = ap.parse_args()

    if args.device == "auto":
        if torch.cuda.is_available():
            dev_name = "cuda"
        elif getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            dev_name = "mps"
        else:
            dev_name = "cpu"
    else:
        dev_name = args.device
    device = torch.device(dev_name)
    if dev_name == "cuda":
        # 逐通道 decay 的 intra-chunk 权重是 (B,H,C,L,L,D)，开启 TF32 更稳更快
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
    torch.manual_seed(args.seed)
    gen = torch.Generator().manual_seed(args.seed)

    VOCAB = 32
    PRETRAIN_CKPT = "results/pilot_pretrained.pt"
    PRE_LEN = 192          # 预训练序列长度
    FT_LEN = 48            # 微调序列长度（短上下文"领域"数据）
    N_PAIRS = 4
    EVAL_LENS = [PRE_LEN, PRE_LEN * 2, PRE_LEN * 4]

    print(f"device={device}  vocab={VOCAB}  pre_len={PRE_LEN}  ft_len={FT_LEN}")

    # ---------------- 阶段 1：预训练（长程召回） ----------------
    model = TinyLRM(VOCAB, d_model=128, n_layer=3, n_head=4, d_head=32, max_len=2048).to(device)
    print("params:", sum(p.numel() for p in model.parameters()))
    if args.skip_pretrain:
        model.load_state_dict(torch.load(PRETRAIN_CKPT, map_location=device))
        print("  [pre] 复用已有 checkpoint:", PRETRAIN_CKPT)
    else:
        opt = torch.optim.AdamW(build_param_groups(model, 0.01), lr=args.lr, betas=(0.9, 0.95))
        sched = torch.optim.lr_scheduler.OneCycleLR(
            opt, max_lr=args.lr, total_steps=args.steps_pretrain, pct_start=0.1
        )

    t0 = time.time()
    for step in range(0 if args.skip_pretrain else args.steps_pretrain):
        inp, tgt, _ = make_mqar(64, PRE_LEN, VOCAB, N_PAIRS, gen, device)
        # MQAR 的标准训练目标：只在"回答"位置计算损失。
        # 用全序列损失会把信号稀释到 1/T（填充符号本身就有 2.77 nat 的熵），学不动。
        logits = model(inp)[:, -2, :]
        loss = F.cross_entropy(logits, tgt)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if step % 500 == 0 or step == args.steps_pretrain - 1:
            msg = f"  [pre] step {step:5d} loss {loss.item():.4f}  ({time.time()-t0:.0f}s)"
            if step % 1000 == 0:
                with torch.no_grad():
                    _in, _tg, _ = make_mqar(64, PRE_LEN, VOCAB, N_PAIRS, gen, device)
                    _acc = (model(_in)[:, -2, :].argmax(-1) == _tg).float().mean().item()
                msg += f"  recall@train_len {_acc:.3f}"
            print(msg)

    base_recall = evaluate_mqar(model, VOCAB, EVAL_LENS, N_PAIRS, device, gen)
    base_bydist = evaluate_mqar_by_distance(model, VOCAB, PRE_LEN, N_PAIRS, device, gen)
    base_local = evaluate_local(model, VOCAB, FT_LEN, device, gen)
    probe_base = make_mqar(8, PRE_LEN, VOCAB, N_PAIRS, gen, device)[0]   # 全局固定探针批次
    base_stats, base_rates = model.decay_stats(probe_base)
    print("  [pre] MQAR recall:", {k: round(v, 3) for k, v in base_recall.items()})
    print("  [pre] MQAR recall by distance:",
          {k: (round(v, 3) if v == v else None) for k, v in base_bydist.items()})
    print("  [pre] local acc:", round(base_local, 3))
    print("  [pre] H_eff(tokens):", round(base_stats["global"]["median_H_eff_tokens"], 1))

    torch.save(model.state_dict(), PRETRAIN_CKPT)

    # ---------------- 阶段 2：微调（短上下文领域任务）各类模式 ----------------
    summary = {
        "pretrain": {
            "mqar_recall": base_recall,
            "mqar_recall_by_distance": base_bydist,
            "local_acc": base_local,
            "decay": base_stats,
        },
        "runs": {},
    }

    for mode in args.modes.split(","):
        torch.manual_seed(args.seed + 1)     # 微调数据/初始扰动一致
        m = TinyLRM(VOCAB, d_model=128, n_layer=3, n_head=4, d_head=32, max_len=2048).to(device)
        m.load_state_dict(torch.load(PRETRAIN_CKPT, map_location=device))
        probe_x = probe_base                                          # 与基准使用同一探针批次

        # ---- 组件开关（SPFT = DF(可选) + SR + LCR；其余为对照） ----
        use_sr = mode in ("spec_reg", "spft")        # 谱正则
        use_lcr = mode in ("lcr", "spft")            # 长上下文回放
        do_restore = mode == "restore_decay"         # 事后把衰减参数还原（免训练基线）

        ref_rates = None
        if mode == "freeze_decay":
            set_decay_trainable(m, False)
        if use_sr:
            # 参考谱 = 微调开始前的**有效**衰减谱（固定探针批次上测得）。
            # 注意不能只冻结 A_log / W_g：有效衰减 softplus(A_log + W_g·norm(x))
            # 依赖上游表示，前层一变有效谱照样漂 —— 这正是 spec_reg 优于 freeze 的原因。
            ref_rates = [r.detach().clone() for r in effective_rates(m, probe_x)]

        opt = torch.optim.AdamW(build_param_groups(m, 0.01), lr=args.ft_lr)
        ft_gen = torch.Generator().manual_seed(args.seed + 7)
        curve_gen = torch.Generator().manual_seed(args.seed + 99)   # 训练内评测专用

        curve = []                                   # 训练中的漂移曲线（论文图用）
        t1 = time.time()
        for step in range(args.steps_finetune):
            replaying = use_lcr and torch.rand(1, generator=ft_gen).item() < args.lcr_prob
            if replaying:
                # 长上下文回放：纯合成 MQAR，无需任何人工标注
                x_in, tgt, _ = make_mqar(64, PRE_LEN, VOCAB, N_PAIRS, ft_gen, device)
                loss = F.cross_entropy(m(x_in)[:, -2, :], tgt)
            elif args.task_gap >= 0:
                # 间隔回看任务：域内数据的「记忆需求」= task_gap 步
                x_in, tgt = make_gap_task(64, FT_LEN, VOCAB, args.task_gap, ft_gen, device)
                loss = F.cross_entropy(m(x_in)[:, -2, :], tgt)
            else:
                x = make_local_task(64, FT_LEN, VOCAB, ft_gen, device)
                logits = m(x[:, :-1])
                loss = F.cross_entropy(logits.reshape(-1, VOCAB), x[:, 1:].reshape(-1))
            if use_sr:
                loss = loss + decay_regularizer(m, probe_x, ref_rates, args.spec_lambda)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            if args.grad_probe and step == 0:
                gn_dec = sum(p.grad.pow(2).sum().item() ** 0.5
                             for n, p in m.named_parameters()
                             if p.grad is not None and (n.endswith("A_log") or n.endswith("g_proj.weight")))
                gn_con = sum(p.grad.pow(2).sum().item() ** 0.5
                             for n, p in m.named_parameters()
                             if p.grad is not None and not (n.endswith("A_log") or n.endswith("g_proj.weight")))
                print(f"  [grad] {mode} task_gap={args.task_gap} "
                      f"||g_decay||={gn_dec:.4f}  ||g_content||={gn_con:.4f}  "
                      f"ratio={gn_dec / max(gn_con, 1e-12):.5f}")
            torch.nn.utils.clip_grad_norm_([p for p in m.parameters() if p.requires_grad], 1.0)
            opt.step()

            if args.eval_every and (step + 1) % args.eval_every == 0:
                # 用**独立**生成器做训练内评测，否则会推进全局 gen 的随机状态，
                # 导致最终评测的数据与其它 run 不可比（复现性坑）。
                _l = evaluate_local(m, VOCAB, FT_LEN, device, curve_gen, n_batch=16, n_rounds=2)
                _r = evaluate_mqar(m, VOCAB, [PRE_LEN], N_PAIRS, device, curve_gen,
                                   n_batch=16, n_rounds=2)[PRE_LEN]
                _, _cur = m.decay_stats(probe_base)
                _w1 = spectral_w1(torch.cat(base_rates), torch.cat(_cur))
                curve.append({"step": step + 1, "local_acc": _l, "mqar192": _r, "w1": _w1})
                m.train()

        if do_restore:
            # 免训练还原基线：直接把 A_log / g_proj.weight 拷回预训练值。
            # 用来回答审稿人「为什么不能像 QK-Restore 那样事后还原」。
            pre_sd = torch.load(PRETRAIN_CKPT, map_location=device)
            with torch.no_grad():
                for name, p in m.named_parameters():
                    if name in pre_sd and (name.endswith("A_log") or name.endswith("g_proj.weight")):
                        p.copy_(pre_sd[name])

        recall = evaluate_mqar(m, VOCAB, EVAL_LENS, N_PAIRS, device, gen)
        bydist = evaluate_mqar_by_distance(m, VOCAB, PRE_LEN, N_PAIRS, device, gen)
        local = evaluate_local(m, VOCAB, FT_LEN, device, gen)
        stats, rates = m.decay_stats(probe_base)

        drift = {
            f"layer{i}": spectral_w1(base_rates[i], rates[i]) for i in range(len(rates))
        }
        drift["global"] = spectral_w1(
            torch.cat(base_rates), torch.cat(rates)
        )

        summary["runs"][mode] = {
            "mqar_recall": recall,
            "mqar_recall_by_distance": bydist,
            "local_acc": local,
            "decay": stats,
            "spectral_w1_vs_pretrain": drift,
            "recall_retention": {
                str(L): recall[L] / max(base_recall[L], 1e-6) for L in EVAL_LENS
            },
            "bydist_retention": {
                k: (bydist[k] / max(base_bydist[k], 1e-6) if bydist[k] == bydist[k] else None)
                for k in bydist
            },
            "curve": curve,
            "config": {
                "use_sr": use_sr, "use_lcr": use_lcr, "freeze_decay": mode == "freeze_decay",
                "restore_decay": do_restore, "lcr_prob": args.lcr_prob if use_lcr else 0.0,
                "spec_lambda": args.spec_lambda if use_sr else 0.0,
                "task_gap": args.task_gap,
                "ft_lr": args.ft_lr, "steps_finetune": args.steps_finetune,
                "seed": args.seed,
            },
        }
        print(f"  [{mode}] local {local:.3f} (base {base_local:.3f}) | "
              f"MQAR {({k: round(v,3) for k,v in recall.items()})} | "
              f"W1 {drift['global']:.3f} | {time.time()-t1:.0f}s")
        print(f"        by-distance recall {({k: (round(v,3) if v==v else None) for k,v in bydist.items()})}")
        torch.save(m.state_dict(), f"results/pilot_ft_{mode}.pt")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(summary, f, indent=2)
    print("saved ->", args.out)


if __name__ == "__main__":
    main()
