# Prespecified main-backbone follow-ups

Frozen before execution on 2026-10-22. These protocols add evidence to the current paper; they do not change the original cohort or the active validation-selected L2-SP+replay run. No outcomes are asserted here.

## Increased replay exposure

Use each original Mamba-2 retrieval-trained reference for seeds0,1,2. Hold short updates600, physical batch4, AdamW groups, learning rate1e-4, clipping1 and all three original RNG streams fixed. Increase replay probability from0.05 to0.30, the same exposure intervention as the completed controlled-model experiment. No distribution penalty. This is an exposure comparison, not a claim of equal wall-clock compute. Record time and peak allocated memory descriptively. Evaluate all nine original test cells with128 examples each, full five-digit greedy generation, text NLL on8064 tokens, conditional preservation, optimized probe distance and the same nine independent-probe batches. Report all seeds; do not choose a replay probability on the test set.

## Mixed skill acquisition

Starting at the same downloaded Mamba-2 weights, establish three independent references with500 updates, batch4, learning rate1e-4, the original optimizer groups and clipping1. Each update minimizes0.5 times the five-key-digit CE on length256 retrieval (depth uniform0.1–0.9) plus0.5 times next-token CE on a length64 text batch. Retrieval RNG seed+111; text RNG seed+112. This reference cohort is distinct from the original retrieval-only acquisition cohort and is never pooled with it.

Measure each reference's retrieval and text quality. Apply both LCR and SPFT with the original600 short updates, replay0.05, coefficient1, matched short/replay/decision streams seed+701/+702/+703. Use the same fixed validation probe and independent test protocols. No coefficient or reference selection on the test set. Include all three references even if their retrieval is low, and explicitly handle zero baseline successes as undefined conditional preservation. The experiment tests whether the joint preservation behavior transports to skill acquisition that also trains language modeling; it is not a natural downstream benchmark.

## Execution and provenance

Scientific driver backbone/revision6_extension.py. The queue waits for successful completion of the active original-reference comparator, then runs increased replay followed by mixed acquisition on the same server and runtime. Results and checkpoints occupy revision_v6/highreplay and revision_v6/mixed. Each cohort records source, common-driver and corpus hashes. Partial endpoints do not count as a complete cohort. Tiny CPU Mamba2 smoke checks cover mixed acquisition and all three adaptation modes but supply no scientific endpoint.
