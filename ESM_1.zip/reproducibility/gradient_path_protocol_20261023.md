# Gradient-path ablation, fixed before new outcomes

Purpose: distinguish an unchanged forward decay-distribution objective from the gradient routes by which that objective influences training. This does not assume decay statistics cause retrieval retention.

- Three original Mamba-2 retrieval-trained references, seeds 0–2; no new acquisition or seed selection.
- Comparator: reuse full-gradient SPFT checkpoints from revision_v7/equal_time. Same revision7 training function, 600 short updates, replay probability .05, coefficient1, AdamW lr1e-4, batch4, warmup-and-restore, matched RNG streams and two-example fixed probe seed90210.
- Intervention: detach the complete clipped softplus step size, including bias, only in the penalty calculation. A_log remains differentiable. Task losses retain their original full gradients.
- Gate before training: exact equal forward statistics at the reference; equal penalty values on a common adapted checkpoint; zero penalty gradients on dt_bias and all other parameters in the detached version; nonzero A_log penalty gradient and nonzero upstream penalty gradient under full differentiation.
- Report all three detached endpoints against the reused anchors: nine-condition exact match, retention of reference-correct answers, held-out text NLL, optimized and nine-batch independent probe distance. Inputs use the existing fixed streams. No hyperparameter or endpoint selection.
- Log penalty-only group gradient L2 norms and parameter displacement by A_log, dt_bias and other parameters. Gradients on shared adapted anchors provide a controlled route check, not an independent training replicate.
- Scientific driver: backbone/revision11_gradient_path.py. Runtime manifest records source fingerprints. All new results are isolated in revision_v11; existing cohorts remain unchanged.
- No timing superiority will be inferred from these runs. The historical common-budget comparison remains the timing experiment.

The zero-gradient upstream condition concerns the penalty only, not the total loss. A_only training can still change upstream parameters through short-text and replay supervision. Thus a difference between endpoints tests the contribution of penalty gradient routing, not a hard intervention that holds the realized recurrent dynamics fixed.
