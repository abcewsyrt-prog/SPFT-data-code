# Planned Mamba-2 matched regularization and replay control

Historical plan as of 2026-10-17. The precision experiment below has since been completed. See [the completed analysis](../results/revision_v5/precision/analysis.json) and the current README. The original-reference comparator is now running under `backbone/revision5_matched_control.py`; its final test records are pending. The dated plan is retained unchanged below.

Status is prepared, not executed. On 2026-10-17, three attempts to connect to the existing A2-Work host returned Network is unreachable before authentication. No new experimental result is claimed in the manuscript.

The driver is `backbone/revision4_matched_control.py`. It imports the unchanged `backbone/revision_experiments.py`, uses the existing Mamba-2 130M model and the three original retrieval-trained references. It uses 600 short updates, batch 4, learning rate 1e-4, replay probability 0.05, and the original seed+701/+702/+703 short/replay/selection RNG streams. L2-SP is mean squared parameter displacement from each reference and is applied on both short and replay steps.

The prespecified strengths are 100, 10000, and 1000000, spanning four orders of magnitude of the normalized parameter penalty. Nine adaptations are required. Each candidate is evaluated on independent validation-corpus retrieval streams with seed 42731 and text seed 42739, with 128 examples per length-depth condition and 128 text sequences. Existing LCR and SPFT checkpoints are evaluated on the same validation streams. A single strength is selected across training seeds by highest mean validation macro EM, subject to mean validation text NLL no greater than matched LCR mean + 0.02. Ties favor lower strength. If no candidate is admissible, the selection stops explicitly and does not use a test-selected replacement.

The selection artifact is saved before candidate test evaluation. The selected strength uses the original nine test conditions, 128 common examples each, and the original text stream. It also reports conditional retention and the same nine independent probe batches as the earlier backbone measurements. All validation candidates are retained. Timing and peak allocated memory are recorded, but training timings are not declared fair comparisons to earlier timing on a potentially shared GPU. A fresh output directory is required. The original sources and result files are preserved.

Example invocation from the existing remote project directory, after copying the new driver into the existing source directory:

```sh
/mnt/data/anaconda3/envs/pytorch1/bin/python revision_v2/revision4_matched_control.py --model models/mamba2-130m-hf --corpus revision_v2/data/mmlu_text.json --references revision_v2 --out revision_v4/mamba_matched
```

The original driver `revision_experiments.py` must remain adjacent for import. Inspect GPU use before starting. The controlled source tests validate the selection rule; they do not validate CUDA execution or establish any new empirical endpoint.

The separate precision-matched reevaluation remains pending. Existing source predictions at Recall@768 differ in net hit count by 0, 1, and 1 between training-process vanilla evaluation and independent ft/ft swap evaluation. Main training explicitly enables TF32 matmul; the swap process has no override. This observed setup difference is recorded, without claiming its causal role has been experimentally isolated.
