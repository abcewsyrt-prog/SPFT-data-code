"""Prespecified input-step-size stop-gradient ablation; no test-based selection."""
import argparse,hashlib,json,math,random,sys
from pathlib import Path
sys.path.insert(0,'/root/ai_paper/revision_v9/source')
import torch
import revision_experiments as R
import revision6_extension as X
import revision7_equal_time as T
FULL=R.corrected_spectrum
ROOT=Path('/root/ai_paper');OUT=ROOT/'revision_v11';SOURCE=Path(__file__)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def a_only_logdecay(mixer,projected):
    raw=projected[..., -mixer.num_heads:].float()
    dt=torch.nn.functional.softplus(raw+mixer.dt_bias.float())
    limits=getattr(mixer,'time_step_limit',(0.,float('inf')))
    dt=dt.clamp(min=limits[0],max=limits[1]).detach()
    return -torch.exp(mixer.A_log.float())[None,None,:]*dt

def spectrum_a_only(model,probe,detach=False):
    store={};handles=[]
    def create(name,parent):
        def hook(module,inputs,output):
            g=a_only_logdecay(parent,output);mu=g.mean(dim=(0,1));u=(math.log(2.)/(-mu).clamp_min(1e-12)).log();store[name]=u.detach() if detach else u
        return hook
    try:
        for name,m in model.named_modules():
            if name.endswith('in_proj'):
                parent=model.get_submodule(name.rsplit('.',1)[0])
                if hasattr(parent,'A_log') and hasattr(parent,'dt_bias'):handles.append(m.register_forward_hook(create(name,parent)))
        if not handles:raise ValueError('No Mamba decay modules')
        with torch.set_grad_enabled(not detach):model(probe,use_cache=False)
    finally:
        for h in handles:h.remove()
    return [store[k] for k in sorted(store)]
def grad_record(model,probe,reference,fn):
    model.zero_grad(set_to_none=True);params=[(n,p) for n,p in model.named_parameters() if p.requires_grad];loss=R.spectrum_distance(fn(model,probe),reference)
    grads=torch.autograd.grad(loss,[p for n,p in params],allow_unused=True)
    totals={'A_log':0.,'dt_bias':0.,'other':0.};counts={k:0 for k in totals}
    for (n,p),g in zip(params,grads):
        k='A_log' if n.endswith('A_log') else 'dt_bias' if n.endswith('dt_bias') else 'other'
        if g is not None:totals[k]+=float(g.detach().double().square().sum());counts[k]+=int(torch.count_nonzero(g))
    return dict(penalty=float(loss.detach()),l2_gradient={k:math.sqrt(v) for k,v in totals.items()},nonzero_elements=counts)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');a=ap.parse_args();OUT.mkdir(exist_ok=True);torch.set_num_threads(4);dev=torch.device('cuda')
    import transformers
    manifest=dict(source_sha256=sha(SOURCE),common_sha256=sha(R.__file__),training_driver_sha256=sha(T.__file__),extension_sha256=sha(X.__file__),torch=torch.__version__,transformers=transformers.__version__,seeds=[0,1,2],short_updates=600,replay_probability=.05,coefficient=1.,batch=4,lr=1e-4,probe_seed=90210,probe_n=2,probe_length=256,intervention='detach entire clipped softplus step size in penalty only; only A_log receives penalty gradient; task gradients unchanged',full_comparator='reuse revision_v7/equal_time seed0..2_spft.pt; identical training driver and RNG',evaluation='all nine fixed test conditions; EM,Q,text NLL,nine independent probe batches; no candidate selection',new_training_runs=3)
    mp=OUT/'manifest.json'
    if mp.exists():assert json.loads(mp.read_text())==manifest
    else:R.atomic_json(mp,manifest)
    corpus=ROOT/'revision_v2/data/mmlu_text.json';raw=json.loads(corpus.read_text());tok=transformers.AutoTokenizer.from_pretrained(ROOT/'models/mamba2-130m-hf');tokens={k:tok.encode('\n\n'.join(raw[k]),add_special_tokens=False) for k in raw};digits=R.digit_ids(tok)
    for seed in range(3):
        R.atomic_json(OUT/'progress.json',dict(phase='setup',seed=seed));refpath=ROOT/f'revision_v2/mamba130_seed{seed}/continued_training.pt';state=torch.load(refpath,map_location='cpu');torch.manual_seed(seed);random.seed(seed);model=R.load_model(ROOT/'models/mamba2-130m-hf',dev);model.load_state_dict(state);model.eval();probe=R.make_retrieval(2,256,.5,torch.Generator().manual_seed(90210),digits,tokens['validation'],dev)[0];reference=FULL(model,probe,detach=True)
        diff=max(float((x-y).abs().max()) for x,y in zip(reference,spectrum_a_only(model,probe,detach=True)));assert diff==0.,diff
        # At a common adapted checkpoint, verify equal forward statistics and distinct gradients.
        anchorpath=ROOT/f'revision_v7/equal_time/seed{seed}_spft.pt';model.load_state_dict(torch.load(anchorpath,map_location=dev));model.eval();normal=grad_record(model,probe,reference,FULL);restricted=grad_record(model,probe,reference,spectrum_a_only)
        assert abs(normal['penalty']-restricted['penalty'])<1e-7
        assert restricted['l2_gradient']['dt_bias']==restricted['l2_gradient']['other']==0.
        assert restricted['l2_gradient']['A_log']>0 and normal['l2_gradient']['other']>0
        R.atomic_json(OUT/f'seed{seed}_path_check.json',dict(forward_max_error=diff,full=normal,a_only=restricted,reference_sha256=sha(refpath),full_checkpoint_sha256=sha(anchorpath)))
        if a.smoke:print('SMOKE_PASS',seed,flush=True);return
        model.load_state_dict(state);model.zero_grad(set_to_none=True);checkpoint=OUT/f'seed{seed}_a_only.pt';training_path=OUT/f'seed{seed}_training.json'
        if not checkpoint.exists():
            R.atomic_json(OUT/'progress.json',dict(phase='training',seed=seed));R.corrected_spectrum=spectrum_a_only
            try:training=T.train(model,tokens['train'],digits,probe,reference,state,seed,'spft',dev)
            finally:R.corrected_spectrum=FULL
            # Save metadata before checkpoint; resume never treats a checkpoint without metadata as complete.
            training.update(reference_sha256=sha(refpath),full_checkpoint_sha256=sha(anchorpath));R.atomic_json(training_path,training);torch.save(model.state_dict(),checkpoint)
        assert training_path.exists();model.load_state_dict(torch.load(checkpoint,map_location=dev));model.eval()
        dest=OUT/f'seed{seed}_a_only_test.json'
        if not dest.exists():
            R.atomic_json(OUT/'progress.json',dict(phase='evaluation',seed=seed));v=X.endpoint(model,tokens['test'],digits,dev);base=json.loads((refpath.parent/'baseline.json').read_text());num=den=0
            for k,c in v['retrieval'].items():
                b=base['retrieval'][k];assert c['targets']==b['targets'] and c['key_positions']==b['key_positions'];den+=sum(b['hits']);num+=sum(h*j for h,j in zip(b['hits'],c['hits']))
            v.update(seed=seed,conditional_retention=dict(retained=num,established=den,fraction=num/den),training=json.loads(training_path.read_text()),checkpoint_sha256=sha(checkpoint),optimized_probe_w1=float(R.spectrum_distance(FULL(model,probe,detach=True),reference)))
            v['penalty_gradients']=dict(full=grad_record(model,probe,reference,FULL),a_only=grad_record(model,probe,reference,spectrum_a_only))
            shifts={k:0. for k in ['A_log','dt_bias','other']}
            for n,p in model.named_parameters():
                k='A_log' if n.endswith('A_log') else 'dt_bias' if n.endswith('dt_bias') else 'other';shifts[k]+=float((p.detach().cpu().double()-state[n].double()).square().sum())
            v['parameter_displacement_l2']={k:math.sqrt(x) for k,x in shifts.items()};v['independent_w1']=X.independent_probes(model,state,tokens['test'],digits,dev);R.atomic_json(dest,v)
        del model,state;torch.cuda.empty_cache();print('SEED_COMPLETE',seed,flush=True)
    R.atomic_json(OUT/'complete.json',dict(status='complete',seeds=3,new_training_runs=3));R.atomic_json(OUT/'progress.json',dict(phase='complete'));print('COMPLETE',flush=True)
if __name__=='__main__':main()
