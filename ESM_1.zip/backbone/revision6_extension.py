"""Prespecified replay-exposure and mixed-acquisition Mamba follow-ups.

Separate cohorts, original inference/runtime/physical batch, no test selection.
Run only after the original-reference validation-selected experiment completes.
"""
import argparse
import hashlib
import json
import random
import statistics
import time
from pathlib import Path
import torch
import revision_experiments as R

SEEDS = (0, 1, 2)

def adaptation(model, tokens, digits, probe, reference, seed, mode, device, steps=600):
    opt = torch.optim.AdamW(R.parameter_groups(model), lr=1e-4)
    sg = torch.Generator().manual_seed(seed+701)
    rg = torch.Generator().manual_seed(seed+702)
    cg = torch.Generator().manual_seed(seed+703)
    probability = .30 if mode == 'highreplay' else .05
    model.train()
    if device.type == 'cuda':
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()
    start = time.perf_counter()
    replays = 0
    for step in range(steps):
        opt.zero_grad(set_to_none=True)
        x = R.text_batch(tokens, 4, 64, sg, device)
        loss = R.next_token_loss(model, x)
        if mode == 'spft':
            loss = loss + R.spectrum_distance(R.corrected_spectrum(model, probe), reference)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
        opt.step()
        if float(torch.rand(1, generator=cg)) < probability:
            depth = float(torch.rand(1, generator=rg))*.8+.1
            x, y, _ = R.make_retrieval(4, 256, depth, rg, digits, tokens, device)
            opt.zero_grad(set_to_none=True)
            loss = R.full_key_loss(model, x, y)
            if mode == 'spft':
                loss = loss + R.spectrum_distance(R.corrected_spectrum(model, probe), reference)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
            opt.step()
            replays += 1
        if (step+1) % 50 == 0:
            print('ADAPT', seed, mode, step+1, flush=True)
    if device.type == 'cuda': torch.cuda.synchronize()
    return {'short_updates': steps, 'replay_updates': replays,
            'replay_probability': probability, 'seconds': time.perf_counter()-start,
            'peak_memory_bytes': torch.cuda.max_memory_allocated() if device.type == 'cuda' else None}

def acquire_mixed(model, tokens, digits, seed, device, steps=500):
    """Equal-weight retrieval and text losses on every acquisition update."""
    opt = torch.optim.AdamW(R.parameter_groups(model), lr=1e-4)
    rg = torch.Generator().manual_seed(seed+111)
    tg = torch.Generator().manual_seed(seed+112)
    model.train()
    for step in range(steps):
        depth = float(torch.rand(1, generator=rg))*.8+.1
        x, y, _ = R.make_retrieval(4, 256, depth, rg, digits, tokens, device)
        t = R.text_batch(tokens, 4, 64, tg, device)
        opt.zero_grad(set_to_none=True)
        loss = .5*R.full_key_loss(model, x, y) + .5*R.next_token_loss(model, t)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
        opt.step()
        if (step+1) % 50 == 0: print('MIXED_ACQUIRE', seed, step+1, flush=True)

def endpoint(model, tokens, digits, device):
    cells = R.evaluate_keys(model, digits, tokens, device, 128, 4,
                            [256, 512, 1024], [.1, .5, .9], 5719)
    return {'retrieval': cells, 'macro_em': statistics.mean(v['full_key_exact_match'] for v in cells.values()),
            'text': R.evaluate_text(model, tokens, device, 128, 4, seed=7091)}

def independent_probes(model, state, tokens, digits, device):
    probes = []
    for length in (64, 256, 1024):
        for rep in range(3):
            g = torch.Generator().manual_seed(917331+length*11+rep)
            probes.append(R.text_batch(tokens, 2, length, g, device) if length == 64 else
                          R.make_retrieval(2, length, .5 if length == 256 else .1,
                                           g, digits, tokens, device)[0])
    model.eval()
    current = [R.corrected_spectrum(model, x, detach=True) for x in probes]
    model.load_state_dict(state)
    model.eval()
    reference = [R.corrected_spectrum(model, x, detach=True) for x in probes]
    return [float(R.spectrum_distance(c, r)) for c, r in zip(current, reference)]

def main():
    ap = argparse.ArgumentParser()
    for key in ('model', 'corpus', 'references', 'out'): ap.add_argument('--'+key, required=True)
    ap.add_argument('--cohort', choices=('highreplay', 'mixed'), required=True)
    a = ap.parse_args()
    import transformers
    dev = torch.device('cuda')
    torch.set_num_threads(4)
    out = Path(a.out);out.mkdir(parents=True, exist_ok=True)
    manifest = dict(vars(a), seeds=list(SEEDS), adaptation_steps=600, acquisition_steps=500,
                    batch=4, lr=1e-4, spec_lambda=1.,
                    mixed_acquisition_loss='0.5 retrieval key CE + 0.5 text next-token CE per update',
                    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    common_sha256=hashlib.sha256(Path(R.__file__).read_bytes()).hexdigest(),
                    corpus_sha256=hashlib.sha256(Path(a.corpus).read_bytes()).hexdigest(),
                    torch=torch.__version__, transformers=transformers.__version__,
                    selection='none; all three seeds and all stated methods reported')
    if (out/'manifest.json').exists():
        assert json.loads((out/'manifest.json').read_text()) == manifest, 'Protocol changed; use fresh directory'
    else: R.atomic_json(out/'manifest.json', manifest)
    tok = transformers.AutoTokenizer.from_pretrained(a.model)
    raw = json.loads(Path(a.corpus).read_text())
    tokens = {k:tok.encode('\n\n'.join(raw[k]), add_special_tokens=False) for k in raw}
    digits = R.digit_ids(tok)
    for seed in SEEDS:
        if (out/f'seed{seed}_complete.json').exists(): continue
        torch.manual_seed(seed);random.seed(seed)
        model = R.load_model(a.model, dev)
        if a.cohort == 'mixed':
            reference_path = out/f'seed{seed}_reference.pt'
            if reference_path.exists(): model.load_state_dict(torch.load(reference_path, map_location=dev))
            else:
                acquire_mixed(model, tokens['train'], digits, seed, dev)
                torch.save(model.state_dict(), reference_path)
        else:
            reference_path = Path(a.references)/f'mamba130_seed{seed}'/'continued_training.pt'
            model.load_state_dict(torch.load(reference_path, map_location=dev))
        state = {k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
        if a.cohort == 'mixed':
            baseline = endpoint(model, tokens['test'], digits, dev)
            R.atomic_json(out/f'seed{seed}_baseline.json', baseline)
        else: baseline = json.loads((reference_path.parent/'baseline.json').read_text())
        g = torch.Generator().manual_seed(90210)
        probe = R.make_retrieval(2, 256, .5, g, digits, tokens['validation'], dev)[0]
        reference = R.corrected_spectrum(model, probe, detach=True)
        for mode in (('lcr', 'spft') if a.cohort == 'mixed' else ('highreplay',)):
            dest = out/f'seed{seed}_{mode}.json'
            if dest.exists(): continue
            model.load_state_dict(state)
            training = adaptation(model, tokens['train'], digits, probe, reference, seed, mode, dev)
            torch.save(model.state_dict(), out/f'seed{seed}_{mode}.pt')
            result = endpoint(model, tokens['test'], digits, dev)
            num = den = 0
            for cell, x in result['retrieval'].items():
                b = baseline['retrieval'][cell]
                assert x['targets'] == b['targets'] and x['key_positions'] == b['key_positions']
                den += sum(b['hits'])
                num += sum(v for h,v in zip(b['hits'], x['hits']) if h)
            result.update(seed=seed, mode=mode, training=training,
                          reference_sha256=hashlib.sha256(reference_path.read_bytes()).hexdigest(),
                          conditional_retention={'retained':num, 'established':den, 'fraction':num/den if den else None})
            result['optimized_probe_w1'] = float(R.spectrum_distance(R.corrected_spectrum(model, probe, detach=True), reference))
            result['independent_w1'] = independent_probes(model, state, tokens['test'], digits, dev)
            R.atomic_json(dest, result)
        R.atomic_json(out/f'seed{seed}_complete.json', {'status':'complete'})
        del model, state
        torch.cuda.empty_cache()
    R.atomic_json(out/'complete.json', {'status':'complete'})

if __name__ == '__main__': main()
