"""RWKV-7 adapter for the shared full-key and natural-text revision protocol."""
import hashlib,math,inspect
from pathlib import Path
import torch
import transformers
from fla.models.rwkv7 import RWKV7ForCausalLM
import revision_experiments as R


def load_model(path,device):
    return RWKV7ForCausalLM.from_pretrained(path,dtype=torch.bfloat16 if device.type=='cuda' else torch.float32).to(device)


def spectrum(model,probe,detach=False):
    handles=[];store={}
    def mk(name):
        def hook(module,inputs,out):
            g=-0.6065306597126334*torch.sigmoid(out.float())
            u=(math.log(2.)/(-g.mean((0,1))).clamp_min(1e-12)).log()
            store[name]=u.detach() if detach else u
        return hook
    try:
        for name,module in model.named_modules():
            if name.endswith('w_lora'):handles.append(module.register_forward_hook(mk(name)))
        if not handles:raise ValueError('No RWKV7 decay heads.')
        with torch.set_grad_enabled(not detach):model(probe,use_cache=False)
    finally:
        for h in handles:h.remove()
    return [store[k] for k in sorted(store)]


def groups(model):
    decay=[];other=[]
    for name,param in model.named_parameters():
        if param.requires_grad:(decay if 'w_lora' in name or name.endswith('x_w') else other).append(param)
    return [{'params':other,'weight_decay':.01},{'params':decay,'weight_decay':0.}]

# FLA's legacy Cache initializer targets Transformers 4.x. Training and the
# uncached evaluation path need only its own states/seen-token fields. Keep this
# adapter local to the process rather than changing the installed packages.
from fla.models.utils import Cache as FLACache

def compatible_cache_init(self, seen_tokens=0):
    self.states=[]
    self._seen_tokens=seen_tokens
    self.layers=[]

FLACache.__init__=compatible_cache_init
# Use explicit full-prefix decoding, avoiding a cross-version generation cache.
source=inspect.getsource(R.evaluate_keys)
source=source.replace("if hasattr(model, 'generate'):", "if False:")
exec(compile(source, '<uncached-rwkv-evaluation>', 'exec'), R.__dict__)

original_tokenizer=transformers.AutoTokenizer.from_pretrained
original_json=R.atomic_json

def tokenizer(path,*a,**kw):
    kw['trust_remote_code']=True
    return original_tokenizer(path,*a,**kw)


def save(path,data):
    if Path(path).name=='manifest.json':
        import fla
        data.update({'architecture':'RWKV-7','generation':'uncached full-prefix fixed-length decoding','cache_adapter':'FLA legacy states initializer; no cached generation','adapter_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'fla_version':getattr(fla,'__version__','unknown'),'spectrum':'per-channel mean log-retention from RWKV-7 w_lora, layer-average log-half-life W1'})
    original_json(path,data)

R.load_model=load_model;R.corrected_spectrum=spectrum;R.parameter_groups=groups;R.atomic_json=save
transformers.AutoTokenizer.from_pretrained=tokenizer

if __name__=='__main__':R.main()
