"""Independent decay probes for completed backbone checkpoints; evaluation only."""
import argparse,hashlib,json,sys,time
from pathlib import Path
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'revision_v2'))
# Local source can also run when the common driver is on PYTHONPATH.
import revision_experiments as R

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--arch',choices=['mamba130','rwkv400'],required=True);ap.add_argument('--model',required=True);ap.add_argument('--corpus',required=True);ap.add_argument('--runs',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
 if a.arch=='rwkv400':import revision_rwkv_experiments
 import transformers
 out=Path(a.out);out.mkdir(parents=True,exist_ok=True);dev=torch.device('cuda');torch.set_num_threads(4)
 tok=transformers.AutoTokenizer.from_pretrained(a.model);raw=json.loads(Path(a.corpus).read_text());tokens=tok.encode('\n\n'.join(raw['test']),add_special_tokens=False);digits=R.digit_ids(tok)
 probes=[];meta=[]
 for length in [64,256,1024]:
  for rep in range(3):
   gen=torch.Generator().manual_seed(917331+length*11+rep)
   if length==64:x=R.text_batch(tokens,2,length,gen,dev)
   else:x,_,_=R.make_retrieval(2,length,.5 if length==256 else .1,gen,digits,tokens,dev)
   probes.append(x);meta.append({'length':length,'replicate':rep,'seed':917331+length*11+rep,'type':'natural-text' if length==64 else 'digit-retrieval','token_sha256':hashlib.sha256(x.cpu().numpy().tobytes()).hexdigest()})
 manifest=vars(a).copy();manifest.update({'probe_definition':meta,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'corpus_sha256':hashlib.sha256(Path(a.corpus).read_bytes()).hexdigest(),'unit':'independent training seeds; probes are repeated measurements, not training replicates','model_files':{str(p.relative_to(a.model)):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(a.model).glob('*.json')}})
 R.atomic_json(out/'manifest.json',manifest)
 model=R.load_model(a.model,dev);model.eval();original=R.evaluate_text(model,tokens,dev,128,2);R.atomic_json(out/'original_model_text.json',original);print('ORIGINAL',a.arch,original,flush=True)
 modes=['vanilla','lcr','spec_reg','spft','l2sp']+(['freeze_decay'] if a.arch=='mamba130' else [])
 for seed in range(3):
  run=Path(a.runs)/f'{a.arch}_seed{seed}';dest=out/f'seed{seed}.json'
  if dest.exists():continue
  model.load_state_dict(torch.load(run/'continued_training.pt',map_location=dev));model.eval()
  reference=[R.corrected_spectrum(model,x,detach=True) for x in probes]
  record={'seed':seed,'arch':a.arch,'reference':'same-seed continued-training checkpoint','modes':{}}
  for mode in modes:
   model.load_state_dict(torch.load(run/(mode+'.pt'),map_location=dev));model.eval();rows=[]
   for x,ref,desc in zip(probes,reference,meta):
    cur=R.corrected_spectrum(model,x,detach=True);rows.append({**desc,'w1':float(R.spectrum_distance(cur,ref)),'aligned_change':float(R.spectrum_distance(cur,ref,True))})
   record['modes'][mode]=rows;R.atomic_json(dest,record);print('DONE',a.arch,seed,mode,[round(x['w1'],4) for x in rows],flush=True)
 print('COMPLETE',a.arch,flush=True)
if __name__=='__main__':main()
