"""Versioned follow-up experiments. Full-key generation, paired tests and true decay.

Never overwrites legacy checkpoints or results. Run one architecture/seed per output.
Data must contain separate train/validation/test text lists (JSON).
"""
import argparse
import copy
import hashlib
import inspect
import json
import math
import os
import platform
import random
import time
from pathlib import Path

import torch
import torch.nn.functional as F

SCHEMA = 'spft-revision-v2'


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2, allow_nan=False))
    os.replace(str(tmp), str(path))


def digit_ids(tokenizer):
    enc = [tokenizer.encode(str(i), add_special_tokens=False) for i in range(10)]
    if any(len(x) != 1 for x in enc) or len(set(x[0] for x in enc)) != 10:
        raise ValueError('This protocol requires ten distinct single-token digits.')
    return torch.tensor([x[0] for x in enc], dtype=torch.long)


def make_retrieval(batch, length, depth, generator, digits, filler, device, key_len=5):
    """Position-variable digit retrieval. Explicit lookup, never arithmetic token IDs."""
    if length < key_len + 8 or not 0 <= depth <= 1:
        raise ValueError('Invalid retrieval length or insertion depth.')
    values = torch.randint(10, (batch, key_len), generator=generator)
    targets = digits[values]
    rows = []
    positions = []
    for b in range(batch):
        start = int(torch.randint(max(1, len(filler) - length), (1,), generator=generator))
        # Repeat only when the corpus fragment is shorter than requested context.
        row = filler[start:start + length]
        if len(row) < length:
            row = (row + filler * (length // max(1, len(filler)) + 1))[:length]
        pos = int((length - key_len - 1) * depth)
        row[pos:pos + key_len] = targets[b].tolist()
        rows.append(row)
        positions.append(pos)
    return torch.tensor(rows, device=device), targets.to(device), positions


def full_key_loss(model, context, target):
    """Teacher forcing trains every key digit; context itself is not a target."""
    length = context.shape[1]
    x = torch.cat((context, target[:, :-1]), dim=1)
    logits = model(x, use_cache=False).logits[:, length - 1:length + target.shape[1] - 1]
    return F.cross_entropy(logits.float().reshape(-1, logits.shape[-1]), target.reshape(-1))


@torch.no_grad()
def evaluate_keys(model, digits, filler, device, n, batch, lengths, depths, seed):
    model.eval()
    results = {}
    for length in lengths:
        for depth in depths:
            gen = torch.Generator().manual_seed(seed + length * 1000 + round(depth * 100))
            predictions = []
            targets_all = []
            positions_all = []
            for offset in range(0, n, batch):
                x, target, positions = make_retrieval(min(batch, n-offset), length, depth, gen, digits, filler, device)
                if hasattr(model, 'generate'):
                    # Exact fixed-length decoding; prevents early EOS and reuses recurrent state.
                    generated = model.generate(x, max_new_tokens=target.shape[1],
                        min_new_tokens=target.shape[1], do_sample=False, use_cache=True,
                        pad_token_id=0, eos_token_id=None)[:, -target.shape[1]:]
                else:
                    columns = []
                    for _ in range(target.shape[1]):
                        pred = model(x, use_cache=False).logits[:, -1].argmax(-1)
                        columns.append(pred)
                        x = torch.cat((x, pred[:, None]), dim=1)
                    generated = torch.stack(columns, dim=1)
                predictions.extend(generated.cpu().tolist())
                targets_all.extend(target.cpu().tolist())
                positions_all.extend(positions)
            hit = [int(a == b) for a, b in zip(predictions, targets_all)]
            per_digit = [sum(a[k] == b[k] for a,b in zip(predictions,targets_all))/n for k in range(5)]
            results['{}@{}'.format(length, depth)] = {
                'n': n, 'full_key_hits': sum(hit), 'full_key_exact_match': sum(hit)/n,
                'first_digit_accuracy': per_digit[0], 'per_digit_accuracy': per_digit,
                'hits': hit, 'predictions': predictions, 'targets': targets_all,
                'key_positions': positions_all,
            }
    return results


def mamba_logdecay(mixer, projected):
    """Matches installed Mamba2Mixer step-size transform, including bias and limits."""
    raw_dt = projected[..., -mixer.num_heads:].float()
    dt = F.softplus(raw_dt + mixer.dt_bias.float())
    limits = getattr(mixer, 'time_step_limit', (0., float('inf')))
    dt = dt.clamp(min=limits[0], max=limits[1])
    return -torch.exp(mixer.A_log.float())[None, None, :] * dt


def corrected_spectrum(model, probe, detach=False):
    handles, store = [], {}
    def hook_for(name, parent):
        def hook(module, inputs, output):
            logdecay = mamba_logdecay(parent, output)
            # Mean log-retention is tied to the observed path sum; descriptive only.
            mean_logdecay = logdecay.mean(dim=(0, 1))
            u = (math.log(2.) / (-mean_logdecay).clamp_min(1e-12)).log()
            store[name] = u.detach() if detach else u
        return hook
    try:
        for name, module in model.named_modules():
            if name.endswith('in_proj'):
                parent = model.get_submodule(name.rsplit('.', 1)[0])
                if hasattr(parent, 'A_log') and hasattr(parent, 'dt_bias'):
                    handles.append(module.register_forward_hook(hook_for(name, parent)))
        if not handles:
            raise ValueError('No supported Mamba-2 decay modules found.')
        with torch.set_grad_enabled(not detach):
            model(probe, use_cache=False)
    finally:
        for h in handles:
            h.remove()
    return [store[k] for k in sorted(store)]


def spectrum_distance(current, reference, aligned=False):
    if len(current) != len(reference) or not current:
        raise ValueError('Spectrum layer mismatch.')
    distances = []
    for a,b in zip(current,reference):
        if a.shape != b.shape:
            raise ValueError('Spectrum channel mismatch.')
        distances.append((a-b).abs().mean() if aligned else (a.sort().values-b.sort().values).abs().mean())
    return torch.stack(distances).mean()


def next_token_loss(model, ids):
    logits = model(ids[:, :-1], use_cache=False).logits
    return F.cross_entropy(logits.float().reshape(-1,logits.shape[-1]), ids[:,1:].reshape(-1))


def text_batch(tokens, batch, length, gen, device):
    if len(tokens) <= length:
        raise ValueError('Text split is too short.')
    starts = torch.randint(len(tokens)-length, (batch,), generator=gen).tolist()
    return torch.tensor([tokens[i:i+length] for i in starts], device=device)


@torch.no_grad()
def evaluate_text(model, tokens, device, n, batch, length=64, seed=7091):
    model.eval()
    gen = torch.Generator().manual_seed(seed)
    total_nll = 0.
    hits, total = 0, 0
    for offset in range(0,n,batch):
        x = text_batch(tokens,min(batch,n-offset),length,gen,device)
        logits = model(x[:,:-1],use_cache=False).logits
        target = x[:,1:]
        total_nll += F.cross_entropy(logits.float().reshape(-1,logits.shape[-1]),target.reshape(-1),reduction='sum').item()
        hits += (logits.argmax(-1)==target).sum().item()
        total += target.numel()
    return {'n_sequences':n,'n_tokens':total,'nll':total_nll/total,'perplexity':math.exp(min(80,total_nll/total)),'accuracy':hits/total}


def load_model(path, device):
    from transformers import Mamba2ForCausalLM
    model = Mamba2ForCausalLM.from_pretrained(path,torch_dtype=torch.bfloat16 if device.type=='cuda' else torch.float32)
    return model.to(device)


def parameter_groups(model):
    decay,other=[],[]
    for name,p in model.named_parameters():
        if p.requires_grad:
            (decay if name.endswith(('A_log','dt_bias')) else other).append(p)
    return [{'params':other,'weight_decay':.01},{'params':decay,'weight_decay':0.}]


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--model',required=True)
    ap.add_argument('--corpus',required=True)
    ap.add_argument('--out',required=True)
    ap.add_argument('--seed',type=int,default=0)
    ap.add_argument('--cp-steps',type=int,default=1000)
    ap.add_argument('--ft-steps',type=int,default=600)
    ap.add_argument('--batch',type=int,default=4)
    ap.add_argument('--eval-n',type=int,default=256)
    ap.add_argument('--eval-lengths',default='256,512,1024')
    ap.add_argument('--eval-depths',default='0.1,0.5,0.9')
    ap.add_argument('--modes',default='vanilla,lcr,spec_reg,spft,l2sp,freeze_decay')
    ap.add_argument('--lr',type=float,default=1e-4)
    ap.add_argument('--spec-lambda',type=float,default=1.)
    ap.add_argument('--l2-lambda',type=float,default=1.)
    ap.add_argument('--replay-prob',type=float,default=.05)
    ap.add_argument('--cp-checkpoint')
    ap.add_argument('--max-steps',type=int,default=0,help='Smoke tests can cap both training stages.')
    args=ap.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    manifest=vars(args).copy();manifest.update({'schema':SCHEMA,'torch':torch.__version__,'python':platform.python_version(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'corpus_sha256':hashlib.sha256(Path(args.corpus).read_bytes()).hexdigest()})
    import transformers
    manifest['transformers']=transformers.__version__
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    manifest['device']=torch.cuda.get_device_name() if device.type=='cuda' else 'cpu'
    manifest['spectrum']='per-channel mean log-retention, bias-inclusive, layer-averaged log-half-life W1'
    manifest['endpoint']='five-digit autoregressive exact match over full vocabulary'
    atomic_json(out/'manifest.json',manifest)
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    tok=transformers.AutoTokenizer.from_pretrained(args.model)
    digits=digit_ids(tok)
    raw=json.loads(Path(args.corpus).read_text())
    split={k:tok.encode('\n\n'.join(raw[k]),add_special_tokens=False) for k in ['train','validation','test']}
    if any(len(split[k])<2048 for k in split):raise ValueError('Each disjoint corpus split needs at least 2048 tokens.')
    model=load_model(args.model,device)
    refpath=out/'continued_training.pt'
    cp_steps=min(args.cp_steps,args.max_steps) if args.max_steps else args.cp_steps
    ft_steps=min(args.ft_steps,args.max_steps) if args.max_steps else args.ft_steps
    if args.cp_checkpoint:
        model.load_state_dict(torch.load(args.cp_checkpoint,map_location=device))
    else:
        opt=torch.optim.AdamW(parameter_groups(model),lr=args.lr)
        gen=torch.Generator().manual_seed(args.seed+111)
        model.train()
        t0=time.perf_counter()
        for step in range(cp_steps):
            depth=float(torch.rand(1,generator=gen))*.8+.1
            x,y,_=make_retrieval(args.batch,256,depth,gen,digits,split['train'],device)
            opt.zero_grad(set_to_none=True)
            loss=full_key_loss(model,x,y);loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
            if step%50==0:print('CP',step,float(loss),'elapsed',round(time.perf_counter()-t0,1),flush=True)
        del opt
    torch.save(model.state_dict(),refpath)
    reference_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
    gen=torch.Generator().manual_seed(90210)
    probe,_,_=make_retrieval(2,256,.5,gen,digits,split['validation'],device)
    reference=corrected_spectrum(model,probe,detach=True)
    lengths=[int(x) for x in args.eval_lengths.split(',')];depths=[float(x) for x in args.eval_depths.split(',')]
    def evaluate(m):
        return {'retrieval':evaluate_keys(m,digits,split['test'],device,args.eval_n,args.batch,lengths,depths,seed=5719),'text':evaluate_text(m,split['test'],device,args.eval_n,args.batch),'spectral_w1':float(spectrum_distance(corrected_spectrum(m,probe,detach=True),reference)),'aligned_decay_change':float(spectrum_distance(corrected_spectrum(m,probe,detach=True),reference,aligned=True))}
    baseline=evaluate(model);atomic_json(out/'baseline.json',baseline)
    print('BASELINE',[(k,v['full_key_exact_match']) for k,v in baseline['retrieval'].items()],flush=True)
    del model
    if device.type=='cuda':torch.cuda.empty_cache()
    for mode in args.modes.split(','):
        if (out/(mode+'.json')).exists():
            print('SKIP existing completed mode',mode,flush=True);continue
        model=load_model(args.model,device);model.load_state_dict(reference_state)
        if mode=='freeze_decay':
            for name,param in model.named_parameters():
                if name.endswith(('A_log','dt_bias')):param.requires_grad_(False)
        opt=torch.optim.AdamW(parameter_groups(model),lr=args.lr)
        # Independent streams prevent intervention choices changing the short-task data.
        short_gen=torch.Generator().manual_seed(args.seed+701)
        replay_gen=torch.Generator().manual_seed(args.seed+702)
        select_gen=torch.Generator().manual_seed(args.seed+703)
        model.train();t0=time.perf_counter();steps=0;short_tokens=0;replay_tokens=0;replays=0
        if device.type=='cuda':torch.cuda.reset_peak_memory_stats()
        l2ref={n:p.detach().clone() for n,p in model.named_parameters()} if mode=='l2sp' else None
        # Equal short-task steps. Replay is extra, with all compute reported explicitly.
        while steps<ft_steps:
            opt.zero_grad(set_to_none=True)
            x=text_batch(split['train'],args.batch,64,short_gen,device)
            loss=next_token_loss(model,x);short_tokens+=args.batch*63
            if mode in ('spec_reg','spft'):
                loss=loss+args.spec_lambda*spectrum_distance(corrected_spectrum(model,probe),reference)
            if mode=='l2sp':
                reg=sum((param.float()-l2ref[name].float()).square().sum() for name,param in model.named_parameters())
                loss=loss+args.l2_lambda*reg/sum(p.numel() for p in model.parameters())
            loss.backward();torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],1.);opt.step();steps+=1
            if mode in ('lcr','spft') and float(torch.rand(1,generator=select_gen))<args.replay_prob:
                opt.zero_grad(set_to_none=True)
                depth=float(torch.rand(1,generator=replay_gen))*.8+.1
                rx,ry,_=make_retrieval(args.batch,256,depth,replay_gen,digits,split['train'],device)
                replay_loss=full_key_loss(model,rx,ry)
                if mode=='spft':replay_loss=replay_loss+args.spec_lambda*spectrum_distance(corrected_spectrum(model,probe),reference)
                replay_loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step();replays+=1;replay_tokens+=args.batch*256
            if steps%50==0:print(mode,steps,float(loss),'elapsed',round(time.perf_counter()-t0,1),flush=True)
        if device.type=='cuda':torch.cuda.synchronize()
        timing={'seconds':time.perf_counter()-t0,'short_updates':steps,'replay_updates':replays,'short_tokens':short_tokens,'replay_input_tokens':replay_tokens,'peak_memory_bytes':torch.cuda.max_memory_allocated() if device.type=='cuda' else None}
        result=evaluate(model);result['training']=timing
        result['seed']=args.seed;result['mode']=mode;result['schema']=SCHEMA
        atomic_json(out/(mode+'.json'),result)
        torch.save(model.state_dict(),out/(mode+'.pt'))
        print('DONE',mode,[(k,v['full_key_exact_match']) for k,v in result['retrieval'].items()],result['text'],timing,flush=True)
        del model,opt,l2ref
        if device.type=='cuda':torch.cuda.empty_cache()


if __name__=='__main__':main()
