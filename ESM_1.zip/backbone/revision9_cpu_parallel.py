"""Run distinct raw-prediction cohorts on CPU alongside the GPU training queue."""
import concurrent.futures,json,os,subprocess,sys,time
from pathlib import Path
R=Path('/root/ai_paper');O=R/'revision_v9/cpu_assessment';O.mkdir(parents=True,exist_ok=True)
def run(cohort):
 out=O/cohort;out.mkdir(exist_ok=True)
 with (out/'analysis.log').open('w') as log:
  p=subprocess.Popen([sys.executable,str(R/'revision_v9/source/multidimensional_assessment.py'),'--data-root',str(R),'--out',str(out),'--cohort',cohort],stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'CUDA_VISIBLE_DEVICES':'','OMP_NUM_THREADS':'1'})
  (out/'process.json').write_text(json.dumps(dict(pid=p.pid,cohort=cohort,device='cpu')))
  rc=p.wait()
 return dict(cohort=cohort,returncode=rc)
(O/'status.json').write_text(json.dumps(dict(phase='running',workers=3,device='cpu',gpu_training_unchanged=True)))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,['original','equal_time','mixed']))
(O/'status.json').write_text(json.dumps(dict(phase='complete' if all(x['returncode']==0 for x in results) else 'failed',workers=3,results=results)))
