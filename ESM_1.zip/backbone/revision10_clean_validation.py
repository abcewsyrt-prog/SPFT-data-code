"""Post-hoc selection-input audit excluding all optimization-probe corpus positions."""
import sys,json,hashlib,statistics
from pathlib import Path
sys.path.insert(0,'/root/ai_paper/revision_v9/source')
import torch
from transformers import AutoTokenizer
import revision_experiments as R
BASE=Path('/root/ai_paper');OUT=BASE/'revision_v10/clean_validation';OUT.mkdir(parents=True,exist_ok=True);torch.set_num_threads(4);dev=torch.device('cuda')
raw=json.loads((BASE/'revision_v2/data/mmlu_text.json').read_text());tok=AutoTokenizer.from_pretrained(BASE/'models/mamba2-130m-hf');tokens=tok.encode('\n\n'.join(raw['validation']),add_special_tokens=False);digits=R.digit_ids(tok);audit=json.loads((BASE/'revision_v10/probe_input_audit.json').read_text());blocked=[(x['start'],x['end']) for x in audit['probe_intervals']]
manifest=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),audit_type='post-hoc validation-input exclusion sensitivity; all historical test results already available',blocked_intervals=blocked,validation_retrieval_seed=42731,validation_text_seed=42739,n=128,optimization_changed=False,new_training_runs=0,selection_rule='maximum mean validation EM with mean text NLL <= LCR + .02; smaller coefficient breaks ties')
R.atomic_json(OUT/'manifest.json',manifest)
def sample_start(length,g):
 while True:
  s=int(torch.randint(len(tokens)-length,(1,),generator=g))
  if all(max(s,a)>=min(s+length,b) for a,b in blocked):return s
seen=[]
def retrieval(batch,length,depth,g,ids,filler,device,key_len=5):
 targets=ids[torch.randint(10,(batch,key_len),generator=g)];rows=[];positions=[]
 for j in range(batch):
  s=sample_start(length,g);x=list(tokens[s:s+length]);pos=int((length-key_len-1)*depth);x[pos:pos+key_len]=targets[j].tolist();rows.append(x);positions.append(pos);seen.append((s,s+length))
 return torch.tensor(rows,device=device),targets.to(device),positions
def text_batch(filler,batch,length,g,device):
 starts=[sample_start(length,g) for _ in range(batch)];seen.extend((s,s+length) for s in starts);return torch.tensor([tokens[s:s+length] for s in starts],device=device)
R.make_retrieval=retrieval;R.text_batch=text_batch
for tag in ['lcr','aligned_lambda0.1','aligned_lambda1']:
 for seed in range(3):
  dest=OUT/f'seed{seed}_{tag}.json'
  if dest.exists():continue
  R.atomic_json(OUT/'progress.json',dict(tag=tag,seed=seed));p=BASE/f'revision_v2/mamba130_seed{seed}/lcr.pt' if tag=='lcr' else BASE/f'revision_v8/ablations/seed{seed}_{tag}.pt'
  model=R.load_model(BASE/'models/mamba2-130m-hf',dev);model.load_state_dict(torch.load(p,map_location=dev));seen.clear();cells=R.evaluate_keys(model,digits,tokens,dev,128,4,[256,512,1024],[.1,.5,.9],42731);text=R.evaluate_text(model,tokens,dev,128,4,seed=42739)
  assert len(seen)==1280 and all(all(max(s,a)>=min(e,b) for a,b in blocked) for s,e in seen)
  R.atomic_json(dest,dict(tag=tag,seed=seed,checkpoint_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),retrieval=cells,macro_em=statistics.mean(c['full_key_exact_match'] for c in cells.values()),text=text,sampled_intervals=seen,overlap_count=0));print('DONE',tag,seed,flush=True);del model;torch.cuda.empty_cache()
lcr=statistics.mean(json.loads((OUT/f'seed{s}_lcr.json').read_text())['text']['nll'] for s in range(3));candidates=[]
for c in [.1,1.]:
 vs=[json.loads((OUT/f'seed{s}_aligned_lambda{c:g}.json').read_text()) for s in range(3)];candidates.append(dict(coefficient=c,em=statistics.mean(v['macro_em'] for v in vs),nll=statistics.mean(v['text']['nll'] for v in vs)))
eligible=[x for x in candidates if x['nll']<=lcr+.02];selected=max(eligible,key=lambda x:(x['em'],-x['coefficient'])) if eligible else min(candidates,key=lambda x:(x['nll'],-x['em'],x['coefficient']))
R.atomic_json(OUT/'complete.json',dict(status='complete',candidates=candidates,lcr_nll=lcr,selected=selected,eligible=bool(eligible),historical_selected_coefficient=.1,unchanged=selected['coefficient']==.1,all_source_intervals_disjoint_from_probe=True));print('COMPLETE',flush=True)
