"""Unexecuted, validation-selected Mamba L2-SP+replay protocol.

Use the same reference checkpoints and three RNG streams as revision_experiments.
Selection is completed and saved before any candidate test endpoint is evaluated.
Existing scientific drivers and completed results are never overwritten.
"""
import argparse
import hashlib
import json
import random
import statistics
import time
from pathlib import Path
import torch
import revision_experiments as R

COEFFICIENTS = (100., 10000., 1000000.)
SEEDS = (0, 1, 2)
NLL_ALLOWANCE = .02

def select_candidate(candidates, lcr_nll):
    """Arguments contain validation summaries only. Ties favor lower strength."""
    eligible = [r for r in candidates if r['validation_nll'] <= lcr_nll + NLL_ALLOWANCE]
    if not eligible:
        raise ValueError('No coefficient satisfies the prespecified validation NLL bound.')
    return max(eligible, key=lambda r: (r['validation_em'], -r['coefficient']))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--corpus', required=True)
    ap.add_argument('--references', required=True, help='Parent of mamba130_seed0..2 directories')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    if (out/'manifest.json').exists():
        raise FileExistsError('Use a fresh output directory to preserve this protocol.')
    import transformers
    dev = torch.device('cuda')
    torch.set_num_threads(4)
    tok = transformers.AutoTokenizer.from_pretrained(a.model)
    raw = json.loads(Path(a.corpus).read_text())
    tokens = {k: tok.encode('\n\n'.join(raw[k]), add_special_tokens=False)
              for k in ('train', 'validation', 'test')}
    digits = R.digit_ids(tok)
    refs = Path(a.references)
    manifest = dict(vars(a), coefficients=list(COEFFICIENTS), seeds=list(SEEDS),
                    short_updates=600, batch_size=4, replay_probability=.05,
                    lr=1e-4, validation_n=128, validation_retrieval_seed=42731,
                    validation_text_seed=42739, test_n=128,
                    selection='Maximum mean validation macro EM subject to mean NLL <= matched LCR mean + 0.02; ties lower coefficient',
                    torch=torch.__version__, transformers=transformers.__version__,
                    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    common_source_sha256=hashlib.sha256(Path(R.__file__).read_bytes()).hexdigest(),
                    corpus_sha256=hashlib.sha256(Path(a.corpus).read_bytes()).hexdigest())
    R.atomic_json(out/'manifest.json', manifest)
    def evaluate(model, split):
        validation = split == 'validation'
        cells = R.evaluate_keys(model, digits, tokens[split], dev, 128, 4,
                                [256,512,1024], [.1,.5,.9], 42731 if validation else 5719)
        text = R.evaluate_text(model, tokens[split], dev, 128, 4,
                               seed=42739 if validation else 7091)
        return {'retrieval':cells, 'text':text,
                'macro_em':statistics.mean(x['full_key_exact_match'] for x in cells.values())}
    lcr_val = []
    candidates = {c: [] for c in COEFFICIENTS}
    for seed in SEEDS:
        torch.manual_seed(seed)
        random.seed(seed)
        root = refs/f'mamba130_seed{seed}'
        state = torch.load(root/'continued_training.pt', map_location='cpu')
        for mode in ('lcr','spft'):
            model = R.load_model(a.model, dev)
            model.load_state_dict(torch.load(root/(mode+'.pt'), map_location=dev))
            result = evaluate(model, 'validation')
            R.atomic_json(out/f'seed{seed}_{mode}_validation.json', result)
            if mode == 'lcr': lcr_val.append(result['text']['nll'])
            del model
            torch.cuda.empty_cache()
        for coef in COEFFICIENTS:
            tag = f'seed{seed}_l2replay_{int(coef)}'
            model = R.load_model(a.model, dev)
            model.load_state_dict(state)
            reference = {k:p.detach().float().clone() for k,p in model.named_parameters()}
            count = sum(p.numel() for p in model.parameters())
            opt = torch.optim.AdamW(R.parameter_groups(model), lr=1e-4)
            sg = torch.Generator().manual_seed(seed+701)
            rg = torch.Generator().manual_seed(seed+702)
            cg = torch.Generator().manual_seed(seed+703)
            def penalty():
                return coef * sum((p.float()-reference[k]).square().sum()
                                  for k,p in model.named_parameters())/count
            model.train()
            torch.cuda.reset_peak_memory_stats()
            start = time.perf_counter()
            replay_updates = 0
            for step in range(600):
                opt.zero_grad(set_to_none=True)
                x = R.text_batch(tokens['train'],4,64,sg,dev)
                loss = R.next_token_loss(model,x)+penalty()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
                opt.step()
                if float(torch.rand(1,generator=cg)) < .05:
                    depth = float(torch.rand(1,generator=rg))*.8+.1
                    x,y,_ = R.make_retrieval(4,256,depth,rg,digits,tokens['train'],dev)
                    opt.zero_grad(set_to_none=True)
                    loss = R.full_key_loss(model,x,y)+penalty()
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
                    opt.step()
                    replay_updates += 1
                if (step+1)%50 == 0: print(tag,step+1,flush=True)
            torch.cuda.synchronize()
            elapsed = time.perf_counter()-start
            assert replay_updates == json.loads((root/'lcr.json').read_text())['training']['replay_updates']
            peak = torch.cuda.max_memory_allocated()
            torch.save(model.state_dict(),out/(tag+'.pt'))
            val = evaluate(model,'validation')
            result = {'seed':seed,'coefficient':coef,'validation':val,
                      'reference_sha256':hashlib.sha256((root/'continued_training.pt').read_bytes()).hexdigest(),
                      'training':{'short_updates':600,'replay_updates':replay_updates,
                                  'seconds':elapsed,'peak_memory_bytes':peak}}
            R.atomic_json(out/(tag+'.json'),result)
            candidates[coef].append(result)
            del model,opt,reference
            torch.cuda.empty_cache()
    summaries = [{'coefficient':c,
                  'validation_em':statistics.mean(r['validation']['macro_em'] for r in rows),
                  'validation_nll':statistics.mean(r['validation']['text']['nll'] for r in rows)}
                 for c,rows in candidates.items()]
    chosen = select_candidate(summaries,statistics.mean(lcr_val))
    R.atomic_json(out/'selection.json',{'selected':chosen,'candidates':summaries,
                   'lcr_mean_validation_nll':statistics.mean(lcr_val),
                   'test_evaluated_before_selection':False})
    for seed in SEEDS:
        tag = f"seed{seed}_l2replay_{int(chosen['coefficient'])}"
        model = R.load_model(a.model,dev)
        model.load_state_dict(torch.load(out/(tag+'.pt'),map_location=dev))
        result = evaluate(model,'test')
        base = json.loads((refs/f'mamba130_seed{seed}'/'baseline.json').read_text())
        retained = established = 0
        for cell,v in base['retrieval'].items():
            new = result['retrieval'][cell]
            assert v['targets'] == new['targets'] and v['key_positions'] == new['key_positions']
            established += sum(v['hits'])
            retained += sum(y for x,y in zip(v['hits'],new['hits']) if x)
        result['conditional_retention'] = {'retained':retained,'established':established,
                                            'fraction':retained/established}
        probes = []
        for length in (64,256,1024):
            for rep in range(3):
                g = torch.Generator().manual_seed(917331+length*11+rep)
                x = (R.text_batch(tokens['test'],2,length,g,dev) if length == 64 else
                     R.make_retrieval(2,length,.5 if length == 256 else .1,g,digits,tokens['test'],dev)[0])
                probes.append(x)
        current = [R.corrected_spectrum(model,x,detach=True) for x in probes]
        model.load_state_dict(torch.load(refs/f'mamba130_seed{seed}'/'continued_training.pt',map_location=dev))
        reference = [R.corrected_spectrum(model,x,detach=True) for x in probes]
        result['independent_w1'] = [float(R.spectrum_distance(c,r)) for c,r in zip(current,reference)]
        R.atomic_json(out/f'seed{seed}_selected_test.json',result)
        del model
        torch.cuda.empty_cache()
    R.atomic_json(out/'complete.json',{'status':'complete','selected_coefficient':chosen['coefficient']})

if __name__ == '__main__':
    main()
