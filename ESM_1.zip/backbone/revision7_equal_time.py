"""Prospective single-GPU equal-training-time comparison; no test-based selection."""
import argparse,hashlib,json,os,random,statistics,subprocess,time
from pathlib import Path
import torch
import revision_experiments as R
import revision6_extension as X

MODES=('spft','lcr','highreplay')

def scheduled_updates(step,draw_replay,*,budget_seconds=None,short_updates=None,clock=time.perf_counter,progress=None):
    if (budget_seconds is None)==(short_updates is None):raise ValueError('Choose one stopping rule')
    if budget_seconds is not None and budget_seconds<=0:raise ValueError('Nonpositive budget')
    if short_updates is not None and short_updates<=0:raise ValueError('Nonpositive update count')
    start=clock();ns=nr=0;last=0.;pending=False
    def expired():return budget_seconds is not None and clock()-start>=budget_seconds
    while short_updates is None or ns<short_updates:
        if expired():break
        before=clock();step('short');last=clock()-before;ns+=1
        pending=bool(draw_replay())
        if pending:
            if expired():break
            before=clock();step('replay');last=clock()-before;nr+=1;pending=False
        if progress and ns%50==0:progress(ns,nr,clock()-start)
    elapsed=clock()-start
    return dict(short_updates=ns,replay_updates=nr,seconds=elapsed,
                budget_seconds=budget_seconds,last_optimizer_step_seconds=last,
                budget_overrun_seconds=max(0.,elapsed-budget_seconds) if budget_seconds else 0.,
                replay_selected_but_not_executed=pending)

def gpu_guard():
    rows=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True)
    others=[int(v.strip()) for v in rows.splitlines() if v.strip().isdigit() and int(v.strip())!=os.getpid()]
    if others:raise RuntimeError(f'GPU must be dedicated; other process IDs {others}')

def train(model,tokens,digits,probe,reference,state,seed,mode,device,budget=None):
    probability=.30 if mode=='highreplay' else .05
    # Warm up task kernels independently, then restore the full reference and reset optimizer/RNG.
    warm=torch.optim.AdamW(R.parameter_groups(model),lr=1e-4)
    wg=torch.Generator().manual_seed(899001+seed)
    model.train()
    for kind in ('short','replay'):
        warm.zero_grad(set_to_none=True)
        if kind=='short':loss=R.next_token_loss(model,R.text_batch(tokens,4,64,wg,device))
        else:
            x,y,_=R.make_retrieval(4,256,.5,wg,digits,tokens,device);loss=R.full_key_loss(model,x,y)
        if mode=='spft':loss=loss+R.spectrum_distance(R.corrected_spectrum(model,probe),reference)
        loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);warm.step()
    torch.cuda.synchronize();del warm;model.load_state_dict(state);model.zero_grad(set_to_none=True)
    torch.manual_seed(seed);random.seed(seed)
    opt=torch.optim.AdamW(R.parameter_groups(model),lr=1e-4)
    sg=torch.Generator().manual_seed(seed+701);rg=torch.Generator().manual_seed(seed+702);cg=torch.Generator().manual_seed(seed+703)
    def step(kind):
        opt.zero_grad(set_to_none=True)
        if kind=='short':loss=R.next_token_loss(model,R.text_batch(tokens,4,64,sg,device))
        else:
            depth=float(torch.rand(1,generator=rg))*.8+.1
            x,y,_=R.make_retrieval(4,256,depth,rg,digits,tokens,device);loss=R.full_key_loss(model,x,y)
        if mode=='spft':loss=loss+R.spectrum_distance(R.corrected_spectrum(model,probe),reference)
        loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step();torch.cuda.synchronize()
    gpu_guard();torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize()
    record=scheduled_updates(step,lambda:float(torch.rand(1,generator=cg))<probability,
                             short_updates=600 if mode=='spft' else None,budget_seconds=budget,
                             progress=lambda a,b,t:print('TRAIN',seed,mode,a,b,round(t,2),flush=True))
    gpu_guard();record.update(replay_probability=probability,peak_memory_bytes=torch.cuda.max_memory_allocated(),warmup_restored=True,
                             short_predicted_tokens=record['short_updates']*4*63,replay_input_tokens=record['replay_updates']*4*256)
    if budget is not None:
        assert record['seconds']>=budget
        assert record['budget_overrun_seconds']<=record['last_optimizer_step_seconds']+.25,'Budget exceeded by more than one step'
    return record

def main():
    ap=argparse.ArgumentParser()
    for k in ('model','corpus','references','out'):ap.add_argument('--'+k,required=True)
    a=ap.parse_args();import transformers
    torch.set_num_threads(4);dev=torch.device('cuda');out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    manifest=dict(vars(a),seeds=[0,1,2],modes=list(MODES),method_order={'0':list(MODES),'1':['spft','highreplay','lcr'],'2':list(MODES)},batch=4,lr=1e-4,spft_lambda=1.,anchor_short_updates=600,
                  stopping='Same per-seed SPFT600 elapsed training time; stop at first completed optimizer step at/after deadline',
                  timing='Synchronized optimizer boundaries; includes sampling, forward/backward, clipping and update; excludes restored warmup, initialization, evaluation and checkpoint IO',
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  common_sha256=hashlib.sha256(Path(R.__file__).read_bytes()).hexdigest(),
                  extension_sha256=hashlib.sha256(Path(X.__file__).read_bytes()).hexdigest(),
                  corpus_sha256=hashlib.sha256(Path(a.corpus).read_bytes()).hexdigest(),
                  torch=torch.__version__,transformers=transformers.__version__,selection='none; fixed p=.05/.30, all seeds')
    if (out/'manifest.json').exists():assert json.loads((out/'manifest.json').read_text())==manifest
    else:R.atomic_json(out/'manifest.json',manifest)
    tok=transformers.AutoTokenizer.from_pretrained(a.model);raw=json.loads(Path(a.corpus).read_text());tokens={k:tok.encode('\n\n'.join(raw[k]),add_special_tokens=False) for k in raw};digits=R.digit_ids(tok)
    for seed in (0,1,2):
        if (out/f'seed{seed}_complete.json').exists():continue
        refpath=Path(a.references)/f'mamba130_seed{seed}/continued_training.pt';state=torch.load(refpath,map_location='cpu');base=json.loads((refpath.parent/'baseline.json').read_text());budget=None
        for mode in (MODES if seed%2==0 else ('spft','highreplay','lcr')):
            path=out/f'seed{seed}_{mode}.json'
            if path.exists():
                v=json.loads(path.read_text())
                if mode=='spft':budget=v['training']['seconds']
                continue
            torch.manual_seed(seed);random.seed(seed);model=R.load_model(a.model,dev);model.load_state_dict(state)
            probe=R.make_retrieval(2,256,.5,torch.Generator().manual_seed(90210),digits,tokens['validation'],dev)[0]
            reference=R.corrected_spectrum(model,probe,detach=True)
            R.atomic_json(out/'progress.json',dict(seed=seed,mode=mode,phase='training',budget_seconds=budget))
            training=train(model,tokens['train'],digits,probe,reference,state,seed,mode,dev,budget)
            if mode=='spft':budget=training['seconds']
            torch.save(model.state_dict(),out/f'seed{seed}_{mode}.pt')
            R.atomic_json(out/'progress.json',dict(seed=seed,mode=mode,phase='evaluation',training=training))
            v=X.endpoint(model,tokens['test'],digits,dev);num=den=0
            for key,c in v['retrieval'].items():
                b=base['retrieval'][key];assert c['targets']==b['targets'] and c['key_positions']==b['key_positions'];den+=sum(b['hits']);num+=sum(z for h,z in zip(b['hits'],c['hits']) if h)
            v.update(seed=seed,mode=mode,training=training,reference_sha256=hashlib.sha256(refpath.read_bytes()).hexdigest(),conditional_retention=dict(retained=num,established=den,fraction=num/den if den else None))
            v['optimized_probe_w1']=float(R.spectrum_distance(R.corrected_spectrum(model,probe,detach=True),reference));v['independent_w1']=X.independent_probes(model,state,tokens['test'],digits,dev)
            R.atomic_json(path,v);del model;torch.cuda.empty_cache()
        R.atomic_json(out/f'seed{seed}_complete.json',dict(status='complete'))
    R.atomic_json(out/'complete.json',dict(status='complete'))
if __name__=='__main__':main()
