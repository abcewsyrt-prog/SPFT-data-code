"""CPU-only reconstruction of optimization and selection input provenance."""
import json,hashlib,os
from pathlib import Path
os.environ['TOKENIZERS_PARALLELISM']='false'
import torch
from transformers import AutoTokenizer
R=Path('/root/ai_paper');O=R/'revision_v10';torch.set_num_threads(1)
tok=AutoTokenizer.from_pretrained(R/'models/mamba2-130m-hf');raw=json.loads((R/'revision_v2/data/mmlu_text.json').read_text());tokens={k:tok.encode('\n\n'.join(raw[k]),add_special_tokens=False) for k in raw};digits=torch.tensor([tok.encode(str(i),add_special_tokens=False)[0] for i in range(10)])
def retrieval(n,batch,length,depth,seed):
 g=torch.Generator().manual_seed(seed);rows=[]
 for offset in range(0,n,batch):
  count=min(batch,n-offset);targets=digits[torch.randint(10,(count,5),generator=g)]
  for b in range(count):
   start=int(torch.randint(len(tokens['validation'])-length,(1,),generator=g));x=list(tokens['validation'][start:start+length]);pos=int((length-6)*depth);x[pos:pos+5]=targets[b].tolist();rows.append(dict(start=start,end=start+length,input_sha256=hashlib.sha256(torch.tensor(x,dtype=torch.int64).numpy().tobytes()).hexdigest()))
 return rows
probe=retrieval(2,2,256,.5,90210);selection=[]
for length in [256,512,1024]:
 for depth in [.1,.5,.9]:selection+=retrieval(128,4,length,depth,42731+length*1000+round(depth*100))
g=torch.Generator().manual_seed(42739);text=[]
for offset in range(0,128,4):
 for start in torch.randint(len(tokens['validation'])-64,(4,),generator=g).tolist():text.append(dict(start=start,end=start+64))
def overlaps(a,b):return max(a['start'],b['start'])<min(a['end'],b['end'])
report=dict(status='complete',optimization_probe_corpus='validation',optimization_probe_seed=90210,optimization_probe_n=2,selection_retrieval_seed=42731,selection_text_seed=42739,selection_examples=len(selection),selection_exact_input_overlap=sum(x['input_sha256'] in {p['input_sha256'] for p in probe} for x in selection),selection_retrieval_shared_underlying_intervals=sum(any(overlaps(x,p) for p in probe) for x in selection),selection_text_shared_underlying_intervals=sum(any(overlaps(x,p) for p in probe) for x in text),shared_validation_corpus=True,probe_intervals=probe,test_document_overlap_with_validation=len(set(raw['test'])&set(raw['validation'])),interpretation='Distinct full inputs do not imply independent source corpus; test corpus remains separate.')
(O/'probe_input_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
