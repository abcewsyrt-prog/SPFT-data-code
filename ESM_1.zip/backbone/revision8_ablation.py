"""Frozen, targeted SPFT ablations after equal-time and mixed-reference cohorts."""
import argparse,hashlib,json,random,statistics,time
from pathlib import Path
import torch
import revision_experiments as R
import revision6_extension as X
from revision7_equal_time import gpu_guard

COEFFICIENTS=(.1,1.,10.)
CONFIGS=[dict(tag='spft_lambda01',family='spft',coefficient=.1,p=.05,probe_seed=90210),
         dict(tag='spft_lambda10',family='spft',coefficient=10.,p=.05,probe_seed=90210),
         *[dict(tag=f'aligned_lambda{c:g}',family='aligned',coefficient=c,p=.05,probe_seed=90210) for c in COEFFICIENTS],
         dict(tag='spft_highreplay',family='spft',coefficient=1.,p=.30,probe_seed=90210),
         dict(tag='spft_probe90211',family='spft',coefficient=1.,p=.05,probe_seed=90211)]

def choose_aligned(candidates,lcr_nll):
    eligible=[v for v in candidates if v['validation_nll']<=lcr_nll+.02]
    if eligible:return dict(eligible=True,selected=max(eligible,key=lambda v:(v['validation_em'],-v['coefficient'])),rule='maximum EM within LCR NLL + .02')
    return dict(eligible=False,selected=min(candidates,key=lambda v:(v['validation_nll'],-v['validation_em'],v['coefficient'])),rule='no eligible candidate; lowest NLL diagnostic endpoint')

def fit(model,state,tokens,digits,probe,reference,seed,config,device):
    def penalty():return config['coefficient']*R.spectrum_distance(R.corrected_spectrum(model,probe),reference,aligned=config['family']=='aligned')
    gpu_guard();model.train();warm=torch.optim.AdamW(R.parameter_groups(model),lr=1e-4);wg=torch.Generator().manual_seed(899001+seed)
    for kind in ('short','replay'):
        warm.zero_grad(set_to_none=True)
        if kind=='short':loss=R.next_token_loss(model,R.text_batch(tokens,4,64,wg,device))
        else:
            x,y,_=R.make_retrieval(4,256,.5,wg,digits,tokens,device);loss=R.full_key_loss(model,x,y)
        (loss+penalty()).backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);warm.step()
    torch.cuda.synchronize();del warm;model.load_state_dict(state);model.zero_grad(set_to_none=True);torch.manual_seed(seed);random.seed(seed)
    opt=torch.optim.AdamW(R.parameter_groups(model),lr=1e-4);sg=torch.Generator().manual_seed(seed+701);rg=torch.Generator().manual_seed(seed+702);cg=torch.Generator().manual_seed(seed+703)
    gpu_guard();torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize();start=time.perf_counter();replays=0
    for step in range(600):
        opt.zero_grad(set_to_none=True);loss=R.next_token_loss(model,R.text_batch(tokens,4,64,sg,device))+penalty();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step();torch.cuda.synchronize()
        if float(torch.rand(1,generator=cg))<config['p']:
            depth=float(torch.rand(1,generator=rg))*.8+.1;x,y,_=R.make_retrieval(4,256,depth,rg,digits,tokens,device)
            opt.zero_grad(set_to_none=True);loss=R.full_key_loss(model,x,y)+penalty();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step();torch.cuda.synchronize();replays+=1
        if (step+1)%50==0:print('TRAIN',config['tag'],seed,step+1,flush=True)
    elapsed=time.perf_counter()-start;gpu_guard()
    return dict(short_updates=600,replay_updates=replays,replay_probability=config['p'],seconds=elapsed,peak_memory_bytes=torch.cuda.max_memory_allocated(),warmup_restored=True)

def validation(model,tokens,digits,device):
    cells=R.evaluate_keys(model,digits,tokens,device,128,4,[256,512,1024],[.1,.5,.9],42731)
    return dict(retrieval=cells,macro_em=statistics.mean(v['full_key_exact_match'] for v in cells.values()),text=R.evaluate_text(model,tokens,device,128,4,seed=42739))

def main():
    ap=argparse.ArgumentParser()
    for key in ('model','corpus','references','anchor','matched','out'):ap.add_argument('--'+key,required=True)
    a=ap.parse_args();import transformers
    torch.set_num_threads(4);dev=torch.device('cuda');out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    manifest=dict(vars(a),seeds=[0,1,2],configs=CONFIGS,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),common_sha256=hashlib.sha256(Path(R.__file__).read_bytes()).hexdigest(),extension_sha256=hashlib.sha256(Path(X.__file__).read_bytes()).hexdigest(),corpus_sha256=hashlib.sha256(Path(a.corpus).read_bytes()).hexdigest(),torch=torch.__version__,transformers=transformers.__version__,selection='SPFT coefficients are sensitivity endpoints; aligned coefficient chosen globally on validation only')
    if (out/'manifest.json').exists():assert json.loads((out/'manifest.json').read_text())==manifest
    else:R.atomic_json(out/'manifest.json',manifest)
    tok=transformers.AutoTokenizer.from_pretrained(a.model);raw=json.loads(Path(a.corpus).read_text());tokens={k:tok.encode('\n\n'.join(raw[k]),add_special_tokens=False) for k in raw};digits=R.digit_ids(tok)
    def reference(seed):
        p=Path(a.references)/f'mamba130_seed{seed}/continued_training.pt';return p,torch.load(p,map_location='cpu')
    # Fit every candidate and save validation before any newly trained candidate test.
    for config in CONFIGS:
        for seed in range(3):
            tag=f'seed{seed}_{config["tag"]}';f=out/(tag+'_validation.json')
            if f.exists():continue
            R.atomic_json(out/'progress.json',dict(phase='training_validation',config=config['tag'],seed=seed))
            gpu_guard();refpath,state=reference(seed);torch.manual_seed(seed);random.seed(seed);model=R.load_model(a.model,dev);model.load_state_dict(state)
            probe=R.make_retrieval(2,256,.5,torch.Generator().manual_seed(config['probe_seed']),digits,tokens['validation'],dev)[0];ref=R.corrected_spectrum(model,probe,detach=True)
            training=fit(model,state,tokens['train'],digits,probe,ref,seed,config,dev);torch.save(model.state_dict(),out/(tag+'.pt'))
            val=validation(model,tokens['validation'],digits,dev)
            R.atomic_json(f,dict(seed=seed,config=config,training=training,reference_sha256=hashlib.sha256(refpath.read_bytes()).hexdigest(),validation=val));del model,state;torch.cuda.empty_cache()
    # Reuse completed R7 coefficient-1 SPFT weights, never rerun or pool a new reference.
    for seed in range(3):
        dest=out/f'seed{seed}_spft_lambda1_validation.json'
        if dest.exists():continue
        gpu_guard();model=R.load_model(a.model,dev);model.load_state_dict(torch.load(Path(a.anchor)/f'seed{seed}_spft.pt',map_location=dev));val=validation(model,tokens['validation'],digits,dev)
        anchor=json.loads((Path(a.anchor)/f'seed{seed}_spft.json').read_text())
        R.atomic_json(dest,dict(seed=seed,config=dict(tag='spft_lambda1',family='spft',coefficient=1.,p=.05,probe_seed=90210),training=anchor['training'],reference_sha256=anchor['reference_sha256'],validation=val,reused_anchor=True));del model;torch.cuda.empty_cache()
    candidates=[]
    for c in COEFFICIENTS:
        vs=[json.loads((out/f'seed{s}_aligned_lambda{c:g}_validation.json').read_text())['validation'] for s in range(3)]
        candidates.append(dict(coefficient=c,validation_em=statistics.mean(v['macro_em'] for v in vs),validation_nll=statistics.mean(v['text']['nll'] for v in vs)))
    lcr_nll=statistics.mean(json.loads((Path(a.matched)/f'seed{s}_lcr_validation.json').read_text())['text']['nll'] for s in range(3))
    selection=dict(choose_aligned(candidates,lcr_nll),candidates=candidates,lcr_mean_validation_nll=lcr_nll,new_candidate_tests_evaluated_before_selection=False,lambda1_spft_historical_test_already_available=True)
    path=out/'selection.json'
    if path.exists():assert json.loads(path.read_text())==selection
    else:R.atomic_json(path,selection)
    selected=selection['selected']['coefficient']
    tests=[c for c in CONFIGS if c['family']!='aligned' or c['coefficient']==selected]
    for config in tests:
        for seed in range(3):
            tag=f'seed{seed}_{config["tag"]}';dest=out/(tag+'_test.json')
            if dest.exists():continue
            R.atomic_json(out/'progress.json',dict(phase='test',config=config['tag'],seed=seed))
            refpath,state=reference(seed);base=json.loads((refpath.parent/'baseline.json').read_text());model=R.load_model(a.model,dev);model.load_state_dict(torch.load(out/(tag+'.pt'),map_location=dev));v=X.endpoint(model,tokens['test'],digits,dev)
            num=den=0
            for key,c in v['retrieval'].items():
                b=base['retrieval'][key];assert c['targets']==b['targets'] and c['key_positions']==b['key_positions'];den+=sum(b['hits']);num+=sum(z for h,z in zip(b['hits'],c['hits']) if h)
            trained=json.loads((out/(tag+'_validation.json')).read_text())
            v.update(seed=seed,config=config,training=trained['training'],reference_sha256=trained['reference_sha256'],conditional_retention=dict(retained=num,established=den,fraction=num/den if den else None))
            probe=R.make_retrieval(2,256,.5,torch.Generator().manual_seed(config['probe_seed']),digits,tokens['validation'],dev)[0];current=R.corrected_spectrum(model,probe,detach=True);model.load_state_dict(state);ref=R.corrected_spectrum(model,probe,detach=True);v['optimized_probe_w1']=float(R.spectrum_distance(current,ref));v['optimized_probe_aligned_distance']=float(R.spectrum_distance(current,ref,aligned=True));model.load_state_dict(torch.load(out/(tag+'.pt'),map_location=dev));v['independent_w1']=X.independent_probes(model,state,tokens['test'],digits,dev)
            R.atomic_json(dest,v);del model,state;torch.cuda.empty_cache()
    R.atomic_json(out/'complete.json',dict(status='complete',new_training_runs=21,new_test_endpoints=15,selected_aligned_coefficient=selected))
if __name__=='__main__':main()
