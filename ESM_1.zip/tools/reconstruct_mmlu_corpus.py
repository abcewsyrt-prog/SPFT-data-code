"""Rebuild the exact corpus from content-verified public Parquet files.

Run from supplement root:
python tools/reconstruct_mmlu_corpus.py --source-dir data/mmlu --out data/rebuilt
Use --download to obtain missing public source files. Requires pyarrow.
"""
import argparse
import hashlib
import json
import urllib.request
from pathlib import Path
import pyarrow.parquet as pq

R = Path(__file__).resolve().parents[1]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source-dir', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--download', action='store_true')
    args = ap.parse_args()
    spec = json.loads((R / 'reproducibility/mmlu_source_manifest.json').read_text())
    meta = json.loads((R / 'reproducibility/mmlu_text_metadata.json').read_text())
    args.source_dir.mkdir(parents=True, exist_ok=True)
    result = {}
    for split, info in spec['sources'].items():
        path = args.source_dir / info['filename']
        if not path.exists() and args.download:
            temp = path.with_suffix('.partial')
            urllib.request.urlretrieve(info['url'], temp)
            if digest(temp) != info['sha256']:
                temp.unlink()
                raise ValueError('Public source content changed: ' + split)
            temp.replace(path)
        if digest(path) != info['sha256']:
            raise ValueError('Source fingerprint mismatch: ' + split)
        mapping = {}
        for row in pq.read_table(path).to_pylist():
            text = row['question'].strip() + '\n' + '\n'.join(
                chr(65 + i) + '. ' + v for i, v in enumerate(row['choices']))
            key = hashlib.sha256(' '.join(text.split()).encode()).hexdigest()
            mapping.setdefault(key, text)
        result[split] = [mapping[h] for h in meta['document_sha256'][split]]
    payload = json.dumps(result).encode()
    if hashlib.sha256(payload).hexdigest() != spec['corpus_sha256']:
        raise ValueError('Reconstructed corpus fingerprint mismatch')
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / 'mmlu_text.json').write_bytes(payload)
    print('Verified exact corpus', spec['corpus_sha256'])

if __name__ == '__main__':
    main()
