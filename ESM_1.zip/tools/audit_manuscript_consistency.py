"""Audit rendered numeric reports against their source cohorts and language versions."""
import json,re,statistics,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];D=R/'results';P=R/'paper'
def load(p):return json.loads(p.read_text())
def stats(xs):return {'mean':statistics.mean(xs),'sd':statistics.stdev(xs)}
def pairs(v):
 out=[]
 if isinstance(v,dict):
  if 'mean' in v and isinstance(v.get('sd'),(int,float)):out.append((v['mean'],v['sd']))
  for x in v.values():out.extend(pairs(x))
 elif isinstance(v,list):
  for x in v:out.extend(pairs(x))
 return out
s=(P/'manuscript.tex').read_text();head,s=s.split(r'\end{filecontents*}',1);m=(P/'manuscript.md').read_text();z=(P/'manuscript_zh.md').read_text()
tex=re.findall(r'\\begin\{tabular\}\{[^}]+\}(.*?)\\end\{tabular\}',s,re.S)
def tables(t):return re.findall(r'(?m)^\|[^\n]+\|\n\|[-| ]+\|\n(?:\|[^\n]+\|\n?)+',t)
mt,zt=tables(m),tables(z);assert len(tex)==len(mt)==len(zt) and len(tex) in (16,17)
for a,b,c in zip(tex,mt,zt):
 number=lambda t:re.findall(r'[-+]?\d+(?:\.\d+)?',t)
 assert number(a.split(r'\midrule',1)[1])==number('\n'.join(b.splitlines()[2:])), 'TeX/English table discrepancy'
 assert number('\n'.join(b.splitlines()[2:]))==number('\n'.join(c.splitlines()[2:])), 'English/Chinese table discrepancy'
b=load(D/'revision_v2/backbone_summary.json');v=load(D/'revision_v3/summary.json');pool={i:[] for i in range(1,18)}
pool[1]=pairs(b)+pairs(v['independent_probes']);
for arch in ['mamba130','rwkv400']:
 base=[load(D/f'revision_v2/{arch}_seed{i}/baseline.json') for i in range(3)]
 pool[1].append(tuple(stats([statistics.mean(c['full_key_exact_match'] for c in x['retrieval'].values()) for x in base]).values()))
pool[1].append((0.,0.))
pool[4]=pairs(b['architectures']['mamba130']);pool[5]=pairs(b['architectures']['rwkv400']);pool[6]=pairs(v['independent_probes']);pool[3]=pool[7]=pairs(v['tasks'])
# Recompute the newer cohorts directly from per-seed endpoint files.
def endpoint_rows(folder,pattern,basefolder=None):
 vs=[load(D/folder/pattern.format(s=i)) for i in range(3)];values={}
 for i,x in enumerate(vs):
  em=statistics.mean(c['full_key_exact_match'] for c in x['retrieval'].values());q=x.get('conditional_retention',{}).get('fraction')
  if q is None:
   base=load(D/f'revision_v2/mamba130_seed{i}/baseline.json');q=sum(sum(h*k for h,k in zip(base['retrieval'][j]['hits'],c['hits'])) for j,c in x['retrieval'].items())/sum(sum(c['hits']) for c in base['retrieval'].values())
  metrics={'em':em,'q':q,'nll':x['text']['nll']}
  if 'independent_w1' in x:metrics['w']=statistics.mean(x['independent_w1'])
  for k,n in x.get('training',{}).items():
   if isinstance(n,(int,float)) and not isinstance(n,bool):metrics[k]=n/(1024**3) if k=='peak_memory_bytes' else n
  for k,n in metrics.items():values.setdefault(k,[]).append(n)
 return [(t['mean'],t['sd']) for k,x in values.items() if len(x)==3 for t in [stats(x)]]
for mode in ['lcr','spft','highreplay']:
 pp=endpoint_rows('revision_v7/equal_time',f'seed{{s}}_{mode}.json');pool[13]+=pp;pool[14]+=pp
pool[2]=pairs(load(D/'revision_v3/backbone_conditional_retention.json'))+pairs(b)+pairs(v['independent_probes'])+endpoint_rows('revision_v6/highreplay','seed{s}_highreplay.json')+endpoint_rows('revision_v9/assessment','seed{s}_spft_highreplay_test.json')
for mode in ['lcr','spft']:pool[15]+=endpoint_rows('revision_v6/mixed',f'seed{{s}}_{mode}.json')
for tag in ['spft_lambda01','spft_lambda10','aligned_lambda0.1']:pool[16]+=endpoint_rows('revision_v9/assessment',f'seed{{s}}_{tag}_test.json')
pool[16]+=endpoint_rows('revision_v7/equal_time','seed{s}_spft.json')
for mode in ['vanilla','lcr','spec_reg','spft','highreplay','l2replay']:
 rows=[r for r in load(D/'revision_v3/cost/results.json')['rows'] if r['mode']==mode]
 if len(rows)==3:pool[9]+=[tuple(stats([x[k]/(1024**3 if k=='peak_memory_bytes' else 1) for x in rows]).values()) for k in ['seconds','peak_memory_bytes']]
# Source modes can have a coefficient suffix; retain actual mode groups.
cost=load(D/'revision_v3/cost/results.json')['rows']
for mode in {x['mode'] for x in cost}:
 rows=[x for x in cost if x['mode']==mode]
 pool[9]+=[tuple(stats([x[k]/(1024**3 if k=='peak_memory_bytes' else 1) for x in rows]).values()) for k in ['seconds','peak_memory_bytes']]
sw=load(D/'revision_v10/swaps_compatible/results.json')['results']
new=load(D/'revision_v10/controlled_summary.json')
pool[10]=pairs(new['swaps']);pool[11]=pairs(new['interpolation'])
raw=[load(D/f'revision_v3/rwkv_lambda01_seed{i}/spft.json') for i in range(3)]
for field in ['em','nll','w']:
 xs=[statistics.mean(c['full_key_exact_match'] for c in x['retrieval'].values()) if field=='em' else x['text']['nll'] if field=='nll' else x['spectral_w1'] for x in raw]
 if isinstance(xs[0],(int,float)):pool[12].append(tuple(stats(xs).values()))
# Exact per-seed comparisons do not carry ± summaries.
if (D/'revision_v11/summary.json').exists():pool[17]=pairs(load(D/'revision_v11/summary.json'))
original_order=['tab:backbone','tab:replay_intensity','tab:controlled','tab:cells_mamba130','tab:cells_rwkv400','tab:heldout','tab:extended','tab:paired','tab:cost','tab:swaps','tab:interpolation','tab:rwkv_sensitivity','tab:equal_time','tab:equal_resources','tab:mixed_acquisition','tab:mamba_sensitivity','tab:gradient_path']
blocks=re.findall(r'\\begin\{table\}.*?\\end\{table\}',s,re.S)
checked=0
for block,t in zip(blocks,tex):
 label=re.search(r'\\label\{([^}]+)\}',block)[1];i=original_order.index(label)+1
 if i==8:continue
 for a,bv in re.findall(r'([0-9]+\.[0-9]+)\\pm([0-9]+\.[0-9]+)',t):
  found=any(f'{x:.{len(a.split(".")[1])}f}'==a and f'{y:.{len(bv.split(".")[1])}f}'==bv for x,y in pool[i]);assert found,(label,a,bv);checked+=1
labels=re.findall(r'\\label\{([^}]+)\}',s);assert len(labels)==len(set(labels));assert set(re.findall(r'\\ref\{([^}]+)\}',s))<=set(labels)
assert not re.search(r'\d(?<!\\)%',s)
for f in re.findall(r'\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}',s):assert (P/f).exists()
assert re.findall(r'\$\$.*?\$\$',m,re.S)==re.findall(r'\$\$.*?\$\$',z,re.S)
old=(P/'backups/consistency_20261023/manuscript.tex').read_text().split(r'\end{filecontents*}',1)[0];assert head==old
report=dict(status='passed',tables=len(tex),mean_sd_pairs_checked_against_sources=checked,three_language_formats_numeric_tables_identical=True,display_equations_identical=True,all_references_resolved=True,class_prefix_unchanged=True,unit_policy='s; GiB=2^30 bytes; nats/token; table rates 0-1; abstract percentages',tex_sha256=hashlib.sha256((P/'manuscript.tex').read_bytes()).hexdigest())
(P/'consistency_audit_20261023.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
