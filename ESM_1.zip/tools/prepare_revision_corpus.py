"""Build a document-disjoint natural-text corpus from already cached public MMLU.

Uses question and choice text, never answer labels. Adaptation endpoint is language
modeling NLL/accuracy, not multiple-choice answer accuracy.
"""
import argparse,hashlib,json
from pathlib import Path
from datasets import Dataset

ap=argparse.ArgumentParser();ap.add_argument('--cache',required=True);ap.add_argument('--out',required=True)
a=ap.parse_args();cache=Path(a.cache);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
files={k:next(cache.rglob('mmlu-'+v+'.arrow')) for k,v in [('test','test'),('validation','validation'),('train','auxiliary_train')]}
limits={'train':10000,'validation':1024,'test':2048}
seen=set();result={};meta={'dataset':'cais/mmlu','config':'all','content':'question and choice text, excluding answer labels','split_sources':{},'split_counts':{},'document_sha256':{}}
# Reserve evaluation documents first, then remove any exact normalized duplicate.
for split in ['test','validation','train']:
 docs=[];hashes=[]
 for row in Dataset.from_file(str(files[split])):
  text=row['question'].strip()+'\n'+'\n'.join(chr(65+i)+'. '+v for i,v in enumerate(row['choices']))
  key=hashlib.sha256(' '.join(text.split()).encode()).hexdigest()
  if key in seen:continue
  seen.add(key);docs.append(text);hashes.append(key)
  if len(docs)>=limits[split]:break
 result[split]=docs;meta['split_sources'][split]=str(files[split]);meta['split_counts'][split]=len(docs);meta['document_sha256'][split]=hashes
(out/'mmlu_text.json').write_text(json.dumps(result));(out/'mmlu_text_metadata.json').write_text(json.dumps(meta,indent=2));print(meta['split_counts'])
