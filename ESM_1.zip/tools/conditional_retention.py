"""Recompute seed-level retention among paired pre-adaptation correct examples."""
import argparse,json,statistics
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();root=Path(a.root);out={}
for arch in ['mamba130','rwkv400']:
 out[arch]={}
 for mode in ['vanilla','lcr','spec_reg','spft']:
  rows=[]
  for seed in range(3):
   d=root/f'{arch}_seed{seed}';b=json.loads((d/'baseline.json').read_text());r=json.loads((d/(mode+'.json')).read_text());num=den=0
   for cell,bv in b['retrieval'].items():
    rv=r['retrieval'][cell];assert bv['targets']==rv['targets'] and bv['key_positions']==rv['key_positions'];den+=sum(bv['hits']);num+=sum(y for x,y in zip(bv['hits'],rv['hits']) if x)
   rows.append({'seed':seed,'retained_hits':num,'baseline_hits':den,'conditional_retention':num/den})
  values=[x['conditional_retention'] for x in rows];out[arch][mode]={'values':rows,'mean':statistics.mean(values),'sd':statistics.stdev(values)}
Path(a.out).write_text(json.dumps(out,indent=2));print('Paired conditional retention recomputed.')
