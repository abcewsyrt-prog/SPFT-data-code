"""Validate complete main-cohort comparisons before producing manuscript metrics."""
from pathlib import Path
import hashlib,json,math,statistics,sys
R=Path(__file__).resolve().parents[1]
D=R/'results/revision_v5/matched_original'
sys.path.insert(0,str(R/'backbone'))
from revision5_matched_control import COEFFICIENTS,select_candidate

def summary(values):
    return {'values':values,'mean':statistics.mean(values),'sd':statistics.stdev(values)}

def check_endpoint(v):
    assert len(v['retrieval'])==9
    for cell,x in v['retrieval'].items():
        assert x['n']==128 and len(x['hits'])==len(x['predictions'])==len(x['targets'])==128
        assert x['hits']==[int(a==b) for a,b in zip(x['predictions'],x['targets'])]
        assert x['full_key_exact_match']==sum(x['hits'])/128
    assert v['macro_em']==statistics.mean(x['full_key_exact_match'] for x in v['retrieval'].values())
    assert math.isfinite(v['text']['nll'])

def main():
    needed=[D/'complete.json',D/'selection.json']+[D/f'seed{s}_selected_test.json' for s in range(3)]
    if not all(p.exists() for p in needed):
        print(json.dumps({'status':'pending','missing':[p.name for p in needed if not p.exists()]}));return
    manifest=json.loads((D/'manifest.json').read_text())
    assert manifest['source_sha256']==hashlib.sha256((R/'backbone/revision5_matched_control.py').read_bytes()).hexdigest()
    assert manifest['common_source_sha256']==hashlib.sha256((R/'backbone/revision_experiments.py').read_bytes()).hexdigest()
    assert manifest['corpus_sha256']=='e5a3d2f2d1ede5988076a70d076e908733b0fa2b70a3982d09f2a34984c50688'
    candidates=[];hashes={s:set() for s in range(3)}
    lcr=[json.loads((D/f'seed{s}_lcr_validation.json').read_text()) for s in range(3)]
    for v in lcr:check_endpoint(v)
    for coefficient in COEFFICIENTS:
        rows=[]
        for seed in range(3):
            v=json.loads((D/f'seed{seed}_l2replay_{int(coefficient)}.json').read_text())
            assert v['seed']==seed and v['coefficient']==coefficient
            assert v['training']['short_updates']==600
            original=json.loads((R/f'results/revision_v2/mamba130_seed{seed}/lcr.json').read_text())
            assert v['training']['replay_updates']==original['training']['replay_updates']
            hashes[seed].add(v['reference_sha256']);check_endpoint(v['validation']);rows.append(v['validation'])
            for cell,x in v['validation']['retrieval'].items():
                assert x['targets']==lcr[seed]['retrieval'][cell]['targets']
                assert x['key_positions']==lcr[seed]['retrieval'][cell]['key_positions']
        candidates.append({'coefficient':coefficient,'validation_em':statistics.mean(v['macro_em'] for v in rows),'validation_nll':statistics.mean(v['text']['nll'] for v in rows)})
    assert all(len(v)==1 for v in hashes.values())
    selection=json.loads((D/'selection.json').read_text());nll=statistics.mean(v['text']['nll'] for v in lcr)
    assert selection['test_evaluated_before_selection'] is False
    assert selection['selected']==select_candidate(candidates,nll)
    assert selection['candidates']==candidates
    tests=[]
    for seed in range(3):
        v=json.loads((D/f'seed{seed}_selected_test.json').read_text());check_endpoint(v)
        b=json.loads((R/f'results/revision_v2/mamba130_seed{seed}/baseline.json').read_text());num=den=0
        for cell,x in v['retrieval'].items():
            ref=b['retrieval'][cell]
            assert x['targets']==ref['targets'] and x['key_positions']==ref['key_positions']
            num+=sum(y for h,y in zip(ref['hits'],x['hits']) if h);den+=sum(ref['hits'])
        assert v['conditional_retention']=={'retained':num,'established':den,'fraction':num/den}
        assert len(v['independent_w1'])==9 and all(math.isfinite(x) and x>=0 for x in v['independent_w1'])
        tests.append(v)
    report={'status':'passed','selected_coefficient':selection['selected']['coefficient'],'validation_candidates':candidates,
            'training_runs':9,'test_predictions_checked':3456,
            'test_em':summary([x['macro_em'] for x in tests]),'test_nll':summary([x['text']['nll'] for x in tests]),
            'conditional_retention':summary([x['conditional_retention']['fraction'] for x in tests]),
            'independent_w1':summary([statistics.mean(x['independent_w1']) for x in tests])}
    (D.parent/'matched_analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
