"""Verify every retained validation window and recompute the exclusion selection."""
from pathlib import Path
import json,statistics
D=Path(__file__).resolve().parents[1]/'results/revision_v10/clean_validation'
def load(p):return json.loads(p.read_text())
m=load(D/'manifest.json');blocked=m['blocked_intervals'];cases=[]
for p in D.glob('seed*.json'):
 x=load(p);assert len(x['sampled_intervals'])==1280 and x['overlap_count']==0;assert all(all(max(a,c)>=min(b,d) for c,d in blocked) for a,b in x['sampled_intervals']);assert len(x['retrieval'])==9
 for v in x['retrieval'].values():
  hits=[int(p==t) for p,t in zip(v['predictions'],v['targets'])];assert hits==v['hits'];assert statistics.mean(hits)==v['full_key_exact_match']
 assert statistics.mean(v['full_key_exact_match'] for v in x['retrieval'].values())==x['macro_em'];cases.append(x)
assert len(cases)==9;c=load(D/'complete.json');lcr=statistics.mean(x['text']['nll'] for x in cases if x['tag']=='lcr');assert lcr==c['lcr_nll'];eligible=[]
for k in [.1,1.]:
 xs=[x for x in cases if x['tag']==f'aligned_lambda{k:g}'];assert len(xs)==3;v=dict(coefficient=k,em=statistics.mean(x['macro_em'] for x in xs),nll=statistics.mean(x['text']['nll'] for x in xs));assert v in c['candidates']
 if v['nll']<=lcr+.02:eligible.append(v)
assert max(eligible,key=lambda x:(x['em'],-x['coefficient']))==c['selected'];assert c['unchanged']
r=dict(status='passed',checkpoints=9,sampled_windows=11520,selection_coefficient=c['selected']['coefficient'],unchanged=True,zero_overlap_with_probe_intervals=True,posthoc_sensitivity_audit=True);(D/'verification.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
