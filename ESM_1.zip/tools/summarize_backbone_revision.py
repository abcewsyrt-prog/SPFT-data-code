"""Aggregate all predeclared retrieval cells and matched baseline-correct retention."""
import argparse,json,statistics
from pathlib import Path


def stats(values):
 return {'mean':statistics.mean(values),'sd':statistics.stdev(values) if len(values)>1 else None,'n_seeds':len(values),'values':values}


def main():
 ap=argparse.ArgumentParser();ap.add_argument('root');a=ap.parse_args();root=Path(a.root)
 summary={'schema':'full-key-natural-adaptation-summary-v2','architectures':{},'all_complete':True}
 for tag,modes in [('mamba130',['vanilla','lcr','spec_reg','spft','l2sp','freeze_decay']),('rwkv400',['vanilla','lcr','spec_reg','spft','l2sp'])]:
  records={};base={};manifests={}
  for seed in range(3):
   d=root/('{}_seed{}'.format(tag,seed))
   if (d/'manifest.json').exists():manifests[seed]=json.loads((d/'manifest.json').read_text())
   if (d/'baseline.json').exists():base[seed]=json.loads((d/'baseline.json').read_text())
   for mode in modes:
    if (d/(mode+'.json')).exists():records[(seed,mode)]=json.loads((d/(mode+'.json')).read_text())
  if len(records)!=3*len(modes):summary['all_complete']=False
  if not base:continue
  keys=list(next(iter(base.values()))['retrieval'])
  baseline={'cells':{k:stats([r['retrieval'][k]['full_key_exact_match'] for r in base.values()]) for k in keys},'natural_text_nll':stats([r['text']['nll'] for r in base.values()])}
  model={'baseline':baseline,'modes':{},'manifest_files':[str(root/('{}_seed{}'.format(tag,s))/'manifest.json') for s in manifests]}
  for mode in modes:
   seeds=[s for s in base if (s,mode) in records]
   if not seeds:continue
   cells={};macro=[]
   for key in keys:
    accuracy=[];retention=[];retention_n=[]
    for seed in seeds:
     b=base[seed]['retrieval'][key];r=records[(seed,mode)]['retrieval'][key]
     if b['targets']!=r['targets'] or b['key_positions']!=r['key_positions']:raise ValueError('Unpaired test samples')
     accuracy.append(r['full_key_exact_match'])
     correct=[j for j,h in enumerate(b['hits']) if h];retention_n.append(len(correct))
     if correct:retention.append(sum(r['hits'][j] for j in correct)/len(correct))
    cells[key]={'full_key_accuracy':stats(accuracy),'baseline_correct_n':retention_n,'retention_given_baseline_correct':stats(retention) if retention else None}
   for seed in seeds:macro.append(statistics.mean(records[(seed,mode)]['retrieval'][k]['full_key_exact_match'] for k in keys))
   model['modes'][mode]={'seeds':seeds,'cells':cells,'macro_accuracy_all_cells':stats(macro),'natural_text_nll':stats([records[(s,mode)]['text']['nll'] for s in seeds]),'natural_text_accuracy':stats([records[(s,mode)]['text']['accuracy'] for s in seeds]),'spectral_w1':stats([records[(s,mode)]['spectral_w1'] for s in seeds])}
  summary['architectures'][tag]=model
 (root/'backbone_summary.json').write_text(json.dumps(summary,indent=2))
 lines=['# Full-key retrieval and natural-text adaptation', '', 'Status: '+('complete' if summary['all_complete'] else 'running; completed records shown below'), '', 'Results include every predeclared length/depth cell. Means and sample SDs use independent training seeds; incomplete groups are explicitly labeled.', '']
 def display(value):
  return '{:.4f} ± {:.4f}'.format(value['mean'],value['sd']) if value['sd'] is not None else '{:.4f} (one seed)'.format(value['mean'])
 for tag,model in summary['architectures'].items():
  lines += ['## '+tag, '', '| Mode | Seeds | Macro full-key exact match | Natural-text NLL |', '|---|---|---|---|']
  baseline=model['baseline'];bmacro=stats([statistics.mean(base_record['retrieval'][k]['full_key_exact_match'] for k in base_record['retrieval']) for base_record in [json.loads((root/('{}_seed{}'.format(tag,s))/'baseline.json').read_text()) for s in range(3) if (root/('{}_seed{}'.format(tag,s))/'baseline.json').exists()]])
  lines.append('| Before adaptation | '+str(bmacro['n_seeds'])+' | '+display(bmacro)+' | '+display(baseline['natural_text_nll'])+' |')
  for mode,v in model['modes'].items():lines.append('| '+mode+' | '+str(len(v['seeds']))+' | '+display(v['macro_accuracy_all_cells'])+' | '+display(v['natural_text_nll'])+' |')
  lines += ['', '| Length @ depth | Before adaptation | '+' | '.join(model['modes'])+' |', '|---|---|'+ '|'.join('---' for _ in model['modes'])+'|']
  for cell,values in baseline['cells'].items():lines.append('| '+cell+' | '+display(values)+' | '+' | '.join(display(v['cells'][cell]['full_key_accuracy']) for v in model['modes'].values())+' |')
  lines += ['', 'Baseline-correct conditional retention, paired targets and evidence positions are retained in the JSON summary and per-example source files.', '']
 (root/'backbone_summary.md').write_text('\n'.join(lines)+'\n')
 print('all_complete',summary['all_complete'])
 for tag,r in summary['architectures'].items():
  print(tag,'baseline NLL',r['baseline']['natural_text_nll'])
  for mode,v in r['modes'].items():print(mode,v['seeds'],'all-cell EM',v['macro_accuracy_all_cells'],'NLL',v['natural_text_nll'])

if __name__=='__main__':main()
