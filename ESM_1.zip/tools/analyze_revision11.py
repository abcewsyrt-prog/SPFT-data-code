"""Emit source-derived draft summary only after complete endpoint verification."""
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];D=R/'results/revision_v11'
if not (D/'verification.json').exists():print('Pending complete verified endpoints; no numerical draft generated.');raise SystemExit(0)
assert json.loads((D/'verification.json').read_text())['status']=='passed';s=json.loads((D/'summary.json').read_text());lines=['| Method | EM | Q | Text NLL | Held-out decay distance |','|---|---|---|---|---|']
for family,label in [('lcr','LCR'),('a_only','SPFT, A-only penalty gradient'),('spft','SPFT, full penalty gradient (ours)')]:
 row=s['families'][family];lines.append('| '+label+' | '+' | '.join(f"{row[k]['mean']:.4f} ± {row[k]['sd']:.4f}" for k in ['em','q','nll','w'])+' |')
text='\n'.join(lines)+'\n\nFull-minus-A-only paired differences:\n'+json.dumps(s['paired_full_minus_a_only'],indent=2)+'\n';(D/'source_derived_draft.md').write_text(text);print(text)
