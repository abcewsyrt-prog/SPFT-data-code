"""Recompute the fixed-checkpoint TF32 attribution against all original predictions."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1]
new=json.loads((R/'results/revision_v5/precision/results.json').read_text())
oldswap=json.loads((R/'results/revision_v3/swaps_corrected/results.json').read_text())
assert new['source_sha256']==hashlib.sha256((R/'pilot/revision5_precision.py').read_bytes()).hexdigest()
assert new['generator_sha256']==hashlib.sha256((R/'pilot/lrm_pilot.py').read_bytes()).hexdigest()
rows=[]
for seed in range(3):
    old=json.loads((R/f'results/revision_v3/iid/seed{seed}_vanilla.json').read_text())
    v=new['seeds'][str(seed)]
    assert v['checkpoint_sha256']==oldswap['results'][str(seed)]['ft_sha256']
    entry={'seed':seed,'checkpoint_sha256':v['checkpoint_sha256'],'lengths':{}}
    for length in ['192','384','768']:
        a=v['precision']['true']['recall'][length];b=v['precision']['false']['recall'][length]
        x=old['recall'][length];y=oldswap['results'][str(seed)]['swaps']['decay_ft_content_ft']['recall'][length]
        assert a['targets']==b['targets']==x['targets']==y['targets']
        assert a['distances']==b['distances']==x['distances']==y['distances']
        assert a['predictions']==x['predictions'] and b['predictions']==y['predictions']
        for z in [a,b]:assert z['hits']==[int(p==q) for p,q in zip(z['predictions'],z['targets'])]
        entry['lengths'][length]={'tf32_enabled_hits':sum(a['hits']),'tf32_disabled_hits':sum(b['hits']),
                                  'changed_predictions':sum(p!=q for p,q in zip(a['predictions'],b['predictions'])),
                                  'changed_hit_status':sum(p!=q for p,q in zip(a['hits'],b['hits']))}
    rows.append(entry)
report={'status':'passed','date':'2026-10-22','causal_factor_varied':'TF32 matmul flag; checkpoints and test inputs held fixed',
        'all_original_main_predictions_reproduced':True,'all_original_full_swap_predictions_reproduced':True,
        'examples_checked':18432,'results':rows}
(R/'results/revision_v5/precision/analysis.json').write_text(json.dumps(report,indent=2))
print('Verified 18432 retrieval predictions, checkpoint hashes, targets and distances.')
