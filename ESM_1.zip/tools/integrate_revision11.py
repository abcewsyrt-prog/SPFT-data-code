"""Integrate completed, verified gradient-path endpoints; preserve the TeX class."""
from pathlib import Path
import json,re,shutil
R=Path(__file__).resolve().parents[1];P=R/'paper';D=R/'results/revision_v11'
assert json.loads((D/'verification.json').read_text())['status']=='passed'
s=json.loads((D/'summary.json').read_text());F=s['families'];paired=s['paired_full_minus_a_only'];assert all(x>0 for x in paired['em']['values']) and all(x<0 for x in paired['w']['values']),'Inspect changed effect directions before integrating the drafted interpretation'
B=P/'backups/gradient_path_integration_20261023';B.mkdir(exist_ok=True)
def fmt(x,bold=False):
 v=f"{x['mean']:.4f}\\pm{x['sd']:.4f}";return '$'+('\\mathbf{'+v+'}' if bold else v)+'$'
rows=[]
for k,label in [('lcr','LCR'),('a_only','SPFT, A-only'),('spft',r'\textbf{SPFT (ours)}')]:rows.append([label]+[fmt(F[k][m],k=='spft' and m in ['em','q','w']) for m in ['em','q','nll','w']])
cap='Gradient-path ablation on the original three Mamba-2 references. Each condition uses 600 short updates, coefficient 1 where applicable, and replay probability 0.05 with matched streams. The A-only variant stops penalty gradients through the complete input-dependent step size; task-loss gradients remain unchanged. Full-gradient SPFT checkpoints are reused from the matched-exposure anchor. Values are mean $\\pm$ sample SD across three training seeds; independent-probe distance averages the same nine probe batches per seed.'
table='\\begin{table}[htbp]\n\\caption{'+cap+'}\\label{tab:gradient_path}\n\\centering\\fontsize{8}{10}\\selectfont\\setlength{\\tabcolsep}{2.5pt}\n\\begin{tabular}{lllll}\\toprule\nMethod & Full-key EM & $Q$ & Text NLL & $W_{\\mathrm{held}}$ \\\\\\midrule\n'+'\n'.join(' & '.join(x)+' \\\\' for x in rows)+'\n\\bottomrule\\end{tabular}\\end{table}\n'
protocol='We isolate the penalty gradient route while preserving its forward statistic. In the A-only variant, the complete clipped softplus step size is detached in the penalty, so only $A_{\\log}$ receives penalty gradients. Both short-text and replay losses retain full gradients. Reference checkpoints, random streams, optimizer, coefficient, probe, and update counts match full-gradient SPFT. The latter reuses the existing three 600-update anchors. At common adapted checkpoints, both penalty implementations have identical forward values; the detached version has zero penalty gradients on the step-size bias and all other parameters, whereas full differentiation has nonzero upstream gradients. All three prespecified seeds are reported without selection.'
result=f"Full-gradient SPFT reached mean full-key exact match {F['spft']['em']['mean']:.4f} versus {F['a_only']['em']['mean']:.4f} for the A-only variant, with independent-probe distances {F['spft']['w']['mean']:.4f} and {F['a_only']['w']['mean']:.4f}. Both directions held in all three paired seeds. The comparison identifies an effect of the penalty's gradient route under the fixed training protocol; it does not equate a smaller endpoint distance with a causal explanation of retrieval."
main=f"A matched gradient-path ablation isolates how the penalty influences adaptation. Allowing its gradient through the full input-dependent computation gives full-key exact match {F['spft']['em']['mean']:.4f}, versus {F['a_only']['em']['mean']:.4f} when the same forward statistic sends penalty gradients only to $A_{{\\log}}$. Full differentiation also reduces independent-probe distance from {F['a_only']['w']['mean']:.4f} to {F['spft']['w']['mean']:.4f}, with both directions consistent across all three seeds (Appendix~\\ref{{sec:gradient_path}})."
interpret='The gradient-path ablation further connects this effect to optimization of the shared input-dependent computation. Restricting the same penalty to $A_{\\log}$ reduces both retrieval retention and statistical preservation relative to full differentiation in all three paired seeds. Thus the implemented constraint influences adaptation through a broader gradient path than direct adjustment of decay coefficients.'
for name in ['manuscript.tex','manuscript.md','manuscript_zh.md']:
 p=P/name;text=p.read_text();assert 'tab:gradient_path' not in text and '## Appendix J' not in text and '## 附录 J' not in text;shutil.copy2(p,B/name)
 if name=='manuscript.tex':
  h,text=text.split(r'\end{filecontents*}',1);a=text.index('The component controls clarify');b=text.index('\n\n',a);text=text[:b]+'\n\n'+main+text[b:]
  a=text.index('The controlled interventions explain');b=text.index('\n\n',a);text=text[:b]+' '+interpret+text[b:]
  a=text.index('\\begin{thebibliography}');text=text[:a]+'\\section{Gradient-path ablation}\\label{sec:gradient_path}\n\n'+protocol+'\n\n'+table+'\n'+result+'\n\n'+text[a:];text=h+r'\end{filecontents*}'+text
 elif name=='manuscript.md':
  a=text.index('The component controls clarify');b=text.index('\n\n',a);text=text[:b]+'\n\n'+main.replace(r'~\ref{sec:gradient_path}',' J')+text[b:]
  a=text.index('The controlled interventions explain');b=text.index('\n\n',a);text=text[:b]+' '+interpret+text[b:]
  mdrows=[[c.replace(r'\textbf{SPFT (ours)}','**SPFT (ours)**') for c in x] for x in rows]
  tab='| Method | Full-key EM | $Q$ | Text NLL | $W_{\\mathrm{held}}$ |\n|---|---|---|---|---|\n'+'\n'.join('| '+' | '.join(x)+' |' for x in mdrows)+'\n'
  a=text.index('## References');text=text[:a]+'## Appendix J Gradient-path ablation\n\n'+protocol+'\n\n**Table 17.** '+cap.replace(r'\pm','±')+'\n\n'+tab+'\n'+result+'\n\n'+text[a:]
 else:
  a=text.index('组件对照明确了联合目标');b=text.index('\n\n',a);zmain=f"匹配的梯度路径消融隔离了惩罚项影响适应的方式。惩罚梯度经过完整输入相关计算时，完整键匹配率为 {F['spft']['em']['mean']:.4f}；相同前向统计只向 $A_{{\\log}}$ 回传惩罚梯度时，为 {F['a_only']['em']['mean']:.4f}。完整反向传播还将独立探针距离从 {F['a_only']['w']['mean']:.4f} 降至 {F['spft']['w']['mean']:.4f}，三个配对种子的两个方向均一致（附录 J）。";text=text[:b]+'\n\n'+zmain+text[b:]
  a=text.index('受控干预解释了行为监督');b=text.index('\n\n',a);text=text[:b]+'梯度路径消融进一步将这一效果与共享输入相关计算的优化联系起来。在三个配对种子中，相同惩罚仅对 $A_{\\log}$ 反向传播时，检索保持和统计保持均低于完整反向传播。这说明所实现约束影响适应的梯度路径超出了衰减系数的直接调整。'+text[b:]
  zrows=[[c.replace(r'\textbf{SPFT (ours)}','**SPFT，完整梯度（本文方法）**').replace('SPFT, A-only','SPFT，仅 A 参数梯度') for c in x] for x in rows]
  tab='| 方法 | 完整键匹配率 | $Q$ | 文本 NLL | $W_{\\mathrm{held}}$ |\n|---|---|---|---|---|\n'+'\n'.join('| '+' | '.join(x)+' |' for x in zrows)+'\n'
  protocolzh='在保持前向统计不变的条件下，本文隔离惩罚项的梯度路径。仅 A 参数梯度的变体将完整的截断 softplus 步长从惩罚计算图分离，只有 $A_{\\log}$ 接收惩罚梯度，短文本和回放损失仍保持完整梯度。参考检查点、随机流、优化器、系数、探针及更新次数均与完整 SPFT 匹配，完整版本复用已有三个 600 次更新的锚点。在相同适应后检查点上，两种惩罚的前向值完全一致；截断版本对步长偏置及其他参数的惩罚梯度为零，完整版本对上游参数的梯度非零。全部三个预设种子均报告，未进行结果选择。'
  capzh='原始三个 Mamba-2 参考模型上的梯度路径消融。各条件均使用 600 次短任务更新及概率 0.05 的匹配回放流；适用时系数为 1。仅 A 参数梯度的变体截断惩罚经完整输入相关步长的反向路径，任务损失梯度保持不变。完整 SPFT 复用匹配暴露量的已有锚点。数值为三个训练种子的均值 ± 样本标准差，独立探针距离平均每个种子相同的九个批次。'
  a=text.index('## 参考文献');text=text[:a]+'## 附录 J 梯度路径消融\n\n'+protocolzh+'\n\n**表 17.** '+capzh+'\n\n'+tab+'\n'+zmain+'这一比较识别了固定训练协议下惩罚梯度路径的效果，并未将更小的终点距离等同于检索收益的因果解释。\n\n'+text[a:]
 p.write_text(text)
print('Integrated complete verified three-seed gradient-path results in all three manuscript formats.')
