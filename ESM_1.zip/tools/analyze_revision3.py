"""Aggregate completed corrective experiments without mixing generator versions."""
from pathlib import Path
import json,statistics,hashlib
R=Path(__file__).resolve().parents[1];D=R/'results/revision_v3'
def stats(v):return {'n':len(v),'values':v,'mean':statistics.mean(v),'sd':statistics.stdev(v) if len(v)>1 else None}
summary={'schema':'strict-revision-v3','tasks':{},'independent_probes':{}}
for suite in ['iid','markov','iid_extra']:
 root=D/suite
 if not root.exists():continue
 groups={}
 for file in sorted(root.glob('seed*_*.json')):
  r=json.loads(file.read_text());mode=r['mode'];groups.setdefault(mode,[]).append(r)
 task={'modes':{}}
 for mode,rows in groups.items():
  rows.sort(key=lambda x:x['seed']);v={'seeds':[x['seed'] for x in rows],'recall':{str(n):stats([x['recall'][str(n)]['accuracy'] for x in rows]) for n in [192,384,768]},'adaptation_accuracy':stats([x['local']['accuracy'] for x in rows]),'adaptation_nll':stats([x['local']['nll'] for x in rows]),'training_probe_w1':stats([x['spectral_w1'] for x in rows]),'validation_recall768':stats([x['validation']['recall']['768']['accuracy'] for x in rows]),'validation_accuracy':stats([x['validation']['local']['accuracy'] for x in rows])};task['modes'][mode]=v
 if 'spft' in groups and 'lcr' in groups:
  aa={x['seed']:x for x in groups['spft']};bb={x['seed']:x for x in groups['lcr']};seeds=sorted(set(aa)&set(bb));task['paired_spft_minus_lcr']={'seeds':seeds,**stats([aa[s]['recall']['768']['accuracy']-bb[s]['recall']['768']['accuracy'] for s in seeds])}
 if suite=='iid':
  choices=[(m,v) for m,v in task['modes'].items() if m.startswith('l2replay_') and len(v['seeds'])==3 and v['validation_accuracy']['mean']>=.245]
  if len(choices)==3:
   best=max(choices,key=lambda x:(x[1]['validation_recall768']['mean'],-int(x[0].split('_')[-1])));task['l2_replay_selected']=best[0]
 summary['tasks'][suite]=task
for arch in ['mamba130','rwkv400']:
 root=D/'independent_probes'/arch;rows=[]
 for seed in range(3):
  p=root/f'seed{seed}.json'
  if p.exists():rows.append(json.loads(p.read_text()))
 modes=sorted(set(k for row in rows for k in row['modes']));result={}
 for mode in modes:
  usable=[row for row in rows if mode in row['modes']]
  result[mode]={'seeds':[row['seed'] for row in usable],'pooled_probe_w1':stats([statistics.mean(x['w1'] for x in row['modes'][mode]) for row in usable]),'by_length':{str(n):stats([statistics.mean(x['w1'] for x in row['modes'][mode] if x['length']==n) for row in usable]) for n in [64,256,1024]}}
 summary['independent_probes'][arch]=result
(D/'summary.json').write_text(json.dumps(summary,indent=2))
for task,v in summary['tasks'].items():
 print(task,{m:(len(x['seeds']),round(x['recall']['768']['mean'],4),round(x['adaptation_accuracy']['mean'],4)) for m,x in v['modes'].items()})
for arch,v in summary['independent_probes'].items():print('heldout',arch,{m:round(x['pooled_probe_w1']['mean'],4) for m,x in v.items()})
