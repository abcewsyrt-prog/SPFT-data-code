"""Verify per-example controlled evaluations and derive all reported summaries."""
from pathlib import Path
import json,statistics,hashlib
R=Path(__file__).resolve().parents[1];O=R/'results/revision_v10';D=O/'controlled'
def load(p):return json.loads(p.read_text())
def ms(xs):return dict(mean=statistics.mean(xs),sd=statistics.stdev(xs))
records=[]
for p in D.glob('*.json'):
 x=load(p)
 if 'recall' not in x:continue
 assert x['matmul_tf32'] is True
 for n,c in x['recall'].items():
  assert c['n']==len(c['hits'])==len(c['predictions'])==len(c['targets'])==len(c['distances'])==1024
  assert c['hits']==[int(a==b) for a,b in zip(c['predictions'],c['targets'])]
  assert c['accuracy']==sum(c['hits'])/1024
 records.append((p,x))
original=[x for p,x in records if p.name.startswith(('iid_','markov_'))];assert len(original)==36 and all(x['original_prediction_reproduced'] for x in original)
summary={'swaps':{},'interpolation':{}}
for mode in ['vanilla','lcr','spec_reg','spft']:
 summary['swaps'][mode]={}
 for d,c in [(0,0),(1,0),(0,1),(1,1)]:
  xs=[load(D/f'seed{s}_{mode}_decay{d}_other{c}.json') for s in range(3)]
  summary['swaps'][mode][f'decay{d}_other{c}']={'recall':ms([x['recall']['768']['accuracy'] for x in xs]),'short_acc':ms([x['local']['accuracy'] for x in xs])}
  for s,x in enumerate(xs):
   anchor=load(D/f'iid_seed{s}_{mode}.json')
   assert all(x['recall'][n]['targets']==anchor['recall'][n]['targets'] and x['recall'][n]['distances']==anchor['recall'][n]['distances'] for n in x['recall'])
   if d==c==1:assert x['recall']==anchor['recall']
for mode in ['vanilla','spft']:
 summary['interpolation'][mode]={}
 for g in ['decay','other']:
  rows=[]
  for a in [0,.2,.4,.6,.8,1]:
   xs=[load(D/f'seed{s}_{mode}_interpolate_{g}_{a:g}.json') for s in range(3)]
   rows.append(dict(alpha=a,recall=ms([x['recall']['768']['accuracy'] for x in xs])))
   if a in [0,1]:
    for s,x in enumerate(xs):
     d=int(a==1 and g=='decay');c=int(a==1 and g=='other');anchor=load(D/f'seed{s}_{mode}_decay{d}_other{c}.json');assert x['recall']==anchor['recall']
  summary['interpolation'][mode][g]=rows
assert len(records)==156
compat={str(s):dict(swaps={f'decay_{ds}_content_{cs}':load(D/f'seed{s}_vanilla_decay{d}_other{c}.json') for d,ds in enumerate(['pre','ft']) for c,cs in enumerate(['pre','ft'])},interpolation={cg:[load(D/f'seed{s}_vanilla_interpolate_{g}_{a:g}.json') for a in [0,.2,.4,.6,.8,1]] for g,cg in [('decay','decay'),('other','content')]}) for s in range(3)}
(O/'swaps_compatible').mkdir(exist_ok=True);(O/'swaps_compatible/results.json').write_text(json.dumps(dict(results=compat),indent=2))
(O/'controlled_summary.json').write_text(json.dumps(summary,indent=2))
report=dict(status='passed',models_reproducing_original_predictions=36,swapped_states=48,interpolated_states=72,total_states=156,per_state_retrieval_lengths=3,per_length_examples=1024,checked_predictions=156*3*1024,all_swap_full_endpoints_match_original=True,interpolation_endpoints_match_swaps=True,all_current_interventions_tf32=True,new_training_runs=0,files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p,x in records})
(O/'verification.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k!='files'})
