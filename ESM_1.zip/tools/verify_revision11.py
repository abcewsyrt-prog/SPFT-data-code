"""Verify all per-example ablation endpoints and derive a prespecified summary."""
from pathlib import Path
import json,hashlib,statistics
R=Path(__file__).resolve().parents[1];D=R/'results/revision_v11';O=R/'results'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ms(x):return dict(mean=statistics.mean(x),sd=statistics.stdev(x),values=x)
if not (D/'complete.json').exists():
 print(json.dumps(dict(status='pending',completed_seed_endpoints=len(list(D.glob('*_a_only_test.json'))))));raise SystemExit(0)
man=load(D/'manifest.json');frozen=R/'reproducibility/executed_v11';assert man['common_sha256']==sha(frozen/'revision_experiments.py');assert man['training_driver_sha256']==sha(frozen/'revision7_equal_time.py');assert man['extension_sha256']==sha(frozen/'revision6_extension.py');assert man['source_sha256']==sha(R/'backbone/revision11_gradient_path.py')
summary={};allmetrics={};records=0
for family in ['lcr','a_only','spft']:
 rows=[]
 for seed in range(3):
  p=D/f'seed{seed}_a_only_test.json' if family=='a_only' else O/f'revision_v7/equal_time/seed{seed}_spft.json' if family=='spft' else O/f'revision_v2/mamba130_seed{seed}/lcr.json';x=load(p);base=load(O/f'revision_v2/mamba130_seed{seed}/baseline.json');assert len(x['retrieval'])==9;num=den=0
  for k,c in x['retrieval'].items():
   b=base['retrieval'][k];assert c['targets']==b['targets'] and c['key_positions']==b['key_positions'];assert len(c['hits'])==len(c['predictions'])==len(c['targets'])==128
   hits=[int(a==b) for a,b in zip(c['predictions'],c['targets'])];assert hits==c['hits'];assert statistics.mean(hits)==c['full_key_exact_match'];num+=sum(h*j for h,j in zip(b['hits'],c['hits']));den+=sum(b['hits']);records+=len(hits)
  em=statistics.mean(c['full_key_exact_match'] for c in x['retrieval'].values())
  if family=='a_only':
   assert em==x['macro_em'] and x['conditional_retention']['fraction']==num/den;assert len(x['independent_w1'])==9
   path=load(D/f'seed{seed}_path_check.json');assert path['forward_max_error']==0;assert abs(path['full']['penalty']-path['a_only']['penalty'])<1e-7
   assert path['a_only']['l2_gradient']['other']==path['a_only']['l2_gradient']['dt_bias']==0 and path['a_only']['l2_gradient']['A_log']>0;assert path['full']['l2_gradient']['other']>0
   training=load(D/f'seed{seed}_training.json');anchor=load(O/f'revision_v7/equal_time/seed{seed}_spft.json');assert training['short_updates']==600 and training['replay_updates']==anchor['training']['replay_updates'];assert x['checkpoint_sha256'] and path['full_checkpoint_sha256']==training['full_checkpoint_sha256']
  w=statistics.mean(x['independent_w1']) if 'independent_w1' in x else None
  if w is None:
   # The original LCR held-out measurements are separately archived.
   probes=load(O/f'revision_v3/independent_probes/mamba130/seed{seed}.json')
   w=statistics.mean(c['w1'] for c in probes['modes']['lcr'])
  rows.append(dict(seed=seed,em=em,q=num/den,nll=x['text']['nll'],w=w))
 summary[family]={k:ms([x[k] for x in rows]) for k in ['em','q','nll','w']};allmetrics[family]=rows
pairs={k:ms([summary['spft'][k]['values'][i]-summary['a_only'][k]['values'][i] for i in range(3)]) for k in ['em','q','nll','w']}
(D/'summary.json').write_text(json.dumps(dict(families=summary,paired_full_minus_a_only=pairs,per_seed=allmetrics),indent=2));report=dict(status='passed',trained_seeds=3,reused_full_anchors=3,predictions_checked=records,gradient_path_checks_passed=True,training_streams_matched=True,source_fingerprints_matched=True,new_cohort_selection=False)
(D/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
