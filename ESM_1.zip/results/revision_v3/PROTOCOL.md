# Corrective experiment protocol

This directory preserves a new cohort generated with a visible key-value pair guaranteed before the query. It does not overwrite revision_v2 or the frozen review packet.

Primary IID replication uses the fixed provided pretrained checkpoint, 3000 short updates per run, batch32 and AdamW1e-4. Seeds0,1,2 compare vanilla, replay p=.05, spectral lambda1, their combination, replay p=.30, and L2-SP plus replay with strengths1/100/10000. Select the L2-plus-replay strength on independent validation examples, maximum mean validation recall768 subject to mean adaptation accuracy>=.245, ties choose the smaller coefficient. All candidate test results remain in the record. Additional paired replay/SPFT adaptation seeds3,4 are reported as a separate robustness extension, not additional pretraining seeds.

Structured short-task verification uses P(next=(current+1) mod4)=.85 and probability.05 for each other symbol. Its optimal next-token accuracy is.85. Three matched seeds compare vanilla, replay, spectral regularization, and their combination after1500 short updates. This task is distinct from IID symbol adaptation and is not pooled into its averages.

Every final test uses1024 paired retrieval examples at nominal lengths192/384/768 and1024 short sequences. Independent validation streams use different seeds. Parameter interventions use the new three vanilla checkpoints with the corrected test generator. Raw targets, predictions and distances are retained.

Completed backbone checkpoints are evaluated without retraining on nine independent probe batches. Three batches of two examples cover each of natural text at64, digit retrieval at256/depth.5, and retrieval at1024/depth.1. These probes never enter training gradients. Distances compare each adapted checkpoint with its own continued-training reference on identical new inputs. Probes are repeated measurements, not independent training replicates. The original public checkpoint text NLL is measured separately on the same held-out stream used for the existing NLL comparison.

The final cost benchmark waits for all training, probe and swap jobs to end, checks that no other GPU compute process is present, and times200 short updates after20 warmup updates. Replay frequencies give10 or60 additional updates. Inputs remain resident. Timing repetitions are not adaptation seeds. Contended scientific-run durations are logged only for provenance.

Model and tokenizer content hashes, archived actual v2 source, and the provided controlled-model pretrained checkpoint close the provenance chain. Actual v2 and current revision_train.py differ only by an added source-hash metadata field; the old generator is preserved alongside the corrected version.
