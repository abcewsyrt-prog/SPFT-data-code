"""Complete vanilla interpolation under the same explicit TF32 setting as R10."""
import json,hashlib
from pathlib import Path
import torch
import lrm_pilot as L
from revision_paired import recall
from revision3_train import short_eval
from revision10_controlled_eval import atomic,decay,sha
R=Path('/root/ai_paper');O=R/'revision_v10/controlled';torch.set_num_threads(2);torch.backends.cuda.matmul.allow_tf32=True;torch.backends.cudnn.allow_tf32=True;dev=torch.device('cuda');pre=torch.load(R/'results/pilot_pretrained.pt',map_location='cpu');model=L.TinyLRM(32,128,3,4,32,2048).to(dev).eval()
for seed in range(3):
 p=R/f'revision_v3/iid/seed{seed}_vanilla.pt';ft=torch.load(p,map_location='cpu')
 for group in ['decay','other']:
  for alpha in [0.,.2,.4,.6,.8,1.]:
   dest=O/f'seed{seed}_vanilla_interpolate_{group}_{alpha:g}.json'
   if dest.exists():continue
   state={k:((1-alpha)*v+alpha*ft[k] if decay(k)==(group=='decay') else v) for k,v in pre.items()};model.load_state_dict(state);v=dict(recall={str(n):recall(model,n,1024,16,81917,dev) for n in [192,384,768]},local=short_eval(model,'iid'),seed=seed,mode='vanilla',group=group,alpha=alpha,checkpoint_sha256=sha(p),matmul_tf32=True);atomic(dest,v);print(seed,group,alpha,v['recall']['768']['accuracy'],flush=True)
atomic(O/'vanilla_interpolation_complete.json',dict(status='complete',states=36,matmul_tf32=True,source_sha256=sha(__file__)))
