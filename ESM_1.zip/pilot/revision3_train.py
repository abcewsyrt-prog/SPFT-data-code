"""Corrected-generator replication and direct replay comparators. No legacy writes."""
import argparse,hashlib,json,math,statistics,time
from pathlib import Path
import torch
import torch.nn.functional as F
import lrm_pilot as L
from revision_train import spectrum,distance
from revision_paired import recall

def atomic(p,x):
 p=Path(p);q=p.with_suffix('.tmp');q.write_text(json.dumps(x,indent=2,allow_nan=False));q.replace(p)
def short_batch(batch,gen,device,suite):
 if suite=='iid':return L.make_local_task(batch,48,32,gen,device)
 x=torch.zeros(batch,48,dtype=torch.long);x[:,0]=torch.randint(32,(batch,),generator=gen)
 for t in range(1,48):
  target=(x[:,t-1]+1)%4
  noise=torch.rand(batch,generator=gen)
  other=torch.randint(1,4,(batch,),generator=gen)
  x[:,t]=torch.where(noise<.85,target,(target+other)%4)
 return x.to(device)
@torch.no_grad()
def short_eval(model,suite,seed=81591,n=1024):
 model.eval();gen=torch.Generator().manual_seed(seed);acc=[];nll=[]
 for start in range(0,n,32):
  x=short_batch(min(32,n-start),gen,next(model.parameters()).device,suite);z=model(x[:,:-1]);y=x[:,1:]
  acc.extend((z.argmax(-1)==y).float().mean(1).cpu().tolist());nll.extend(F.cross_entropy(z.reshape(-1,32),y.reshape(-1),reduction='none').reshape(y.shape).mean(1).cpu().tolist())
 return {'n_sequences':n,'accuracy':statistics.mean(acc),'nll':statistics.mean(nll)}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pre',required=True);ap.add_argument('--out',required=True);ap.add_argument('--suite',choices=['iid','markov'],required=True);ap.add_argument('--steps',type=int,default=3000);ap.add_argument('--n',type=int,default=1024);ap.add_argument('--seeds',default='0,1,2');ap.add_argument('--smoke',action='store_true');ap.add_argument('--modes');a=ap.parse_args()
 out=Path(a.out);out.mkdir(parents=True,exist_ok=True);dev=torch.device('cuda' if torch.cuda.is_available() else 'cpu');torch.set_num_threads(4)
 if dev.type=='cuda':torch.backends.cuda.matmul.allow_tf32=True
 pre=torch.load(a.pre,map_location='cpu');probe=L.make_mqar(8,192,32,4,torch.Generator().manual_seed(12301),dev)[0]
 model=L.TinyLRM(32,128,3,4,32,2048).to(dev);model.load_state_dict(pre)
 with torch.no_grad():ref=[x.detach() for x in spectrum(model,probe)]
 def evaluate(m,validation=False):
  with torch.no_grad():return {'recall':{str(n):recall(m,n,a.n,16,41927 if validation else 81917,dev) for n in ([768] if validation else [192,384,768])},'local':short_eval(m,a.suite,41329 if validation else 81591,a.n),'spectral_w1':float(distance(spectrum(m,probe),ref))}
 atomic(out/'baseline.json',evaluate(model))
 # Fixed primary configurations. Competitor strengths selected using separate streams.
 configs=[('vanilla',0.,0.,0.),('lcr',.05,0.,0.),('spec_reg',0.,1.,0.),('spft',.05,1.,0.)]
 if a.suite=='iid':configs += [('lcr_p30',.30,0.,0.),('l2replay_1',.05,0.,1.),('l2replay_100',.05,0.,100.),('l2replay_10000',.05,0.,10000.)]
 if a.modes:configs=[c for c in configs if c[0] in a.modes.split(',')]
 manifest=vars(a).copy();manifest.update({'schema':'corrected-generator-v3','pre_sha256':hashlib.sha256(Path(a.pre).read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'generator_sha256':hashlib.sha256(Path(L.__file__).read_bytes()).hexdigest(),'spectrum_source_sha256':hashlib.sha256(Path(__file__).with_name('revision_train.py').read_bytes()).hexdigest(),'torch':torch.__version__,'device':torch.cuda.get_device_name() if dev.type=='cuda' else str(dev),'configs':configs,'test_retrieval_seed':81917,'validation_retrieval_seed':41927,'selection_rule':'L2+replay maximum mean validation recall768, mean adaptation accuracy >= .245; ties smaller lambda','markov_optimal_accuracy':.85,'markov_transition':'P(next=(current+1)%4)=.85, other three=.05 each','replication_unit':'adaptation seed conditional on shared original pretrained checkpoint'})
 atomic(out/'manifest.json',manifest)
 for seed in map(int,a.seeds.split(',')):
  for name,p,lam,l2 in configs:
   dest=out/f'seed{seed}_{name}.json'
   if dest.exists():continue
   torch.manual_seed(seed);model=L.TinyLRM(32,128,3,4,32,2048).to(dev);model.load_state_dict(pre);opt=torch.optim.AdamW(L.build_param_groups(model,.01),lr=1e-4)
   l2ref={k:v.to(dev) for k,v in pre.items()} if l2 else None
   sg=torch.Generator().manual_seed(seed+2001);rg=torch.Generator().manual_seed(seed+2002);cg=torch.Generator().manual_seed(seed+2003)
   def penalty():
    value=lam*distance(spectrum(model,probe),ref) if lam else torch.zeros((),device=dev)
    if l2:value=value+l2*sum((v-l2ref[k]).square().sum() for k,v in model.named_parameters())/sum(v.numel() for v in model.parameters())
    return value
   model.train();t=time.perf_counter();replays=0;steps=2 if a.smoke else a.steps
   for step in range(steps):
    opt.zero_grad(set_to_none=True);x=short_batch(32,sg,dev,a.suite);z=model(x[:,:-1]);loss=F.cross_entropy(z.reshape(-1,32),x[:,1:].reshape(-1))+penalty();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
    if p and float(torch.rand(1,generator=cg))<p:
     opt.zero_grad(set_to_none=True);x,y,_=L.make_mqar(32,192,32,4,rg,dev);loss=F.cross_entropy(model(x)[:,-2],y)+penalty();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step();replays+=1
    if (step+1)%1000==0:print(a.suite,seed,name,step+1,round(time.perf_counter()-t,1),flush=True)
   if dev.type=='cuda':torch.cuda.synchronize()
   elapsed=time.perf_counter()-t;model.eval();val=evaluate(model,True);r=evaluate(model);r.update({'seed':seed,'mode':name,'replay_probability':p,'spectral_lambda':lam,'l2_lambda':l2,'suite':a.suite,'validation':val,'training':{'short_updates':steps,'replay_updates':replays,'seconds_contended':elapsed},'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest()})
   torch.save(model.state_dict(),out/f'seed{seed}_{name}.pt');atomic(dest,r);print('DONE',a.suite,seed,name,r['recall']['768']['accuracy'],r['local'],flush=True)
   del model,opt,l2ref
   if dev.type=='cuda':torch.cuda.empty_cache()
 print('COMPLETE',a.suite,flush=True)
if __name__=='__main__':main()
