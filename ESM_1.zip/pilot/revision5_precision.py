"""Isolate TF32 on the same fixed controlled-model checkpoints and test streams."""
import argparse,hashlib,json,platform
from pathlib import Path
import torch
import lrm_pilot as L
from revision_paired import recall,local
ap=argparse.ArgumentParser();ap.add_argument('--runs',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
out=Path(a.out);out.mkdir(parents=True,exist_ok=True);torch.set_num_threads(4)
dev=torch.device('cuda');model=L.TinyLRM(32,128,3,4,32,2048).to(dev).eval()
result={'schema':'fixed-checkpoint-precision-v5','torch':torch.__version__,'python':platform.python_version(),
        'gpu':torch.cuda.get_device_name(),'retrieval_seed':81917,'short_seed':81591,
        'retrieval_batch':16,'short_batch':32,'n_examples':1024,
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'generator_sha256':hashlib.sha256(Path(L.__file__).read_bytes()).hexdigest(),'seeds':{}}
for seed in range(3):
    p=Path(a.runs)/f'seed{seed}_vanilla.pt';state=torch.load(p,map_location='cpu')
    model.load_state_dict(state);assert all(p.dtype==torch.float32 for p in model.parameters())
    row={'checkpoint_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'precision':{}}
    for enabled in [False,True]:
        torch.backends.cuda.matmul.allow_tf32=enabled
        row['precision'][str(enabled).lower()]={'matmul_allow_tf32':enabled,
            'matmul_precision':torch.get_float32_matmul_precision(),
            'recall':{str(length):recall(model,length,1024,16,81917,dev) for length in [192,384,768]},
            'local':local(model,1024,32,81591,dev)}
        print(seed,enabled,row['precision'][str(enabled).lower()]['recall']['768']['accuracy'],flush=True)
    result['seeds'][str(seed)]=row
    tmp=out/'results.json.tmp';tmp.write_text(json.dumps(result,indent=2,allow_nan=False));tmp.replace(out/'results.json')
print('COMPLETE',flush=True)
