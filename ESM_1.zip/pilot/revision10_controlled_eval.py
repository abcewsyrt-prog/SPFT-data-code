"""Fixed-checkpoint interventions and one-precision controlled evaluations; no training."""
import argparse,hashlib,json,subprocess,os
from pathlib import Path
import torch
import lrm_pilot as L
from revision_paired import recall
from revision3_train import short_eval

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def atomic(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix('.tmp');q.write_text(json.dumps(v,indent=2,allow_nan=False));q.replace(p)
def decay(k):return k.endswith(('A_log','g_proj.weight'))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',required=True,type=Path);a=ap.parse_args();R=a.root;O=R/'revision_v10';out=O/'controlled';out.mkdir(exist_ok=True)
 torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=True;torch.backends.cudnn.allow_tf32=True;dev=torch.device('cuda')
 prepath=R/'results/pilot_pretrained.pt';pre=torch.load(prepath,map_location='cpu');model=L.TinyLRM(32,128,3,4,32,2048).to(dev).eval()
 manifest=dict(source_sha256=sha(__file__),generator_sha256=sha(L.__file__),pre_sha256=sha(prepath),torch=torch.__version__,matmul_tf32=True,cudnn_tf32=True,parameter_dtype='float32',replication='three adaptation seeds conditional on one fixed pretrained reference',retrieval_seed=81917,short_seed=81591,n=1024,retrieval_batch=16,short_batch=32,new_training_runs=0)
 atomic(out/'manifest.json',manifest)
 def evaluate(state,suite):
  model.load_state_dict(state);return dict(recall={str(n):recall(model,n,1024,16,81917,dev) for n in [192,384,768]},local=short_eval(model,suite),matmul_tf32=True)
 for suite in ['iid','markov']:
  for p in sorted((R/f'revision_v3/{suite}').glob('seed*_*.pt')):
   dest=out/(suite+'_'+p.stem+'.json')
   if dest.exists():continue
   atomic(O/'progress.json',dict(phase='unified_precision',suite=suite,checkpoint=p.name));state=torch.load(p,map_location='cpu');v=evaluate(state,suite);old=json.loads(p.with_suffix('.json').read_text());v.update(checkpoint_sha256=sha(p),seed=old['seed'],mode=old['mode'],suite=suite,original_prediction_reproduced=all(v['recall'][n]['predictions']==old['recall'][n]['predictions'] for n in v['recall']));atomic(dest,v);print('ENDPOINT',suite,p.stem,v['recall']['768']['accuracy'],v['original_prediction_reproduced'],flush=True)
 for mode in ['vanilla','lcr','spec_reg','spft']:
  for seed in range(3):
   p=R/f'revision_v3/iid/seed{seed}_{mode}.pt';ft=torch.load(p,map_location='cpu')
   for d,c in [(False,False),(True,False),(False,True),(True,True)]:
    name=f'seed{seed}_{mode}_decay{int(d)}_other{int(c)}';dest=out/(name+'.json')
    if dest.exists():continue
    atomic(O/'progress.json',dict(phase='parameter_swaps',mode=mode,seed=seed,decay_adapted=d,other_adapted=c));state={k:(ft[k] if (d if decay(k) else c) else v) for k,v in pre.items()};v=evaluate(state,'iid');v.update(seed=seed,mode=mode,checkpoint_sha256=sha(p),decay_adapted=d,other_adapted=c);atomic(dest,v);print('SWAP',name,v['recall']['768']['accuracy'],flush=True)
   if mode=='spft':
    for group in ['decay','other']:
     for alpha in [0.,.2,.4,.6,.8,1.]:
      dest=out/f'seed{seed}_spft_interpolate_{group}_{alpha:g}.json'
      if dest.exists():continue
      atomic(O/'progress.json',dict(phase='spft_interpolation',seed=seed,group=group,alpha=alpha));state={k:((1-alpha)*v+alpha*ft[k] if decay(k)==(group=='decay') else v) for k,v in pre.items()};v=evaluate(state,'iid');v.update(seed=seed,mode=mode,checkpoint_sha256=sha(p),group=group,alpha=alpha);atomic(dest,v);print('INTERPOLATE',seed,group,alpha,v['recall']['768']['accuracy'],flush=True)
 atomic(out/'complete.json',dict(status='complete',unified_precision_models=36,swapped_states=48,spft_interpolated_states=36,matmul_tf32=True,new_training_runs=0));atomic(O/'queue_status.json',dict(phase='completed_pending_validation'));print('COMPLETE',flush=True)
if __name__=='__main__':main()
