"""Paired held-out re-evaluation of existing toy checkpoints; no training claims."""
import argparse,hashlib,json,math,time
from pathlib import Path
import torch
import lrm_pilot as L


def recall(model, length, n, batch, seed, device):
    gen=torch.Generator().manual_seed(seed+length)
    hit=[]; targets=[];predictions=[];distances=[]
    model.eval()
    with torch.no_grad():
        for start in range(0,n,batch):
            x,y,d=L.make_mqar(min(batch,n-start),length,32,4,gen,device)
            pred=model(x)[:,-2].argmax(-1)
            hit.extend((pred==y).int().cpu().tolist());targets.extend(y.cpu().tolist());predictions.extend(pred.cpu().tolist());distances.extend(d.cpu().tolist())
    return {'n':n,'hits':hit,'accuracy':sum(hit)/n,'predictions':predictions,'targets':targets,'distances':distances}


def local(model,n,batch,seed,device):
    gen=torch.Generator().manual_seed(seed); seq=[]
    model.eval()
    with torch.no_grad():
        for start in range(0,n,batch):
            x=L.make_local_task(min(batch,n-start),48,32,gen,device)
            pred=model(x[:,:-1]).argmax(-1)
            seq.extend((pred==x[:,1:]).float().mean(1).cpu().tolist())
    return {'n_sequences':n,'sequence_accuracy':seq,'accuracy':sum(seq)/n}


def ci(values):
    v=torch.tensor(values,dtype=torch.float64);gen=torch.Generator().manual_seed(2781)
    boot=v[torch.randint(v.numel(),(4000,v.numel()),generator=gen)].mean(1)
    return [float(torch.quantile(boot,.025)),float(torch.quantile(boot,.975))]


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--out',required=True);ap.add_argument('--n',type=int,default=1024);ap.add_argument('--batch',type=int,default=8)
    args=ap.parse_args();root=Path(args.root);out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu');torch.set_num_threads(4)
    pre=torch.load(root/'pilot_pretrained.pt',map_location='cpu');ft=torch.load(root/'pilot_ft_vanilla.pt',map_location='cpu')
    model=L.TinyLRM(32,128,3,4,32,2048).to(device)
    summary={'schema':'toy-paired-v2','unit':'held-out examples, fixed existing checkpoints; not independent training seeds','device':torch.cuda.get_device_name() if device.type=='cuda' else 'cpu','torch':torch.__version__,'n':args.n,'results':{},'checkpoint_sha256':{}}
    def evaluate(name,state):
        t=time.perf_counter();model.load_state_dict(state)
        r={'recall':{str(length):recall(model,length,args.n,args.batch,81917,device) for length in [192,384,768]},'local':local(model,args.n,args.batch,81591,device)}
        r['seconds']=time.perf_counter()-t
        summary['results'][name]=r;(out/'results.json').write_text(json.dumps(summary,indent=2))
        print(name,{k:v['accuracy'] for k,v in r['recall'].items()},r['local']['accuracy'],round(r['seconds'],1),flush=True)
    for name,file in [('pre','pilot_pretrained.pt'),('vanilla','pilot_ft_vanilla.pt'),('freeze_decay','pilot_ft_freeze_decay.pt'),('restore_decay','pilot_ft_restore_decay.pt'),('spec_reg','pilot_ft_spec_reg.pt'),('lcr','pilot_ft_lcr.pt'),('spft','pilot_ft_spft.pt')]:
        f=root/file;summary['checkpoint_sha256'][name]=hashlib.sha256(f.read_bytes()).hexdigest();evaluate(name,torch.load(f,map_location='cpu'))
    for dft,cft in [(False,True),(True,False)]:
        state={k:(ft[k] if (dft if k.endswith(('A_log','g_proj.weight')) else cft) else v) for k,v in pre.items()}
        evaluate('swap_decay_{}_content_{}'.format('ft' if dft else 'pre','ft' if cft else 'pre'),state)
    comparisons={}
    for a,b in [('spft','lcr'),('spft','vanilla'),('swap_decay_pre_content_ft','vanilla')]:
        comp={}
        for length in ['192','384','768']:
            va=summary['results'][a]['recall'][length];vb=summary['results'][b]['recall'][length]
            assert va['targets']==vb['targets'] and va['distances']==vb['distances']
            diff=[x-y for x,y in zip(va['hits'],vb['hits'])]
            comp[length]={'difference':sum(diff)/len(diff),'paired_sample_bootstrap95':ci(diff)}
        comparisons[a+'__minus__'+b]=comp
    summary['comparisons']=comparisons;(out/'results.json').write_text(json.dumps(summary,indent=2));print('COMPLETE',comparisons,flush=True)


if __name__=='__main__':main()
