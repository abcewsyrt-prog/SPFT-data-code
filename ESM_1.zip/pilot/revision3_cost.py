"""Isolated cost comparison for the exact corrective-intervention families."""
import argparse,hashlib,json,os,subprocess,time
from pathlib import Path
import torch
import torch.nn.functional as F
import lrm_pilot as L
from revision_train import spectrum,distance
ap=argparse.ArgumentParser();ap.add_argument('--pre',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
sensitivity=Path(a.out).parents[1]/'rwkv_sensitivity.log'
while not sensitivity.exists() or 'COMPLETE rwkv_sensitivity' not in sensitivity.read_text():
 if sensitivity.exists() and 'Traceback' in sensitivity.read_text():raise RuntimeError('Sensitivity queue failed before isolated timing.')
 time.sleep(15)
dev=torch.device('cuda');torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=True
pre=torch.load(a.pre,map_location='cpu');probe=L.make_mqar(8,192,32,4,torch.Generator().manual_seed(541),dev)[0]
pids={int(x.strip()) for x in subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).splitlines() if x.strip().isdigit()}
if pids-{os.getpid()}:raise RuntimeError('Dedicated timing requires all other GPU computations to finish.')
candidates=[]
for coefficient in [1,100,10000]:
 records=[json.loads((Path(a.out).parents[1]/'iid'/f'seed{s}_l2replay_{coefficient}.json').read_text()) for s in range(3)]
 accuracy=sum(x['validation']['local']['accuracy'] for x in records)/3
 recall=sum(x['validation']['recall']['768']['accuracy'] for x in records)/3
 if accuracy>=.245:candidates.append((recall,-coefficient))
selected=-max(candidates)[1]
configs=[('vanilla',0.,0.,0.),('lcr',.05,0.,0.),('spec_reg',0.,1.,0.),('spft',.05,1.,0.),('lcr_p30',.30,0.,0.),('l2replay',.05,0.,float(selected))];rows=[]
for rep in range(3):
 for name,p,lam,l2 in configs:
  model=L.TinyLRM(32,128,3,4,32,2048).to(dev);model.load_state_dict(pre)
  with torch.no_grad():ref=[x.detach() for x in spectrum(model,probe)]
  opt=torch.optim.AdamW(L.build_param_groups(model,.01),lr=1e-4);refs={k:v.to(dev) for k,v in pre.items()} if l2 else None
  gen=torch.Generator().manual_seed(77);x=L.make_local_task(32,48,32,gen,dev);rx,ry,_=L.make_mqar(32,192,32,4,gen,dev)
  def penalty():
   val=lam*distance(spectrum(model,probe),ref) if lam else torch.zeros((),device=dev)
   if l2:val=val+l2*sum((z-refs[k]).square().sum() for k,z in model.named_parameters())/sum(z.numel() for z in model.parameters())
   return val
  def update(i):
   opt.zero_grad(set_to_none=True);z=model(x[:,:-1]);loss=F.cross_entropy(z.reshape(-1,32),x[:,1:].reshape(-1))+penalty();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
   if int((i+1)*p)>int(i*p):
    opt.zero_grad(set_to_none=True);loss=F.cross_entropy(model(rx)[:,-2],ry)+penalty();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
  for i in range(20):update(i)
  torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();start=time.perf_counter()
  for i in range(200):update(i)
  torch.cuda.synchronize();row={'mode':name,'repeat':rep,'seconds':time.perf_counter()-start,'peak_memory_bytes':torch.cuda.max_memory_allocated(),'short_updates':200,'replay_updates':int(200*p)};rows.append(row);print(row,flush=True)
  del model,opt,refs,ref;torch.cuda.empty_cache()
result={'schema':'dedicated-v3-cost','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'device':torch.cuda.get_device_name(),'torch':torch.__version__,'configs':configs,'warmup_short_updates':20,'resident_inputs':True,'gpu_pids_at_start':sorted(pids),'rows':rows};Path(a.out).parent.mkdir(parents=True,exist_ok=True);Path(a.out).write_text(json.dumps(result,indent=2));print('COMPLETE isolated_cost',flush=True)
