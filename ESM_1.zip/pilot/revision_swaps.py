"""Paired checkpoint interventions on fresh, provenance-matched adaptation seeds."""
import argparse,hashlib,json
from pathlib import Path
import torch
import lrm_pilot as L
from revision_paired import recall,local,ci
ap=argparse.ArgumentParser();ap.add_argument('--pre',required=True);ap.add_argument('--runs',required=True);ap.add_argument('--out',required=True);ap.add_argument('--seeds',default='0,1,2');ap.add_argument('--n',type=int,default=1024);a=ap.parse_args()
out=Path(a.out);out.mkdir(parents=True,exist_ok=True);device=torch.device('cuda' if torch.cuda.is_available() else 'cpu');torch.set_num_threads(4)
pre=torch.load(a.pre,map_location='cpu');model=L.TinyLRM(32,128,3,4,32,2048).to(device)
summary={'schema':'paired-fresh-swaps-v2','n':a.n,'pre_sha256':hashlib.sha256(Path(a.pre).read_bytes()).hexdigest(),'unit':'independent adaptation seeds conditional on a fixed pretrained checkpoint','results':{}}
def eval_state(state):
 model.load_state_dict(state)
 return {'recall':{str(n):recall(model,n,a.n,16,81917,device) for n in [192,384,768]},'local':local(model,a.n,32,81591,device)}
def is_decay(k):return k.endswith(('A_log','g_proj.weight'))
for seed in map(int,a.seeds.split(',')):
 path=Path(a.runs)/('seed{}_vanilla.pt'.format(seed))
 if not path.exists():raise FileNotFoundError(str(path))
 ft=torch.load(path,map_location='cpu');entry={'ft_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'swaps':{},'interpolation':{}}
 for df,cf in [(False,False),(True,False),(False,True),(True,True)]:
  name='decay_{}_content_{}'.format('ft' if df else 'pre','ft' if cf else 'pre')
  state={k:(ft[k] if (df if is_decay(k) else cf) else v) for k,v in pre.items()}
  entry['swaps'][name]=eval_state(state)
 for group in ['decay','content']:
  rows=[]
  for alpha in [0.,.2,.4,.6,.8,1.]:
   state={k:((1-alpha)*v+alpha*ft[k] if (is_decay(k)==(group=='decay')) else v) for k,v in pre.items()}
   r=eval_state(state);r['alpha']=alpha;rows.append(r)
  entry['interpolation'][group]=rows
 summary['results'][str(seed)]=entry;(out/'results.json').write_text(json.dumps(summary,indent=2))
 print('DONE',seed,{k:v['recall']['768']['accuracy'] for k,v in entry['swaps'].items()},flush=True)
print('ALL_COMPLETE',flush=True)
